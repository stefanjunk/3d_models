# 3D Design Preflight Skill v0.9

Dieses Paket enthält ein research-basiertes, aber bewusst **noch nicht statistisch kalibriertes** Preflight-System für 3D-Druck- und CAD-Projekte.

## Dateien

- `SKILL.md` - kompakte Agentenlogik und Freigaberegeln
- `rubrics/scoring-rubric.yaml` - vollständige Bewertungsrubriken
- `schemas/interface-contract.schema.json` - Interface-Vertrag
- `schemas/preflight-result.schema.json` - maschinenlesbares Ergebnis
- `templates/preflight-input.yaml` - Aufnahmeformular
- `templates/interface-register.yaml` - Interface-Register
- `examples/example-assessments.yaml` - Beispielbewertungen
- `references/research-basis.md` - Forschungsbasis und Grenzen

## Empfohlene Integration

1. Preflight als Pflichtschritt vor dem 3D Functional Design Workflow ausführen.
2. Bei Lane A/B kann der Design-Agent nach bestandenen Gates starten.
3. Bei Lane C erzeugt er zuerst Interface-Master und Testcoupons.
4. Lane D verlangt Fachprüfung und gestufte Nachweise.
5. Lane E blockiert Endfreigabe und beschränkt die Arbeit auf Konzept/Data Acquisition.

Die Gewichte und Schwellwerte sind eine operationale Synthese. Sie sollten nach 30-100 dokumentierten Projekten gegen reale Erstpassungs-, Funktions- und Iterationsdaten kalibriert werden.
