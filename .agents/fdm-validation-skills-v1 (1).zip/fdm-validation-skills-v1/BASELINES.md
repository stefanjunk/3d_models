# Ausgangskopien

Die elf Fach-Skills wurden aus den zum Paketzeitpunkt installierten, logisch gleichnamigen Skills kopiert. Die internen Quellkennungen dienen nur zum späteren Vergleich:

| Logischer Name | Ausgangskennung |
|---|---|
| `3d-print-heightmap-relief` | `skill-6a78249a37e08191987ce96d28f83caf` |
| `casting-negative-molds` | `skill-6a78b45bec788191a724b8965403d792` |
| `commercialize-3d-models` | `skill-6a79ed43268481919bbab30da744f67b` |
| `decompose-printable-designs` | `skill-6a821dc40fec819186b2a11abfda394e` |
| `design-printable-surface-textures` | `skill-6a84d08d99c08191bb2300a91084bbe9` |
| `functional-3d-design` | `skill-6a785770000081918fd92f036b9a0d9e` |
| `multicolor-fdm-design` | `skill-6a86fc67d3608191b534e4d3cb728f06` |
| `optimize-fdm-design` | `skill-6a7d9c74b94c8191a0be76910e80b7ef` |
| `organic-mesh-functionalization` | `skill-6a78b48c72cc8191bae2c4ae5877ddf8` |
| `parametric-freeform-surfacing` | `skill-6a86fc987bdc8191b247880f8d8d242a` |
| `reconstruct-printable-3d-from-images` | `skill-6a78e2d1919c8191ad415c7eb7329f79` |

`validate-printable-3d-projects` ist neu und hat keine Ausgangskopie.
