# Validierungsstand

Der endgültige Paketlauf wird in `validation-results.json` abgelegt. Die folgenden Gates müssen für das Downloadpaket erfüllt sein:

- alle zwölf Skill-Verzeichnisse bestehen `validate-skill --runtime opencode --profile release`;
- alle elf Companion-Profile bestehen `validate-profile --profile release`;
- alle JSON-Dateien sind parsebar und alle Python-Dateien AST-valid;
- alle vorhandenen standardbibliotheksbasierten Tests laufen;
- Tests mit nicht installierten optionalen Backends werden als übersprungen oder `NOT_RUN` ausgewiesen, niemals als `PASS` erfunden;
- keine `.pyc`- oder `__pycache__`-Dateien sind enthalten;
- `SHA256SUMS` deckt den Downloadinhalt ab und `tools/verify_package.py` bestätigt ihn.

## Ausgeführter Lauf

- Paketstatus: `PASS`
- ausgeführte Unittests: **96**
- davon übersprungen: **8** (jeweils sauber dependency-gesteuert)
- fehlgeschlagene Suites: **0**
- statische Skill-/Profil-/JSON-/AST-Prüfung: `PASS`
- zusätzliche vollständige Suites `casting-negative-molds` und `organic-mesh-functionalization`: `NOT_RUN`, weil `pytest` beziehungsweise `trimesh` in der unveränderten Testumgebung fehlen

Die neue Autonomie-Suite deckt zusätzlich ab:

- vollständige Agentenfreigabe bis `print-candidate`;
- Ablehnung eines Agentenversuchs auf `physical-print` ohne Ledger-Änderung;
- `BLOCKED` bei `NOT_RUN`-Evidenz;
- Erkennung nachträglich veränderter Evidenz;
- integrierte `approvals`-Prüfung im Projektvertrag;
- HMAC-geprüfte menschliche Freigabe und Ablehnung eines falschen Prüfschlüssels.

Die zwei `NOT_RUN`-Suites sind in `validation-results.json` offen ausgewiesen. Ihre Abhängigkeiten sind in den jeweiligen Requirements-Dateien deklariert; der Paketlauf hat sie absichtlich nicht installiert.

## Cross-Runtime-Frontmatter

Der neue Skill `validate-printable-3d-projects` besteht zusätzlich den strikten `skill-creator/scripts/quick_validate.py`-Check. Vier übernommene OpenCode-Skills (`casting-negative-molds`, `multicolor-fdm-design`, `organic-mesh-functionalization` und `parametric-freeform-surfacing`) behalten bewusst ihr bereits vorhandenes `compatibility`-Frontmatter. Der reine Codex-Quick-Validator kennt dieses OpenCode-Feld nicht; die paketinterne Cross-Runtime-Prüfung und alle zwölf `--runtime opencode`-Prüfungen bestehen. Das Feld wurde deshalb nicht stillschweigend entfernt.

## Erwartete optionale Backends

Die gemeinsame Runtime installiert nichts. Für vollständige Geometriepfade werden je nach Check unter anderem `trimesh`, `rtree`, `manifold3d`, `python-fcl`, `CadQuery`, `OpenSCAD`, `Blender` oder ein Slicer benötigt. Ohne passendes Backend meldet der jeweilige Pflichtcheck `NOT_RUN`.

## Grenzen dieses Pakettests

Pakettests beweisen Syntax, Verträge und vorhandene deterministische Pfade. Sie ersetzen keinen projektbezogenen Mesh-, Slicer-, Druck-, Fit-, Last-, Guss-, Farb-, Sicherheits- oder Rechtsnachweis.
