#!/usr/bin/env python3
from __future__ import annotations

import argparse
import json
import shutil
import subprocess
import sys
import tempfile
from pathlib import Path

ROOT = Path(__file__).resolve().parents[1]
SOURCE = ROOT / "skills"


def main() -> int:
    parser = argparse.ArgumentParser(description="Plan or install the bundled skills into an OpenCode skills directory.")
    parser.add_argument("--target", type=Path, required=True, help="Destination such as PROJECT/.opencode/skills")
    parser.add_argument("--skill", action="append", default=[], help="Install only this logical skill name; repeat as needed")
    parser.add_argument("--apply", action="store_true", help="Perform the copy; without this flag only print the plan")
    args = parser.parse_args()

    available = sorted(path.name for path in SOURCE.iterdir() if (path / "SKILL.md").is_file())
    selected = sorted(set(args.skill or available))
    unknown = sorted(set(selected) - set(available))
    target = args.target.resolve()
    existing = sorted(name for name in selected if (target / name).exists())
    verification = subprocess.run(
        [sys.executable, "-B", str(ROOT / "tools" / "verify_package.py")],
        cwd=ROOT,
        text=True,
        capture_output=True,
        check=False,
    )
    package_valid = verification.returncode == 0
    status = "BLOCKED" if unknown or existing or not package_valid else ("APPLIED" if args.apply else "PLAN")
    report = {
        "status": status,
        "source": str(SOURCE),
        "target": str(target),
        "selected": selected,
        "unknown": unknown,
        "existing_targets": existing,
        "package_valid": package_valid,
        "will_modify": bool(args.apply and not unknown and not existing and package_valid),
        "note": "Existing skills are never overwritten.",
    }
    if unknown or existing or not package_valid:
        print(json.dumps(report, indent=2, sort_keys=True))
        return 1
    if not args.apply:
        print(json.dumps(report, indent=2, sort_keys=True))
        return 0

    target.parent.mkdir(parents=True, exist_ok=True)
    target.mkdir(parents=True, exist_ok=True)
    staging = Path(tempfile.mkdtemp(prefix=".fdm-skills-stage-", dir=target.parent))
    try:
        for name in selected:
            shutil.copytree(SOURCE / name, staging / name, symlinks=False)
        for name in selected:
            (staging / name).replace(target / name)
    finally:
        shutil.rmtree(staging, ignore_errors=True)
    print(json.dumps(report, indent=2, sort_keys=True))
    return 0


if __name__ == "__main__":
    raise SystemExit(main())
