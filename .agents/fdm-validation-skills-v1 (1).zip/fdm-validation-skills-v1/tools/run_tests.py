#!/usr/bin/env python3
from __future__ import annotations

import argparse
import importlib.util
import json
import os
import re
import subprocess
import sys
from pathlib import Path

ROOT = Path(__file__).resolve().parents[1]
SKILLS = ROOT / "skills"
UNITTEST_SKILLS = [
    "3d-print-heightmap-relief",
    "commercialize-3d-models",
    "decompose-printable-designs",
    "design-printable-surface-textures",
    "functional-3d-design",
    "multicolor-fdm-design",
    "optimize-fdm-design",
    "parametric-freeform-surfacing",
    "reconstruct-printable-3d-from-images",
    "validate-printable-3d-projects",
]


def run(command: list[str], cwd: Path, timeout: float = 300) -> dict:
    environment = os.environ.copy()
    environment["PYTHONDONTWRITEBYTECODE"] = "1"
    environment.setdefault("PYTHONHASHSEED", "0")
    try:
        completed = subprocess.run(
            command,
            cwd=cwd,
            env=environment,
            text=True,
            capture_output=True,
            check=False,
            timeout=timeout,
        )
        combined = completed.stdout + completed.stderr
        ran = re.search(r"Ran\s+(\d+)\s+tests?", combined)
        skipped = re.search(r"skipped=(\d+)", combined)
        result = {
            "status": "PASS" if completed.returncode == 0 else "FAIL",
            "returncode": completed.returncode,
            "tests_ran": int(ran.group(1)) if ran else None,
            "tests_skipped": int(skipped.group(1)) if skipped else 0,
        }
        if completed.returncode != 0:
            result["output_tail"] = combined[-8000:]
        return result
    except subprocess.TimeoutExpired as exc:
        stdout = exc.stdout.decode("utf-8", errors="replace") if isinstance(exc.stdout, bytes) else (exc.stdout or "")
        stderr = exc.stderr.decode("utf-8", errors="replace") if isinstance(exc.stderr, bytes) else (exc.stderr or "")
        tail = (stdout + stderr)[-8000:]
        return {"status": "FAIL", "returncode": 124, "tests_ran": None, "tests_skipped": 0, "output_tail": tail}


def main() -> int:
    parser = argparse.ArgumentParser(description="Run available tests without installing dependencies.")
    parser.add_argument("--json-out", type=Path)
    args = parser.parse_args()
    suites = {}

    verify = run([sys.executable, "-B", str(ROOT / "tools" / "verify_package.py")], ROOT)
    suites["package-static"] = verify

    for name in UNITTEST_SKILLS:
        suites[name] = run(
            [sys.executable, "-B", "-m", "unittest", "discover", "-s", "tests", "-p", "test_*.py", "-v"],
            SKILLS / name,
        )

    if importlib.util.find_spec("pytest") is None:
        suites["casting-negative-molds"] = {
            "status": "NOT_RUN",
            "reason": "pytest is declared by the skill but not installed in the current test environment",
            "tests_ran": 0,
            "tests_skipped": 0,
        }
    else:
        suites["casting-negative-molds"] = run(
            [sys.executable, "-B", "-m", "pytest", "-q", "tests"],
            SKILLS / "casting-negative-molds",
        )

    if importlib.util.find_spec("trimesh") is None:
        suites["organic-mesh-functionalization"] = {
            "status": "NOT_RUN",
            "reason": "trimesh is declared by the skill but not installed in the current test environment",
            "tests_ran": 0,
            "tests_skipped": 0,
        }
    else:
        suites["organic-mesh-functionalization"] = run(
            [sys.executable, "-B", "tests/smoke_test.py"],
            SKILLS / "organic-mesh-functionalization",
        )

    failures = sorted(name for name, result in suites.items() if result["status"] == "FAIL")
    not_run = sorted(name for name, result in suites.items() if result["status"] == "NOT_RUN")
    tests_ran = sum(result.get("tests_ran") or 0 for result in suites.values())
    tests_skipped = sum(result.get("tests_skipped") or 0 for result in suites.values())
    report = {
        "schema_version": "1.0",
        "tool": "run-package-tests",
        "status": "PASS" if not failures else "FAIL",
        "runtime_coverage": "REVIEW_REQUIRED" if not_run else "PASS",
        "summary": {
            "tests_ran": tests_ran,
            "tests_skipped": tests_skipped,
            "failed_suites": failures,
            "not_run_suites": not_run,
        },
        "suites": suites,
        "limitations": [
            "No dependency was installed or upgraded by this test runner.",
            "NOT_RUN suites require the dependencies declared by their skill before execution.",
        ],
    }
    rendered = json.dumps(report, indent=2, sort_keys=True, ensure_ascii=False) + "\n"
    if args.json_out:
        args.json_out.parent.mkdir(parents=True, exist_ok=True)
        args.json_out.write_text(rendered, encoding="utf-8")
    sys.stdout.write(rendered)
    return 0 if report["status"] == "PASS" else 1


if __name__ == "__main__":
    raise SystemExit(main())
