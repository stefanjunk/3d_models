#!/usr/bin/env python3
from __future__ import annotations

import argparse
import ast
import hashlib
import json
import subprocess
import sys
from pathlib import Path

ROOT = Path(__file__).resolve().parents[1]
SKILLS = ROOT / "skills"
CORE = SKILLS / "validate-printable-3d-projects" / "scripts" / "fdm_ci.py"
EXPECTED = {
    "3d-print-heightmap-relief",
    "casting-negative-molds",
    "commercialize-3d-models",
    "decompose-printable-designs",
    "design-printable-surface-textures",
    "functional-3d-design",
    "multicolor-fdm-design",
    "optimize-fdm-design",
    "organic-mesh-functionalization",
    "parametric-freeform-surfacing",
    "reconstruct-printable-3d-from-images",
    "validate-printable-3d-projects",
}


def digest(path: Path) -> str:
    value = hashlib.sha256()
    with path.open("rb") as handle:
        for block in iter(lambda: handle.read(1024 * 1024), b""):
            value.update(block)
    return value.hexdigest()


def run_core(*arguments: str) -> dict:
    completed = subprocess.run(
        [sys.executable, "-B", str(CORE), *arguments],
        cwd=ROOT,
        text=True,
        capture_output=True,
        check=False,
    )
    try:
        result = json.loads(completed.stdout)
    except Exception as exc:
        return {"status": "FAIL", "error": f"invalid core output: {exc}", "stderr": completed.stderr}
    result["exit_code"] = completed.returncode
    return result


def verify_checksums(path: Path) -> dict:
    if not path.is_file():
        return {"status": "NOT_RUN", "message": "SHA256SUMS is not present"}
    failures = []
    checked = 0
    for line_number, line in enumerate(path.read_text(encoding="utf-8").splitlines(), start=1):
        if not line.strip():
            continue
        try:
            expected, relative = line.split("  ", 1)
        except ValueError:
            failures.append(f"line {line_number}: malformed")
            continue
        target = ROOT / relative
        if not target.is_file():
            failures.append(f"{relative}: missing")
        elif digest(target) != expected:
            failures.append(f"{relative}: hash mismatch")
        checked += 1
    return {"status": "PASS" if not failures else "FAIL", "checked": checked, "failures": failures}


def main() -> int:
    parser = argparse.ArgumentParser(description="Read-only verification of the downloadable FDM skill package.")
    parser.add_argument("--json-out", type=Path)
    args = parser.parse_args()

    checks = []
    actual = {path.name for path in SKILLS.iterdir() if (path / "SKILL.md").is_file()}
    checks.append({"id": "skill-set", "status": "PASS" if actual == EXPECTED else "FAIL", "expected": sorted(EXPECTED), "actual": sorted(actual)})

    skill_results = {}
    profile_results = {}
    for name in sorted(EXPECTED):
        skill = SKILLS / name
        result = run_core("validate-skill", str(skill), "--runtime", "opencode", "--profile", "release")
        skill_results[name] = result
        checks.append({"id": f"skill:{name}", "status": result.get("status", "FAIL")})
        companion_profile = skill / "assets" / "validation-profile.json"
        if companion_profile.is_file():
            profile_result = run_core("validate-profile", str(companion_profile), "--profile", "release")
            profile_results[name] = profile_result
            checks.append({"id": f"profile:{name}", "status": profile_result.get("status", "FAIL")})

    json_errors = []
    for path in sorted(ROOT.rglob("*.json")):
        try:
            json.loads(path.read_text(encoding="utf-8"))
        except Exception as exc:
            json_errors.append(f"{path.relative_to(ROOT)}: {exc}")
    checks.append({"id": "json-syntax", "status": "PASS" if not json_errors else "FAIL", "errors": json_errors})

    python_errors = []
    python_count = 0
    for path in sorted(ROOT.rglob("*.py")):
        python_count += 1
        try:
            ast.parse(path.read_text(encoding="utf-8"), filename=str(path))
        except Exception as exc:
            python_errors.append(f"{path.relative_to(ROOT)}: {exc}")
    checks.append({"id": "python-ast", "status": "PASS" if not python_errors else "FAIL", "files": python_count, "errors": python_errors})

    cache_files = [str(path.relative_to(ROOT)) for path in ROOT.rglob("*.pyc")]
    cache_dirs = [str(path.relative_to(ROOT)) for path in ROOT.rglob("__pycache__") if path.is_dir()]
    checks.append({"id": "no-bytecode-cache", "status": "PASS" if not cache_files and not cache_dirs else "FAIL", "files": cache_files, "directories": cache_dirs})

    checksum_result = verify_checksums(ROOT / "SHA256SUMS")
    checks.append({"id": "checksums", **checksum_result})
    required = [item for item in checks if item["id"] != "checksums" or checksum_result["status"] != "NOT_RUN"]
    status = "PASS" if all(item["status"] == "PASS" for item in required) else "FAIL"
    report = {
        "schema_version": "1.0",
        "tool": "verify-package",
        "status": status,
        "checks": checks,
        "skill_results": skill_results,
        "profile_results": profile_results,
    }
    rendered = json.dumps(report, indent=2, sort_keys=True, ensure_ascii=False) + "\n"
    if args.json_out:
        args.json_out.parent.mkdir(parents=True, exist_ok=True)
        args.json_out.write_text(rendered, encoding="utf-8")
    sys.stdout.write(rendered)
    return 0 if status == "PASS" else 1


if __name__ == "__main__":
    raise SystemExit(main())
