# Änderungsmatrix

| Skill | Deterministische Ergänzung | Weiterhin explizit menschlich/physisch |
|---|---|---|
| `validate-printable-3d-projects` | Neue gemeinsame CLI für Doctor, Hash-Lock, Profile, Projekte, Mesh, Vergleich, Interfaces, G-Code, 3MF, Sweeps und Skill-Portabilität | Fachliche Grenzwerte und nicht messbare Freigaben |
| `3d-print-heightmap-relief` | Hash-Kette für Bild, 16-Bit-Master, Referenz-/Fertigungsmesh, Reliefbericht und G-Code | Druckcoupon, optische Reliefwirkung |
| `casting-negative-molds` | Mesh-/Interface-Gates, Pull-Richtungs-Sweep, Parameterbericht und G-Code; sichererer Smoke-Test ohne Bytecode | Undercuts, Venting, Drainage, Gipsmemory, Schrumpfversuch |
| `commercialize-3d-models` | Technischer Release-Report wird als gehashte Evidenz eingebunden | Rechte, Lizenzen, Produktsicherheit, Marktfreigaben |
| `decompose-printable-designs` | Komponentenautorität, Datums, Transformationen, Interfaces, Assembly-3MF und Integrationsbericht | Servicezugang, Interface-Coupon |
| `design-printable-surface-textures` | Mapping-/Budgetbericht, Schutzmaske, Mesh und G-Code werden hashgebunden | Optik, Haptik, Haftung, Reinigung |
| `functional-3d-design` | Zentrales Release-Orchestrator-Profil für Quelle, Mesh, Interface, Sweep, 3MF, G-Code und Freigaben | Funktions-/Fit-Coupon, sicherheitskritische Qualifikation |
| `multicolor-fdm-design` | Strengere 3MF-/Part-/Interface-/G-Code-Route; AST statt `py_compile`; begrenzte Dependency-Ranges und dependency-aware Tests | Purge-/Farbgrenzencoupon, finale Slicer-Interpretation |
| `optimize-fdm-design` | Baseline/Candidate-Hashes, deterministische Sweeps, geschützte Geometrie und G-Code-Metriken | Festigkeit, Dichtheit, Ermüdung, Pareto-Freigabe |
| `organic-mesh-functionalization` | Gehashte Original/ROI/Cutter/Edit-Kette, seeded Vergleich, Interface und G-Code | Physischer Insert-Fit; approximative Distanz bleibt Review |
| `parametric-freeform-surfacing` | Hardpoint-/Fairness-/Sweep-/Mesh-/G-Code-Profil; portabler OpenCode-Command; AST statt Bytecode; Requirements ergänzt | G1/G2, Silhouette, Ergonomie, Formcoupon |
| `reconstruct-printable-3d-from-images` | Kamera-/Masken-/Bild-/Mesh-Hashes und frischer View-Comparison-Bericht | Verdeckte Geometrie, semantische Annahmen, kritischer Maß-/Fit-Test |

## Querschnittsänderungen

- Jeder der elf Fach-Skills enthält `assets/validation-profile.json` und einen fail-closed Handoff in `SKILL.md`.
- `validate-skill` prüft diese Profile automatisch, wenn sie vorhanden sind.
- Pflichtartefakte ohne erwarteten SHA-256 blockieren ein Release.
- Externe Berichte ohne deklarierte Eingaben oder mit falschen/veralteten Hashes blockieren.
- 3MF prüft ZIP-Integrität, Größen-/Kompressionsgrenzen, sichere Pfade, Content Types, Root Relationship, IDs, Materialreferenzen, Transformen, Build-Items und Komponentenzyklen.
- G-Code behandelt Einheiten und Extruderpositionen pro Tool; nicht vollständig ausgewertete Arcs oder volumetrische Extrusion blockieren davon abhängige Aussagen.
- Sweeps verweigern nichtleere Ausgabeverzeichnisse, setzen `PYTHONHASHSEED` deterministisch und schreiben pro Fall Command/Stdout/Stderr.
- Skill-Prüfungen nutzen ausschließlich AST-Parsing und erzeugen kein `__pycache__`.

## Anwendungshinweis

Die Profile sind Anforderungsprofile, keine universellen Zahlenwerte. Bauraum, Materialfluss, Toleranz, Samplezahl, Wandstärke und Vergleichsgrenzen müssen pro Drucker, Material, Geometrie und Risiko freigegeben und in `validation-project.json` eingetragen werden.
