# Deterministische FDM-Skills für OpenCode

Dieses Paket ist eine **separate Download-Arbeitskopie**. Es wurde nichts in die aktuell installierten Skills übernommen.

## Inhalt

- elf überarbeitete Kopien der vorhandenen 3D-/FDM-Skills;
- der neue Skill `validate-printable-3d-projects` als gemeinsame, fail-closed Prüfruntime;
- elf maschinenlesbare `assets/validation-profile.json`-Profile;
- JSON-Schemas und editierbare Policy-Beispiele;
- Tests, Paketprüfung und ein standardmäßig rein planender OpenCode-Installer;
- Änderungs- und Validierungsübersicht.

## Was jetzt deterministisch ist

- eindeutige Statuswerte: `PASS`, `FAIL`, `NOT_RUN` und `REVIEW_REQUIRED`;
- SHA-256-Bindung von Quellen, Exporten und Prüfberichten;
- Erkennung veralteter externer Berichte anhand ihrer Eingabe-Hashes;
- Mesh-Topologie, Maße, Bauraum, Budgets und optionale Stichproben-Wandstärke;
- gesetzte, reproduzierbare Mesh-Vergleiche mit expliziten Toleranzen;
- Überlappungs-, Abstands- und diskrete Bewegungsverträge;
- lokales G-Code-Audit für Layer, Werkzeuge, Extrusion, Grenzen, Zeit und Fluss;
- sichere 3MF-ZIP-/XML-/Referenz-/Material-/Topologieprüfung;
- Default/Min/Max/Pairwise-Parametersweeps ohne Shell-Interpolation;
- Skill-Struktur, Python-AST, Abhängigkeitserklärungen, Symlink-Grenzen, Kontextbudget und OpenCode-Portabilität;
- ein aggregiertes Release-Gate, bei dem ein erforderliches `NOT_RUN` oder `REVIEW_REQUIRED` blockiert.

## Bewusst nicht automatisch entschieden

Selbstüberschneidungsnachweise ohne geeigneten exakten Backend, kontinuierliche Bewegungsfreiheit, Festigkeit und Ermüdung, Entformung/Venting/Drainage, Farbeindruck, Haptik, Ergonomie sowie rechtliche und sicherheitsbezogene Freigaben bleiben `NOT_RUN` oder `REVIEW_REQUIRED`. Das ist beabsichtigt: Ein lokales Modell darf fehlende Evidenz nicht sprachlich zu einem Pass umdeuten.

## Paket prüfen

Vom entpackten Paketverzeichnis:

```bash
python3 -B tools/verify_package.py
```

Der Prüfer verändert die Skill-Verzeichnisse nicht. Er validiert alle Skill-Kopien, Profile, JSON-Dateien, Python-Quellen und – sobald vorhanden – `SHA256SUMS`.

## OpenCode-Installation zunächst nur planen

```bash
python3 -B tools/install_opencode_skills.py \
  --target /pfad/zum/projekt/.opencode/skills
```

Erst `--apply` kopiert. Existierende Ziel-Skills werden grundsätzlich nicht überschrieben.

Für den optionalen Freeform-Command die enthaltene Datei
`skills/parametric-freeform-surfacing/opencode/commands/design-freeform-surface.md`
bei Bedarf separat nach `.opencode/commands/` kopieren.

## Validierungsprojekt verwenden

```bash
export FDM_VALIDATION_SKILL=.opencode/skills/validate-printable-3d-projects

python3 -B "$FDM_VALIDATION_SKILL/scripts/fdm_ci.py" doctor

python3 -B "$FDM_VALIDATION_SKILL/scripts/fdm_ci.py" \
  freeze-project validation-project.json validation-project.lock.json

python3 -B "$FDM_VALIDATION_SKILL/scripts/fdm_ci.py" \
  validate-project validation-project.lock.json \
  --profile release \
  --json-out validation/release-summary.json
```

`freeze-project` überschreibt die Quelldatei nie. Im Release-Profil benötigen erforderliche Artefakte erwartete Hashes.

## Betrieb mit einem lokalen 27B-Modell

- Lade den aktiven Fach-Skill, den Validator-Skill und nur die unmittelbar benötigten Referenzen.
- Lass das Modell Schwellen und Verträge formulieren; lass Skripte die Messung und Statusentscheidung ausführen.
- Übergib dem Modell den aggregierten JSON-Bericht statt vollständiger Logs und Quellcodes.
- Installiere fehlende Backends nicht automatisch. `doctor` meldet sie und erforderliche Checks werden `NOT_RUN`.
- Behandle das 130k-Kontextfenster als Obergrenze, nicht als Ziel. Der Paketprüfer setzt für jede `SKILL.md` ein kompaktes 24.000-Zeichen-Budget; alle enthaltenen Skills liegen darunter.

Siehe [CHANGE-MATRIX.md](CHANGE-MATRIX.md) für die Änderungen je Skill und [VALIDATION.md](VALIDATION.md) für den Teststand.
