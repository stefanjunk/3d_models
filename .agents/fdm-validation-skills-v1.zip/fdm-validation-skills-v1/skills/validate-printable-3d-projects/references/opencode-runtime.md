# OpenCode runtime

Install the complete directory as:

```text
.opencode/skills/validate-printable-3d-projects/
```

Install companion skills as sibling directories using their frontmatter names. Do not copy only `SKILL.md`; scripts, assets, and references are required.

The core CLI runs from any current working directory. Invoke it by absolute path or set:

```bash
export FDM_VALIDATION_SKILL=.opencode/skills/validate-printable-3d-projects
python3 "$FDM_VALIDATION_SKILL/scripts/fdm_ci.py" doctor
```

The validator never writes into its installed directory. Reports and temporary builds belong in the active model project.

## Dependencies

The manifest, G-code, 3MF, project, and skill-portability checks use the Python standard library. Mesh, distance, collision, wall-thickness, and CAD-format checks use optional capability groups listed by `doctor`.

Create a project virtual environment, install only required groups, then save the actual `doctor` report with every release. Do not let an agent silently install or upgrade the environment.

## Local-model context

Load this `SKILL.md`, the active specialist skill, and only the references explicitly needed for the task. Run scripts without loading their source into the model context. Feed the model the aggregate JSON failures and metrics rather than complete logs.
