"""Deterministic validation helpers for printable 3D projects."""

__version__ = "1.0.0"
