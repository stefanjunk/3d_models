# Changelog

## 1.0.0 — 2026-08-20

- Erstveröffentlichung mit 120 parametrischen FDM-Mechanikmustern in 30 Familien.
- 120 druckfertige Druckplatten, 284 getrennte Komponenten-STLs und 120 Vorschauen.
- Vollständiger OpenSCAD-Quellcode, Katalog, Auswahlwerkzeuge und OpenCode-Skill.
- Digitale Mesh- und Paketvalidierung für alle Muster.
- Deutsche Druck-, Integrations-, Toleranz- und physische Prüfhinweise.
