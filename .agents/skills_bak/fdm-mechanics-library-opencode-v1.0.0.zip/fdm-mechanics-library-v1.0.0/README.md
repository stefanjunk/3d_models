# FDM Mechanical Sample Library

A reproducible collection of **120 parametric, FDM-oriented mechanical samples across 30 families**. Every sample includes an OpenSCAD source, printable STL plate, separated component STLs, preview image, metadata, and German integration notes.

Start with `README_DE.md` and `CATALOG.html`. Build with OpenSCAD and Python; query with `python3 tools/query_catalog.py`.

Digital validation: 120/120 plates passed watertightness, positive-volume, orientation, build-plane, component-count, and 220-mm-bed checks. Physical strength and fatigue tests remain printer-, material-, and process-specific.

Code: MIT. Generated geometry and previews: CC0-1.0.
