# Validierungsbericht — FDM-Mechanikbibliothek v1.0.0

**Status:** digitale Release-Abnahme bestanden.

Dieser Bericht dokumentiert die automatisierte Geometrie- und Paketprüfung. Er ersetzt keine physischen Druck-, Last-, Ermüdungs- oder Sicherheitsversuche.

## Umfang

| Kennzahl | Ergebnis |
|---|---:|
| Parametrische Muster | 120 |
| Mechanikfamilien | 30 |
| Druckplatten-STLs | 120 |
| Getrennte Einzelkörper-STLs | 284 |
| Insgesamt validierte Dreiecke der Druckplatten | 193.720 |
| Summiertes Modellvolumen | 1.351,3 cm³ |
| Größte X-Ausdehnung | 146,031 mm |
| Größte Y-Ausdehnung | 96,870 mm |
| Maximale Z-Höhe | 54,000 mm |

## Ergebnis der Mesh-Prüfungen

| Prüfkriterium | Bestanden |
|---|---:|
| Druckplatte als Gesamtmesh wasserdicht | 120/120 |
| Orientierung/Winding konsistent | 120/120 |
| Alle getrennten Einzelkörper wasserdicht | 120/120 |
| Alle Einzelkörper mit positivem Volumen | 120/120 |
| Keine degenerierten Dreiecke | 120/120 |
| Geometrie vollständig auf oder über Z=0 | 120/120 |
| Passt in 220-mm-XY-Prüfbauraum | 120/120 |
| Komponentenanzahl stimmt mit Dokumentation überein | 120/120 |

Alle 120 Druckplatten erhielten den Status `passed`; es gab 0 Warnungen und 0 Fehler. Die vollständigen maschinenlesbaren Resultate liegen in `validation/build-summary.json` und `validation/samples/`.

## Geprüfte Dateien je Muster

- `model.scad`: parametrisierbare OpenSCAD-Quelle
- `print_plate.stl`: vorgesehene Druckanordnung
- `preview.png`: Montage-/Explosionsansicht
- `README.md`: Funktions-, Druck-, Montage- und Integrationshinweise
- `metadata.json`: Parameter und Katalogdaten
- `components.json`: Bounds, Volumen, Flächenzahl, Wasserdichtheit und SHA-256 pro Körper
- `parts/part_XX.stl`: automatisch getrennte, auf den Ursprung verschobene Einzelkörper

## Prüfverfahren

1. OpenSCAD-Quellen wurden zu STL-Druckplatten gerendert.
2. Jede STL wurde mit Trimesh eingelesen, bereinigt und in verbundene Körper zerlegt.
3. Gesamtmesh und Einzelkörper wurden auf Wasserdichtheit, konsistente Orientierung, positives Volumen und degenerierte Flächen geprüft.
4. Die Bounding Box wurde auf Z ≥ −0,03 mm sowie auf einen 220-mm-XY-Prüfbauraum geprüft.
5. Die ermittelte Komponentenanzahl wurde mit der Mechanismusdokumentation verglichen.
6. Jede getrennte STL und jede Druckplatte erhielt einen SHA-256-Hash in den jeweiligen Berichten.
7. Die Release-Struktur wurde zusätzlich mit `tools/validate_library.py` auf 120 Katalogeinträge, 30 Familien, vollständige Pflichtdateien, 284 Einzelteile, OpenCode-Skill und gemeinsame SCAD-Bibliothek geprüft.

## Nicht durch die digitale Abnahme nachgewiesen

- reale Passung auf einem konkreten Drucker, Material und Slicerprofil;
- Einrast-, Auszieh-, Klemm- oder Betätigungskräfte;
- Spiel, Reibung, Verschleiß und Lebensdauer nach wiederholten Zyklen;
- Tragfähigkeit, Stoßfestigkeit, Kriechen, Temperatur- oder Chemikalienbeständigkeit;
- Normkonformität von Gewinden, Zahnrädern, Lagern oder Verbindungselementen;
- Eignung für Personenlasten oder andere sicherheitskritische Anwendungen.

Der physische Prüfablauf ist in `PHYSICAL_TEST_PLAN_DE.md` beschrieben. Vor der Integration sollte pro Mechanikfamilie zunächst die Standard- oder mittlere Variante gedruckt und anschließend die passende Toleranzvariante gewählt werden.

## Reproduzierbarkeit

```bash
python3 tools/generate_sources.py
python3 tools/build_library.py --workers 3
python3 tools/build_contact_sheets.py
python3 tools/validate_library.py
```

Für einen reinen Struktur- und Artefaktcheck ohne erneutes Rendern genügt der letzte Befehl.
