# Katalog — 120 FDM-Mechanikmuster

| ID | Familie | Variante | Kategorie |
|---:|---|---|---|
| 001 | [Versetztes Stiftgelenk](../samples/01_rotation_1d/001-offset-pin-hinge-tight/README.md) | eng | Eindimensionale Drehbewegung |
| 002 | [Versetztes Stiftgelenk](../samples/01_rotation_1d/002-offset-pin-hinge-standard/README.md) | standard | Eindimensionale Drehbewegung |
| 003 | [Versetztes Stiftgelenk](../samples/01_rotation_1d/003-offset-pin-hinge-free/README.md) | leichtgängig | Eindimensionale Drehbewegung |
| 004 | [Versetztes Stiftgelenk](../samples/01_rotation_1d/004-offset-pin-hinge-dirty/README.md) | schmutztolerant | Eindimensionale Drehbewegung |
| 005 | [Print-in-Place-Flachdrehgelenk](../samples/01_rotation_1d/005-print-in-place-pivot-020/README.md) | 0,20 mm | Eindimensionale Drehbewegung |
| 006 | [Print-in-Place-Flachdrehgelenk](../samples/01_rotation_1d/006-print-in-place-pivot-025/README.md) | 0,25 mm | Eindimensionale Drehbewegung |
| 007 | [Print-in-Place-Flachdrehgelenk](../samples/01_rotation_1d/007-print-in-place-pivot-030/README.md) | 0,30 mm | Eindimensionale Drehbewegung |
| 008 | [Print-in-Place-Flachdrehgelenk](../samples/01_rotation_1d/008-print-in-place-pivot-040/README.md) | 0,40 mm | Eindimensionale Drehbewegung |
| 009 | [Dünnsteg-Festkörpergelenk](../samples/01_rotation_1d/009-thin-section-flexure-hinge-soft/README.md) | weich 0,6 mm | Eindimensionale Drehbewegung |
| 010 | [Dünnsteg-Festkörpergelenk](../samples/01_rotation_1d/010-thin-section-flexure-hinge-balanced/README.md) | ausgewogen 0,8 mm | Eindimensionale Drehbewegung |
| 011 | [Dünnsteg-Festkörpergelenk](../samples/01_rotation_1d/011-thin-section-flexure-hinge-stiff/README.md) | steif 1,0 mm | Eindimensionale Drehbewegung |
| 012 | [Dünnsteg-Festkörpergelenk](../samples/01_rotation_1d/012-thin-section-flexure-hinge-heavy/README.md) | kräftig 1,2 mm | Eindimensionale Drehbewegung |
| 013 | [Serpentinen-Filmgelenk](../samples/01_rotation_1d/013-serpentine-living-hinge-080/README.md) | 0,8 mm Bahn | Eindimensionale Drehbewegung |
| 014 | [Serpentinen-Filmgelenk](../samples/01_rotation_1d/014-serpentine-living-hinge-100/README.md) | 1,0 mm Bahn | Eindimensionale Drehbewegung |
| 015 | [Serpentinen-Filmgelenk](../samples/01_rotation_1d/015-serpentine-living-hinge-120/README.md) | 1,2 mm Bahn | Eindimensionale Drehbewegung |
| 016 | [Serpentinen-Filmgelenk](../samples/01_rotation_1d/016-serpentine-living-hinge-150/README.md) | 1,5 mm Bahn | Eindimensionale Drehbewegung |
| 017 | [Schnapp-Kardangelenk](../samples/02_movement_2d/017-snap-universal-joint-tight/README.md) | eng | Zweiachsige Bewegung |
| 018 | [Schnapp-Kardangelenk](../samples/02_movement_2d/018-snap-universal-joint-standard/README.md) | standard | Zweiachsige Bewegung |
| 019 | [Schnapp-Kardangelenk](../samples/02_movement_2d/019-snap-universal-joint-free/README.md) | leichtgängig | Zweiachsige Bewegung |
| 020 | [Schnapp-Kardangelenk](../samples/02_movement_2d/020-snap-universal-joint-loose/README.md) | großzügig | Zweiachsige Bewegung |
| 021 | [Zweiachsiger Gimbal mit Stiften](../samples/02_movement_2d/021-pinned-gimbal-tight/README.md) | eng | Zweiachsige Bewegung |
| 022 | [Zweiachsiger Gimbal mit Stiften](../samples/02_movement_2d/022-pinned-gimbal-standard/README.md) | standard | Zweiachsige Bewegung |
| 023 | [Zweiachsiger Gimbal mit Stiften](../samples/02_movement_2d/023-pinned-gimbal-free/README.md) | leichtgängig | Zweiachsige Bewegung |
| 024 | [Zweiachsiger Gimbal mit Stiften](../samples/02_movement_2d/024-pinned-gimbal-loose/README.md) | großzügig | Zweiachsige Bewegung |
| 025 | [XY-Festkörpertisch](../samples/02_movement_2d/025-xy-flexure-stage-soft/README.md) | weich 0,8 mm | Zweiachsige Bewegung |
| 026 | [XY-Festkörpertisch](../samples/02_movement_2d/026-xy-flexure-stage-balanced/README.md) | ausgewogen 1,0 mm | Zweiachsige Bewegung |
| 027 | [XY-Festkörpertisch](../samples/02_movement_2d/027-xy-flexure-stage-stiff/README.md) | steif 1,2 mm | Zweiachsige Bewegung |
| 028 | [XY-Festkörpertisch](../samples/02_movement_2d/028-xy-flexure-stage-heavy/README.md) | kräftig 1,5 mm | Zweiachsige Bewegung |
| 029 | [Geschlitztes Schnapp-Kugelgelenk](../samples/03_ball_joints/029-slotted-snap-ball-joint-tight/README.md) | eng | Kugelgelenke |
| 030 | [Geschlitztes Schnapp-Kugelgelenk](../samples/03_ball_joints/030-slotted-snap-ball-joint-standard/README.md) | standard | Kugelgelenke |
| 031 | [Geschlitztes Schnapp-Kugelgelenk](../samples/03_ball_joints/031-slotted-snap-ball-joint-free/README.md) | leichtgängig | Kugelgelenke |
| 032 | [Geschlitztes Schnapp-Kugelgelenk](../samples/03_ball_joints/032-slotted-snap-ball-joint-loose/README.md) | großzügig | Kugelgelenke |
| 033 | [Geteilte Klemm-Kugelpfanne](../samples/03_ball_joints/033-split-clamp-ball-joint-d12/README.md) | Kugel 12 mm | Kugelgelenke |
| 034 | [Geteilte Klemm-Kugelpfanne](../samples/03_ball_joints/034-split-clamp-ball-joint-d14/README.md) | Kugel 14 mm | Kugelgelenke |
| 035 | [Geteilte Klemm-Kugelpfanne](../samples/03_ball_joints/035-split-clamp-ball-joint-d16/README.md) | Kugel 16 mm | Kugelgelenke |
| 036 | [Geteilte Klemm-Kugelpfanne](../samples/03_ball_joints/036-split-clamp-ball-joint-d20/README.md) | Kugel 20 mm | Kugelgelenke |
| 037 | [Dauerhafter Pressstift](../samples/04_permanent_connections/037-press-fit-dowel-i015/README.md) | 0,15 mm Übermaß | Dauerhafte Steck- und Schiebverbindungen |
| 038 | [Dauerhafter Pressstift](../samples/04_permanent_connections/038-press-fit-dowel-i005/README.md) | 0,05 mm Übermaß | Dauerhafte Steck- und Schiebverbindungen |
| 039 | [Dauerhafter Pressstift](../samples/04_permanent_connections/039-press-fit-dowel-line/README.md) | Nennmaß | Dauerhafte Steck- und Schiebverbindungen |
| 040 | [Dauerhafter Pressstift](../samples/04_permanent_connections/040-press-fit-dowel-g010/README.md) | 0,10 mm Spiel | Dauerhafte Steck- und Schiebverbindungen |
| 041 | [Verdrehsichere Schlüssel-Steckverbindung](../samples/04_permanent_connections/041-keyed-plug-socket-015/README.md) | 0,15 mm | Dauerhafte Steck- und Schiebverbindungen |
| 042 | [Verdrehsichere Schlüssel-Steckverbindung](../samples/04_permanent_connections/042-keyed-plug-socket-025/README.md) | 0,25 mm | Dauerhafte Steck- und Schiebverbindungen |
| 043 | [Verdrehsichere Schlüssel-Steckverbindung](../samples/04_permanent_connections/043-keyed-plug-socket-035/README.md) | 0,35 mm | Dauerhafte Steck- und Schiebverbindungen |
| 044 | [Verdrehsichere Schlüssel-Steckverbindung](../samples/04_permanent_connections/044-keyed-plug-socket-045/README.md) | 0,45 mm | Dauerhafte Steck- und Schiebverbindungen |
| 045 | [Einweg-Steckverbinder mit Widerhaken](../samples/04_permanent_connections/045-barbed-one-way-connector-015/README.md) | 0,15 mm | Dauerhafte Steck- und Schiebverbindungen |
| 046 | [Einweg-Steckverbinder mit Widerhaken](../samples/04_permanent_connections/046-barbed-one-way-connector-025/README.md) | 0,25 mm | Dauerhafte Steck- und Schiebverbindungen |
| 047 | [Einweg-Steckverbinder mit Widerhaken](../samples/04_permanent_connections/047-barbed-one-way-connector-035/README.md) | 0,35 mm | Dauerhafte Steck- und Schiebverbindungen |
| 048 | [Einweg-Steckverbinder mit Widerhaken](../samples/04_permanent_connections/048-barbed-one-way-connector-045/README.md) | 0,45 mm | Dauerhafte Steck- und Schiebverbindungen |
| 049 | [Schwalbenschwanz-Verbinder](../samples/04_permanent_connections/049-dovetail-joiner-interference/README.md) | leichte Interferenz | Dauerhafte Steck- und Schiebverbindungen |
| 050 | [Schwalbenschwanz-Verbinder](../samples/04_permanent_connections/050-dovetail-joiner-tight/README.md) | eng 0,10 mm | Dauerhafte Steck- und Schiebverbindungen |
| 051 | [Schwalbenschwanz-Verbinder](../samples/04_permanent_connections/051-dovetail-joiner-standard/README.md) | standard 0,20 mm | Dauerhafte Steck- und Schiebverbindungen |
| 052 | [Schwalbenschwanz-Verbinder](../samples/04_permanent_connections/052-dovetail-joiner-free/README.md) | leichtgängig 0,35 mm | Dauerhafte Steck- und Schiebverbindungen |
| 053 | [Nut-Feder-Verbindung mit Querkeil](../samples/04_permanent_connections/053-transverse-wedge-lock-015/README.md) | 0,15 mm | Dauerhafte Steck- und Schiebverbindungen |
| 054 | [Nut-Feder-Verbindung mit Querkeil](../samples/04_permanent_connections/054-transverse-wedge-lock-025/README.md) | 0,25 mm | Dauerhafte Steck- und Schiebverbindungen |
| 055 | [Nut-Feder-Verbindung mit Querkeil](../samples/04_permanent_connections/055-transverse-wedge-lock-035/README.md) | 0,35 mm | Dauerhafte Steck- und Schiebverbindungen |
| 056 | [Nut-Feder-Verbindung mit Querkeil](../samples/04_permanent_connections/056-transverse-wedge-lock-045/README.md) | 0,45 mm | Dauerhafte Steck- und Schiebverbindungen |
| 057 | [Schraubdom mit seitlicher Muttertasche](../samples/05_screw_connections/057-captured-nut-screw-boss-m25/README.md) | M2,5 | Schraubverbindungen |
| 058 | [Schraubdom mit seitlicher Muttertasche](../samples/05_screw_connections/058-captured-nut-screw-boss-m3/README.md) | M3 | Schraubverbindungen |
| 059 | [Schraubdom mit seitlicher Muttertasche](../samples/05_screw_connections/059-captured-nut-screw-boss-m4/README.md) | M4 | Schraubverbindungen |
| 060 | [Schraubdom mit seitlicher Muttertasche](../samples/05_screw_connections/060-captured-nut-screw-boss-m5/README.md) | M5 | Schraubverbindungen |
| 061 | [Heizeinsatz-Schraubprobe](../samples/05_screw_connections/061-heat-set-insert-coupon-m2/README.md) | M2 | Schraubverbindungen |
| 062 | [Heizeinsatz-Schraubprobe](../samples/05_screw_connections/062-heat-set-insert-coupon-m25/README.md) | M2,5 | Schraubverbindungen |
| 063 | [Heizeinsatz-Schraubprobe](../samples/05_screw_connections/063-heat-set-insert-coupon-m3/README.md) | M3 | Schraubverbindungen |
| 064 | [Heizeinsatz-Schraubprobe](../samples/05_screw_connections/064-heat-set-insert-coupon-m4/README.md) | M4 | Schraubverbindungen |
| 065 | [Grobgewinde aus dem Drucker](../samples/05_screw_connections/065-coarse-printed-thread-d12/README.md) | Ø 12 / P 2,5 | Schraubverbindungen |
| 066 | [Grobgewinde aus dem Drucker](../samples/05_screw_connections/066-coarse-printed-thread-d16/README.md) | Ø 16 / P 3 | Schraubverbindungen |
| 067 | [Grobgewinde aus dem Drucker](../samples/05_screw_connections/067-coarse-printed-thread-d20/README.md) | Ø 20 / P 4 | Schraubverbindungen |
| 068 | [Grobgewinde aus dem Drucker](../samples/05_screw_connections/068-coarse-printed-thread-d24/README.md) | Ø 24 / P 5 | Schraubverbindungen |
| 069 | [Wiederlösbarer Kragarm-Schnapper](../samples/06_reusable_closures/069-cantilever-snap-latch-soft/README.md) | weich 0,8 mm | Periodisch lösbare Verschlüsse |
| 070 | [Wiederlösbarer Kragarm-Schnapper](../samples/06_reusable_closures/070-cantilever-snap-latch-balanced/README.md) | ausgewogen 1,0 mm | Periodisch lösbare Verschlüsse |
| 071 | [Wiederlösbarer Kragarm-Schnapper](../samples/06_reusable_closures/071-cantilever-snap-latch-standard/README.md) | standard 1,2 mm | Periodisch lösbare Verschlüsse |
| 072 | [Wiederlösbarer Kragarm-Schnapper](../samples/06_reusable_closures/072-cantilever-snap-latch-heavy/README.md) | kräftig 1,5 mm | Periodisch lösbare Verschlüsse |
| 073 | [Drehhakenverschluss](../samples/06_reusable_closures/073-rotating-hook-latch-015/README.md) | 0,15 mm | Periodisch lösbare Verschlüsse |
| 074 | [Drehhakenverschluss](../samples/06_reusable_closures/074-rotating-hook-latch-025/README.md) | 0,25 mm | Periodisch lösbare Verschlüsse |
| 075 | [Drehhakenverschluss](../samples/06_reusable_closures/075-rotating-hook-latch-035/README.md) | 0,35 mm | Periodisch lösbare Verschlüsse |
| 076 | [Drehhakenverschluss](../samples/06_reusable_closures/076-rotating-hook-latch-045/README.md) | 0,45 mm | Periodisch lösbare Verschlüsse |
| 077 | [Bajonett-Vierteldrehverschluss](../samples/06_reusable_closures/077-bayonet-quarter-turn-020/README.md) | 0,20 mm | Periodisch lösbare Verschlüsse |
| 078 | [Bajonett-Vierteldrehverschluss](../samples/06_reusable_closures/078-bayonet-quarter-turn-030/README.md) | 0,30 mm | Periodisch lösbare Verschlüsse |
| 079 | [Bajonett-Vierteldrehverschluss](../samples/06_reusable_closures/079-bayonet-quarter-turn-040/README.md) | 0,40 mm | Periodisch lösbare Verschlüsse |
| 080 | [Bajonett-Vierteldrehverschluss](../samples/06_reusable_closures/080-bayonet-quarter-turn-050/README.md) | 0,50 mm | Periodisch lösbare Verschlüsse |
| 081 | [Linearer Schubriegel](../samples/06_reusable_closures/081-sliding-bolt-latch-015/README.md) | 0,15 mm | Periodisch lösbare Verschlüsse |
| 082 | [Linearer Schubriegel](../samples/06_reusable_closures/082-sliding-bolt-latch-025/README.md) | 0,25 mm | Periodisch lösbare Verschlüsse |
| 083 | [Linearer Schubriegel](../samples/06_reusable_closures/083-sliding-bolt-latch-035/README.md) | 0,35 mm | Periodisch lösbare Verschlüsse |
| 084 | [Linearer Schubriegel](../samples/06_reusable_closures/084-sliding-bolt-latch-045/README.md) | 0,45 mm | Periodisch lösbare Verschlüsse |
| 085 | [Schwalbenschwanz-Linearführung](../samples/07_linear_motion/085-dovetail-linear-rail-020/README.md) | 0,20 mm | Periodische Linearbewegung |
| 086 | [Schwalbenschwanz-Linearführung](../samples/07_linear_motion/086-dovetail-linear-rail-030/README.md) | 0,30 mm | Periodische Linearbewegung |
| 087 | [Schwalbenschwanz-Linearführung](../samples/07_linear_motion/087-dovetail-linear-rail-040/README.md) | 0,40 mm | Periodische Linearbewegung |
| 088 | [Schwalbenschwanz-Linearführung](../samples/07_linear_motion/088-dovetail-linear-rail-050/README.md) | 0,50 mm | Periodische Linearbewegung |
| 089 | [Pilzkopf-/T-Linearführung](../samples/07_linear_motion/089-mushroom-t-linear-rail-020/README.md) | 0,20 mm | Periodische Linearbewegung |
| 090 | [Pilzkopf-/T-Linearführung](../samples/07_linear_motion/090-mushroom-t-linear-rail-030/README.md) | 0,30 mm | Periodische Linearbewegung |
| 091 | [Pilzkopf-/T-Linearführung](../samples/07_linear_motion/091-mushroom-t-linear-rail-040/README.md) | 0,40 mm | Periodische Linearbewegung |
| 092 | [Pilzkopf-/T-Linearführung](../samples/07_linear_motion/092-mushroom-t-linear-rail-050/README.md) | 0,50 mm | Periodische Linearbewegung |
| 093 | [Vorgespannter Feder-Schlitten](../samples/07_linear_motion/093-compliant-preload-slider-soft/README.md) | weich | Periodische Linearbewegung |
| 094 | [Vorgespannter Feder-Schlitten](../samples/07_linear_motion/094-compliant-preload-slider-balanced/README.md) | ausgewogen | Periodische Linearbewegung |
| 095 | [Vorgespannter Feder-Schlitten](../samples/07_linear_motion/095-compliant-preload-slider-stiff/README.md) | steif | Periodische Linearbewegung |
| 096 | [Vorgespannter Feder-Schlitten](../samples/07_linear_motion/096-compliant-preload-slider-rugged/README.md) | robust | Periodische Linearbewegung |
| 097 | [Zahnstange und Ritzel](../samples/08_drives_and_components/097-rack-and-pinion-m125/README.md) | Modul 1,25 | Antriebe und weitere Mechanik |
| 098 | [Zahnstange und Ritzel](../samples/08_drives_and_components/098-rack-and-pinion-m150/README.md) | Modul 1,50 | Antriebe und weitere Mechanik |
| 099 | [Zahnstange und Ritzel](../samples/08_drives_and_components/099-rack-and-pinion-m175/README.md) | Modul 1,75 | Antriebe und weitere Mechanik |
| 100 | [Zahnstange und Ritzel](../samples/08_drives_and_components/100-rack-and-pinion-m200/README.md) | Modul 2,00 | Antriebe und weitere Mechanik |
| 101 | [Stirnradpaar auf Stiftbasis](../samples/08_drives_and_components/101-spur-gear-pair-1to1/README.md) | 1:1 | Antriebe und weitere Mechanik |
| 102 | [Stirnradpaar auf Stiftbasis](../samples/08_drives_and_components/102-spur-gear-pair-14to22/README.md) | 14:22 | Antriebe und weitere Mechanik |
| 103 | [Stirnradpaar auf Stiftbasis](../samples/08_drives_and_components/103-spur-gear-pair-12to24/README.md) | 1:2 | Antriebe und weitere Mechanik |
| 104 | [Stirnradpaar auf Stiftbasis](../samples/08_drives_and_components/104-spur-gear-pair-10to30/README.md) | 1:3 | Antriebe und weitere Mechanik |
| 105 | [Dreh-Rastindexierung](../samples/08_drives_and_components/105-rotary-detent-indexer-n8/README.md) | 8 Positionen | Antriebe und weitere Mechanik |
| 106 | [Dreh-Rastindexierung](../samples/08_drives_and_components/106-rotary-detent-indexer-n12/README.md) | 12 Positionen | Antriebe und weitere Mechanik |
| 107 | [Dreh-Rastindexierung](../samples/08_drives_and_components/107-rotary-detent-indexer-n16/README.md) | 16 Positionen | Antriebe und weitere Mechanik |
| 108 | [Dreh-Rastindexierung](../samples/08_drives_and_components/108-rotary-detent-indexer-n24/README.md) | 24 Positionen | Antriebe und weitere Mechanik |
| 109 | [Geteilte Wellen-Klemmkupplung](../samples/08_drives_and_components/109-split-shaft-coupler-d4/README.md) | 4-mm-Welle | Antriebe und weitere Mechanik |
| 110 | [Geteilte Wellen-Klemmkupplung](../samples/08_drives_and_components/110-split-shaft-coupler-d5/README.md) | 5-mm-Welle | Antriebe und weitere Mechanik |
| 111 | [Geteilte Wellen-Klemmkupplung](../samples/08_drives_and_components/111-split-shaft-coupler-d6/README.md) | 6-mm-Welle | Antriebe und weitere Mechanik |
| 112 | [Geteilte Wellen-Klemmkupplung](../samples/08_drives_and_components/112-split-shaft-coupler-d8/README.md) | 8-mm-Welle | Antriebe und weitere Mechanik |
| 113 | [Wiederlösbarer Kabel-Schnappclip](../samples/08_drives_and_components/113-reusable-cable-clip-d4/README.md) | Kabel 4 mm | Antriebe und weitere Mechanik |
| 114 | [Wiederlösbarer Kabel-Schnappclip](../samples/08_drives_and_components/114-reusable-cable-clip-d6/README.md) | Kabel 6 mm | Antriebe und weitere Mechanik |
| 115 | [Wiederlösbarer Kabel-Schnappclip](../samples/08_drives_and_components/115-reusable-cable-clip-d8/README.md) | Kabel 8 mm | Antriebe und weitere Mechanik |
| 116 | [Wiederlösbarer Kabel-Schnappclip](../samples/08_drives_and_components/116-reusable-cable-clip-d10/README.md) | Kabel 10 mm | Antriebe und weitere Mechanik |
| 117 | [Umlenkrollen-Block](../samples/08_drives_and_components/117-pulley-block-small/README.md) | 24 mm / Seil 2 mm | Antriebe und weitere Mechanik |
| 118 | [Umlenkrollen-Block](../samples/08_drives_and_components/118-pulley-block-medium/README.md) | 28 mm / Seil 3 mm | Antriebe und weitere Mechanik |
| 119 | [Umlenkrollen-Block](../samples/08_drives_and_components/119-pulley-block-large/README.md) | 34 mm / Seil 4 mm | Antriebe und weitere Mechanik |
| 120 | [Umlenkrollen-Block](../samples/08_drives_and_components/120-pulley-block-xlarge/README.md) | 40 mm / Seil 5 mm | Antriebe und weitere Mechanik |
