# 090 — Pilzkopf-/T-Linearführung

**Variante:** 0,30 mm  
**Kategorie:** Periodische Linearbewegung  
**Mechanikfamilie:** `mushroom-t-linear-rail`

![Vorschau](preview.png)

## Prinzip

Ein Pilzkopfprofil hält den Schlitten gegen Abheben und bietet breite horizontale Führungsflächen.

## Typische Verwendung

Schiebedeckel, leichte Schlitten und wechselbare Module.

## Enthaltene Dateien

- `model.scad` — parametrische OpenSCAD-Quelle
- `print_plate.stl` — druckfertige Anordnung aller Körper
- `preview.png` — Explosions-/Montagevorschau
- `parts/part_XX.stl` — automatisch getrennte Einzelkörper für CAD-Import
- `components.json` — Abmessungen und ursprüngliche Position jeder Komponente
- `metadata.json` — maschinenlesbare Dokumentation

Vorgesehene Komponenten:

- T-Schiene
- T-Schlitten

## Parameter dieser Variante

- `clearance`: `0.3`
- `length`: `70`
- `carriage_l`: `26`

**Variantenhinweis:** Standard.

## FDM-Empfehlung

- Material: PLA, PETG, PA
- Düse: 0.4 mm
- Schichthöhe: 0.2 mm
- Außenlinien: mindestens 4
- Infill: 25 % als Startwert; funktionskritische Bereiche bei Bedarf lokal erhöhen
- Supportbedarf: grundsätzlich gering; die familienspezifischen Hinweise und die eigene Slicer-Vorschau beachten

Flach; 45°-Unterseiten reduzieren Supportbedarf.

## Montage und Nacharbeit

Kanten brechen, einschieben und Reibung über Variante wählen.

## Integration in ein Projekt

Profil an beiden Enden zugänglich lassen oder Schlitten vor dem Verschließen montieren.

## Fremdteile

Kein Fremdteil.

## Grenzen und Sicherheit

Unterzüge sind druckerabhängig; nicht für hohe Biegemomente.

Die Geometrie wurde digital auf geschlossene, positive Volumenkörper geprüft. Sie wurde nicht physisch auf jedem Drucker und Material gedruckt. Vor Lastanwendung zuerst die passende Toleranzvariante testen. Nicht für Personenlasten, Schutzfunktionen oder sonstige sicherheitskritische Anwendungen verwenden.
