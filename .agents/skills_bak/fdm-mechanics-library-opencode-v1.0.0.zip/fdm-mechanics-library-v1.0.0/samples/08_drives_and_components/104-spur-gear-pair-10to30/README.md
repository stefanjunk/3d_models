# 104 — Stirnradpaar auf Stiftbasis

**Variante:** 1:3  
**Kategorie:** Antriebe und weitere Mechanik  
**Mechanikfamilie:** `spur-gear-pair`

![Vorschau](preview.png)

## Prinzip

Zwei flach gedruckte Räder laufen auf vertikalen Stiften und demonstrieren mehrere Übersetzungen.

## Typische Verwendung

Langsame Getriebe, Lernmodelle, Zähler und handbetätigte Mechanik.

## Enthaltene Dateien

- `model.scad` — parametrische OpenSCAD-Quelle
- `print_plate.stl` — druckfertige Anordnung aller Körper
- `preview.png` — Explosions-/Montagevorschau
- `parts/part_XX.stl` — automatisch getrennte Einzelkörper für CAD-Import
- `components.json` — Abmessungen und ursprüngliche Position jeder Komponente
- `metadata.json` — maschinenlesbare Dokumentation

Vorgesehene Komponenten:

- Stiftbasis
- Rad A
- Rad B

## Parameter dieser Variante

- `teeth_a`: `10`
- `teeth_b`: `30`
- `module_size`: `1.5`
- `clearance`: `0.3`

**Variantenhinweis:** Große Übersetzung als Demonstrator.

## FDM-Empfehlung

- Material: PLA, PETG, PA
- Düse: 0.4 mm
- Schichthöhe: 0.2 mm
- Außenlinien: mindestens 4
- Infill: 25 % als Startwert; funktionskritische Bereiche bei Bedarf lokal erhöhen
- Supportbedarf: grundsätzlich gering; die familienspezifischen Hinweise und die eigene Slicer-Vorschau beachten

Räder flach, Basis flach. Zahnnaht nicht auf alle Zähne derselben Flanke legen.

## Montage und Nacharbeit

Zähne entgraten, Räder aufstecken und mit dünner Scheibe sichern.

## Integration in ein Projekt

Achsabstand aus Modul und Zahnzahl übernehmen; Lagerung und Axialsicherung projektspezifisch ergänzen.

## Fremdteile

Kein Fremdteil; optional Metallachsen.

## Grenzen und Sicherheit

Vereinfachte Zahnform; nicht für hohe Leistung, Drehzahl oder exakte Evolventengeometrie.

Die Geometrie wurde digital auf geschlossene, positive Volumenkörper geprüft. Sie wurde nicht physisch auf jedem Drucker und Material gedruckt. Vor Lastanwendung zuerst die passende Toleranzvariante testen. Nicht für Personenlasten, Schutzfunktionen oder sonstige sicherheitskritische Anwendungen verwenden.
