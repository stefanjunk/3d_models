#!/usr/bin/env python3
from __future__ import annotations
import json
from pathlib import Path
from PIL import Image, ImageDraw, ImageFont

ROOT=Path(__file__).resolve().parents[1]
records=json.loads((ROOT/'catalog/catalog.json').read_text(encoding='utf-8'))
font=ImageFont.load_default()

def sheet(items, out, cols=5, thumb=(320,240), label_h=42):
    rows=(len(items)+cols-1)//cols
    canvas=Image.new('RGB',(cols*thumb[0],rows*(thumb[1]+label_h)),(244,246,248))
    draw=ImageDraw.Draw(canvas)
    for idx,r in enumerate(items):
        x=(idx%cols)*thumb[0]; y=(idx//cols)*(thumb[1]+label_h)
        img=Image.open(ROOT/'samples'/r['relative_directory']/'preview.png').convert('RGB')
        img.thumbnail(thumb)
        px=x+(thumb[0]-img.width)//2; py=y+(thumb[1]-img.height)//2
        canvas.paste(img,(px,py))
        label=f"{r['id']}  {r['title_de']}\n{r['variant_label_de']}"
        draw.text((x+7,y+thumb[1]+4),label,fill=(18,28,38),font=font)
    out.parent.mkdir(parents=True,exist_ok=True)
    canvas.save(out,optimize=True)

first=[]
seen=set()
for r in records:
    if r['family_number'] not in seen:
        seen.add(r['family_number']); first.append(r)
sheet(first,ROOT/'catalog/contact-sheet-30-families.png',cols=5)
for category in sorted({r['category'] for r in records}):
    subset=[r for r in records if r['category']==category]
    sheet(subset,ROOT/'catalog'/f'contact-sheet-{category}.png',cols=4,thumb=(300,225),label_h=38)
sheet(records,ROOT/'catalog/contact-sheet-all-120.png',cols=8,thumb=(220,165),label_h=34)
print('contact sheets created')
