#!/usr/bin/env python3
"""Validate release structure and generated artifacts without rebuilding geometry."""
from __future__ import annotations
import argparse, json, hashlib
from pathlib import Path

ROOT=Path(__file__).resolve().parents[1]

def sha(path: Path) -> str:
    h=hashlib.sha256()
    with path.open('rb') as f:
        for chunk in iter(lambda:f.read(1024*1024),b''): h.update(chunk)
    return h.hexdigest()

def main() -> int:
    p=argparse.ArgumentParser(); p.add_argument('--report',default='validation/library-validation.json'); a=p.parse_args()
    records=json.loads((ROOT/'catalog/catalog.json').read_text(encoding='utf-8'))
    build=json.loads((ROOT/'validation/build-summary.json').read_text(encoding='utf-8'))
    errors=[]; samples=[]
    required=['model.scad','print_plate.stl','preview.png','README.md','metadata.json','components.json']
    for r in records:
        d=ROOT/'samples'/r['relative_directory']
        missing=[name for name in required if not (d/name).is_file()]
        parts=sorted((d/'parts').glob('part_*.stl')) if (d/'parts').is_dir() else []
        comp=json.loads((d/'components.json').read_text(encoding='utf-8')) if (d/'components.json').is_file() else {}
        ok=not missing and len(parts)==comp.get('combined',{}).get('components') and all(x.get('watertight') for x in comp.get('components',[]))
        if not ok: errors.append({'id':r['id'],'missing':missing,'part_files':len(parts),'component_count':comp.get('combined',{}).get('components')})
        samples.append({'id':r['id'],'ok':ok,'parts':len(parts)})
    checks={
        'catalog_has_120_samples':len(records)==120,
        'catalog_has_30_families':len({r['family_number'] for r in records})==30,
        'build_summary_has_120_passed':build.get('passed')==120 and build.get('warning')==0 and build.get('failed')==0,
        'all_sample_files_complete':not errors,
        'opencode_skill_present':(ROOT/'.opencode/skills/fdm-mechanical-sample-library/SKILL.md').is_file(),
        'shared_scad_library_present':(ROOT/'library/fdm_mechanisms.scad').is_file(),
    }
    report={'root':str(ROOT),'checks':checks,'passed':all(checks.values()),'errors':errors,'sample_count':len(records),'part_stl_count':sum(x['parts'] for x in samples),'samples':samples}
    out=ROOT/a.report; out.parent.mkdir(parents=True,exist_ok=True); out.write_text(json.dumps(report,ensure_ascii=False,indent=2),encoding='utf-8')
    print(json.dumps({**checks,'part_stl_count':report['part_stl_count'],'passed':report['passed']},ensure_ascii=False,indent=2))
    return 0 if report['passed'] else 1
if __name__=='__main__': raise SystemExit(main())
