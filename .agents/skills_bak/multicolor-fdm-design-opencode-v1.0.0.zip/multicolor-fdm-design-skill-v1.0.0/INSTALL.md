# Installation

## Project-local

```bash
./install.sh --project /absolute/path/to/project
```

This copies:

- `.opencode/skills/multicolor-fdm-design`
- `.opencode/commands/design-multicolor-fdm.md`

Existing files are not overwritten unless `--force` is supplied.

## Global skill

```bash
./install.sh --global
```

Default destination:

```text
~/.config/opencode/skills/multicolor-fdm-design
```

## Python dependencies

```bash
python3 -m pip install -r requirements.txt
```

Core scripts use NumPy, Pillow, PyYAML, jsonschema, Trimesh, SciPy, scikit-image, and matplotlib. OpenSCAD is optional but required to rebuild the first two examples. Blender and slicer GUIs remain external applications and are not installed by this package.
