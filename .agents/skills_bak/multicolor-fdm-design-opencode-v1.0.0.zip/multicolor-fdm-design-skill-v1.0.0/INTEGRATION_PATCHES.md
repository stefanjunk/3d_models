# Suggested non-destructive integration patches

The uploaded existing skills were treated as references; this package does not overwrite them. Apply these small routing additions in their source repositories.

## functional-3d-design

Add under specialist routing:

> Load `multicolor-fdm-design` when filament color affects geometry, part decomposition, 3MF output, texture conversion, purge waste, or a multi-filament accessory. Keep function, material suitability, tolerances, orientation, and physical safety here; delegate color architecture and multicolor validation.

## organic-mesh-functionalization

Add under companion routing:

> After immutable-source preservation, repair, and functional edits are complete, load `multicolor-fdm-design` to convert UV textures, vertex colors, or source materials into printable filament regions. Color conversion must remain a derived artifact and must not overwrite the authoritative mesh/texture.

## parametric-freeform-surfacing

Add:

> Freeze or validate the envelope and tessellation before generating color partitions. Multicolor regions may follow semantic panels, rails, section coordinates, or UV fields, but color operations must not silently move exact hardpoints.

## 3d-print-heightmap-relief

Add:

> Route to `multicolor-fdm-design` when an image should also control filament color. Continuous grayscale relief remains depth data; the printable color image is a separate fixed-palette derivative with its own resolution and validation.
