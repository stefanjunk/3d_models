# Skill für Mehrfarben-FDM-Druck

Dieses Paket ergänzt die vorhandene 3D-Design-Skill-Familie um einen eigenständigen Spezialisten für Mehrfarbendruck.

Enthalten sind:

- Best Practices für parametrische Farbsolids, Inlays, Schalen, Einsätze und Schichtwechsel;
- ein vollständiger Workflow für texturierte OBJ/GLB-Dateien;
- Quantisierung auf die tatsächlich vorhandenen Filamentfarben;
- schneller GUI-Weg über Bambu Studio Texture-to-Color Painting mit Pflichtprüfung in Anycubic Slicer Next;
- automatischer, portabler Fallback über Voxel-Farbpartitionen und standardkonformes Mehrteil-3MF;
- Purge-/Farbwechselplanung;
- Referenzen, Schemas, Skripte, Tests und drei gebaute Beispiele.

Schnelltest:

```bash
python3 .opencode/skills/multicolor-fdm-design/scripts/validate_skill.py
python3 -m unittest discover -s .opencode/skills/multicolor-fdm-design/tests -v
```

Die bereits erzeugten Beispielausgaben liegen unter `generated/examples/`.
