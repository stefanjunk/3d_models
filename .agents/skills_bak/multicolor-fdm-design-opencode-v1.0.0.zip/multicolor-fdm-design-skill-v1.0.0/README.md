# Multicolor FDM Design for OpenCode

A standalone specialist skill for **designing, converting, validating, and optimizing multicolor single-nozzle FDM/FFF models**.

It follows the existing 3D-design family’s source-first and validation-first structure: concise `SKILL.md`, detailed references loaded on demand, machine-readable templates/schema, deterministic helper scripts, three worked examples, tests, generated evidence, installation helpers, and routing patches.

## What it adds

- semantic color architecture for parametric CAD;
- layer-band, inlay, shell, insert, and separate-solid methods;
- real-filament palette capture and CIEDE2000 texture quantization;
- textured OBJ/glTF/GLB inspection;
- documented Bambu Studio Texture-to-Color Painting → Anycubic Slicer Next handoff;
- portable fallback: texture → voxel shell partitions → aligned color solids → standard 3MF assembly;
- directed purge matrices and change-count estimation;
- multicolor geometry, 3MF, slicer, and coupon validation;
- three built examples with source, STLs, previews, reports, and 3MF files.

## Install

Project-local:

```bash
./install.sh --project /absolute/path/to/project
```

Global skill only:

```bash
./install.sh --global
```

## Verify

```bash
python3 .opencode/skills/multicolor-fdm-design/scripts/validate_skill.py
python3 -m unittest discover \
  -s .opencode/skills/multicolor-fdm-design/tests -v
python3 .opencode/skills/multicolor-fdm-design/scripts/build_examples.py \
  --output-root generated/examples
```

## Package map

```text
.opencode/
├── commands/design-multicolor-fdm.md
└── skills/multicolor-fdm-design/
    ├── SKILL.md
    ├── assets/
    │   ├── schemas/
    │   └── templates/
    ├── references/
    ├── scripts/
    ├── examples/
    └── tests/
generated/examples/                 # built evidence
ROUTING_ADDENDUM.md
INTEGRATION_PATCHES.md
VALIDATION.md
```

## Important interoperability policy

A standard 3MF with explicit aligned color solids is the portable design artifact. A slicer-project 3MF can additionally contain private paint, profile, and purge metadata; it must be verified in the destination slicer and is not assumed to transfer identically between applications.
