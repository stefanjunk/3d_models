# Routing addendum for the existing 3D-design skill family

Add this specialist as a separate MECE module.

| Module | Owns | Does not own |
|---|---|---|
| Functional design | requirements, mechanics, interfaces, tolerances, materials, assemblies, base print configuration | multicolor decomposition and texture conversion |
| Parametric freeform surfacing | fair curves, editable envelopes, NURBS/lofts/SubD/FFD, hardpoint preservation | color-part architecture and purge planning |
| Organic mesh functionalization | immutable source, ROI/protected/transition/keep-out planning, repair and functional edits | palette reduction and multicolor 3MF handoff |
| Height-map relief | image-to-depth sampling and mapping | filament-color quantization |
| Multicolor FDM design | semantic filament regions, real-filament palettes, parametric inlays/solids, texture-to-color conversion, multi-part 3MF, purge/change optimization, final color validation | underlying mechanical design, protected mesh edits, freeform envelope construction, image-to-depth relief |

## New product sequence

```text
functional contract and hardpoints
→ exact/freeform geometry and print split
→ optional relief
→ multicolor architecture
→ standard 3MF and destination-slicer mapping
→ purge/change and physical validation
```

## Existing textured asset sequence

```text
organic-mesh preservation contract
→ repair and functional edits
→ normalized/baked printable texture
→ actual-filament palette quantization
→ texture painting handoff or explicit solid partitions
→ 3MF/slicer validation
```
