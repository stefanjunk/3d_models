# Package validation

Validation executed on **2026-08-20** in the provided container.

## Environment

- Python 3.13.5
- OpenSCAD CLI available
- NumPy 2.3.5
- Pillow 12.3.0
- PyYAML 6.0.3
- jsonschema 4.26.0
- Trimesh 4.11.1
- SciPy 1.17.0
- scikit-image 0.26.0
- matplotlib available for deterministic previews

Machine-readable details: `validation/environment.json`.

## Skill/package checks

`validate_skill.py` passed:

- valid OpenCode frontmatter;
- `name: multicolor-fdm-design` matches the directory;
- required references, schemas, templates, scripts, tests, and examples exist;
- all Python helpers compile;
- the supplied `multicolor-job.yaml` validates against the JSON schema.

Evidence:

- `validation/skill-validation.json`
- `validation/skill-validation.stdout.txt`

A project-local installation into a temporary project also passed skill validation. Evidence: `validation/install-smoke.txt`.

## Automated tests

**6/6 tests passed.** Coverage includes:

- exact fixed-palette mapping and CIEDE2000 path;
- small-island cleanup;
- standards-based two-part 3MF write/parse/validation round trip;
- job-template schema validation;
- skill frontmatter and three-example structure.

Evidence: `validation/unittest.txt`.

## Three worked example builds

All three examples were rebuilt from source and their 3MF packages passed the included structural and mesh validation.

| Example | Color parts | All mesh parts watertight | 3MF assembly valid |
|---|---:|---:|---:|
| Parametric inlay nameplate | 4 | yes | yes |
| Four-color fox badge | 4 | yes | yes |
| Textured OBJ to four-color 3MF | 4 | yes | yes |

The first two examples were generated with OpenSCAD and exported as aligned semantic solids. The third generated a UV-textured OBJ and GLB, quantized the texture, created a filled voxel shell partition, remeshed four color volumes, and packaged them as one component assembly.

Evidence:

- `validation/examples-summary.json`
- `validation/examples-build.stdout.txt`
- `generated/examples/*/3mf-validation.json`
- `generated/examples/*/change-budget.json`
- `generated/examples/*/preview.png`

## OBJ and GLB texture conversion

The generated GLB was independently inspected:

- one textured geometry;
- 260 UV coordinates;
- embedded 512×256 RGB base-color image.

A separate coarse GLB conversion produced **four watertight color meshes**. Evidence:

- `validation/glb-inspection.json`
- `validation/glb-conversion.json`
- `validation/glb-parts/`

## 3MF implementation scope

The included writer uses a deliberately portable Core subset:

- millimetre units;
- one base-material entry per semantic filament;
- one mesh object per color;
- a component assembly preserving relative placement;
- a build item referencing that assembly;
- standard OPC relationships/content types;
- optional PNG thumbnail.

The validator checks package members, XML, IDs, material references, component references, triangle indices, and reconstructed mesh topology.

## Limitations and human acceptance gates

The following were **not** available or not executed in the container:

- Blender GUI baking and manual source repair;
- Bambu Studio 2.7 Texture-to-Color Painting;
- Anycubic Slicer Next import and ACE slot assignment;
- Lib3MF/3MF Consortium conformance suite;
- a physical multicolor print, purge coupon, opacity coupon, or dimensional coupon.

Consequently:

- cross-slicer painted-project transfer remains a mandatory manual verification step;
- the generated standard 3MF conveys semantic material intent and display colors, but physical ACE/AMS/MMU slot mapping must be assigned in the destination slicer;
- the voxel converter is a validated workflow implementation, but production pitch/shell depth must be chosen for the actual model, nozzle, memory budget, and acceptable surface deviation;
- purge estimates are comparative planning values; the destination slicer and a physical directed-transition coupon remain authoritative.
