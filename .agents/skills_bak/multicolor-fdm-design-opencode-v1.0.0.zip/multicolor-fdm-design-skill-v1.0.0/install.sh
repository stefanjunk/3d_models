#!/usr/bin/env bash
set -euo pipefail
ROOT="$(cd "$(dirname "${BASH_SOURCE[0]}")" && pwd)"
FORCE=0
MODE=""
TARGET=""
while [[ $# -gt 0 ]]; do
  case "$1" in
    --project) MODE=project; TARGET="$2"; shift 2 ;;
    --global) MODE=global; TARGET="${HOME}/.config/opencode"; shift ;;
    --force) FORCE=1; shift ;;
    *) echo "Unknown argument: $1" >&2; exit 2 ;;
  esac
done
if [[ -z "$MODE" ]]; then
  echo "Usage: $0 --project /path/to/project [--force] | --global [--force]" >&2
  exit 2
fi
copy_tree() {
  local src="$1" dst="$2"
  mkdir -p "$(dirname "$dst")"
  if [[ -e "$dst" && "$FORCE" -ne 1 ]]; then
    echo "Refusing to overwrite existing: $dst (use --force)" >&2
    exit 1
  fi
  rm -rf "$dst"
  cp -R "$src" "$dst"
}
if [[ "$MODE" == project ]]; then
  copy_tree "$ROOT/.opencode/skills/multicolor-fdm-design" "$TARGET/.opencode/skills/multicolor-fdm-design"
  mkdir -p "$TARGET/.opencode/commands"
  if [[ -e "$TARGET/.opencode/commands/design-multicolor-fdm.md" && "$FORCE" -ne 1 ]]; then
    echo "Refusing to overwrite command; skill installed, command skipped." >&2
  else
    cp "$ROOT/.opencode/commands/design-multicolor-fdm.md" "$TARGET/.opencode/commands/design-multicolor-fdm.md"
  fi
else
  copy_tree "$ROOT/.opencode/skills/multicolor-fdm-design" "$TARGET/skills/multicolor-fdm-design"
fi
echo "Installed multicolor-fdm-design ($MODE)."
