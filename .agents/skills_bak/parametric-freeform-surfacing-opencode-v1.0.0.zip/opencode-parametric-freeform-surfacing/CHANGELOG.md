# Changelog

## 1.0.0 — 2026-08-19

- Initial OpenCode-compatible `parametric-freeform-surfacing` skill.
- Added fair-curve, loft, FFD, routing, environment, specification, and validation helpers.
- Added barefoot shoe, organic bowl, and RC car reference generators.
- Added references for NURBS/lofts, continuity/fairness, SubD/FFD, SDF, AI-assisted reconstruction, FDM surface quality, validation, and OpenCode integration.
