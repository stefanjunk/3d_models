# Installation

## Project-local OpenCode installation

```bash
./install.sh --project /absolute/path/to/project
```

This copies:

- `.opencode/skills/parametric-freeform-surfacing`
- `.opencode/commands/design-freeform-surface.md`

Existing files are not overwritten unless `--force` is supplied.

## Global skill installation

```bash
./install.sh --global
```

This installs the skill at:

```text
~/.config/opencode/skills/parametric-freeform-surfacing
```

The command remains project-local by default because project command policy should be reviewed per repository.

## Manual installation

```bash
mkdir -p /path/to/project/.opencode/skills
cp -R .opencode/skills/parametric-freeform-surfacing \
  /path/to/project/.opencode/skills/
```

## Dependencies

```bash
python -m pip install -r requirements.txt
```

Optional integrations are listed in `requirements-optional.txt`. They are not installed or executed automatically.

## OpenCode references

`config-examples/opencode.references.jsonc` contains optional local and documentation references. Merge only the entries that match your installation paths.
