# Parametric Freeform Surfacing for OpenCode

An OpenCode-compatible companion skill for creating smooth, editable, FDM-ready product form from dimensions, hardpoints, guide curves, sections, or AI/scan references.

It fills the gap between exact mechanical CAD and destructive mesh sculpting:

```text
functional skeleton + fair aesthetic envelope + regenerated exact features
```

## Responsibilities

- B-spline/NURBS guide curves and section lofts
- G0/G1/G2 continuity and curve/surface fairness
- SubD cages, free-form deformation, and morph targets
- local SDF/implicit blending
- AI/scan-to-editable-envelope workflows
- hardpoint-drift, tessellation, topology, and FDM surface checks

It complements rather than replaces:

- `functional-3d-design` for mechanics, materials, tolerances, slicing, BOMs, and physical tests;
- `organic-mesh-functionalization` for preserving and modifying an existing dense AI/scanned mesh;
- `3d-print-heightmap-relief` for image-driven relief after the base surface is stable.

## Install

Project-local:

```bash
./install.sh --project /absolute/path/to/project
```

Global skill:

```bash
./install.sh --global
```

OpenCode discovers the main skill at:

```text
.opencode/skills/parametric-freeform-surfacing/SKILL.md
```

The optional command is installed project-locally as:

```text
/design-freeform-surface <request>
```

No model ID is hard-coded. The skill and command inherit the user's OpenCode provider/model configuration.

## Core runtime

```bash
python -m pip install -r requirements.txt
```

Core helpers use Python, NumPy, and PyYAML. SciPy and Trimesh are used when available for comparison and richer validation. CAD/DCC packages are optional and detected rather than silently assumed.

## Verify

```bash
make env
make validate
make test
make examples
```

Generated example artifacts are written below `build/examples/` and include OBJ/STL meshes plus machine-readable validation reports.

## Included examples

1. **Barefoot shoe sole/envelope** — smooth centerline, anatomical width profile, rocker, toe spring, arch, and section loft.
2. **Organic bowl** — smooth height profile with Fourier-controlled lobes and twist, constant nominal wall, open rim, and closed printable shell.
3. **RC car sporty envelope** — fair body-section loft plus a separate smooth parametric chassis around immutable axle and mounting hardpoints.

## Package map

```text
.opencode/
├── commands/design-freeform-surface.md
└── skills/parametric-freeform-surfacing/
    ├── SKILL.md
    ├── references/
    ├── assets/
    ├── scripts/
    ├── examples/
    └── tests/
integration/
config-examples/
```

See `VALIDATION.md` for the checks actually executed for this package.
