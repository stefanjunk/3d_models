# Parametrisches Freiform-Surfacing für OpenCode

Dieser zusätzliche Skill erzeugt geschwungene, weiterhin editierbare Produktformen für den FDM-Druck. Er ergänzt das exakte funktionale CAD um eine eigene **ästhetische Hülle** aus fairen Leitkurven, Loft-Flächen, SubD, FFD/Morphs und lokalen SDF-Blends.

## Abgrenzung

- `functional-3d-design`: Mechanik, Hardpoints, Toleranzen, Material, Slicer, BOM und Tests.
- `organic-mesh-functionalization`: vorhandene dichte AI-/Scan-Meshes schützen und funktionalisieren.
- `parametric-freeform-surfacing`: neue oder rekonstruierte geschwungene Linien und Hüllen parametrisch erzeugen.

## Installation

```bash
./install.sh --project /absoluter/pfad/zum/projekt
```

oder global:

```bash
./install.sh --global
```

## Prüfung und Beispiele

```bash
make env
make validate
make test
make examples
```

Enthalten sind ein Barfußschuh, eine organische Schüssel und ein sportliches RC-Auto mit separatem Chassis. Alle drei Generatoren laufen im Core-Modus mit Python/NumPy und erzeugen OBJ/STL sowie JSON-Berichte.
