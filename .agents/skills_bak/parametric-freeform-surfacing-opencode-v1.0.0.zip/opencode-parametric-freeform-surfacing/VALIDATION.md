# Package validation

Validation executed on **2026-08-19** in the provided container.

## Environment

- Python: 3.13.5
- Core: NumPy 2.3.5, PyYAML 6.0.3
- Optional backends exercised: SciPy 1.17.0, Trimesh 4.11.1, CadQuery 2.8.0, OpenSCAD CLI present
- Optional backends not available in this environment: build123d, geomdl, PyGeM, Blender, FreeCAD, Houdini/hython, Rhino

See `validation/environment.json` for the machine-readable report. Missing optional tools were not installed or simulated.

## OpenCode/package checks

`validate_skill.py` passed:

- frontmatter starts and parses correctly;
- `name: parametric-freeform-surfacing` matches its directory;
- name pattern and description length comply with the documented OpenCode Agent Skill constraints;
- metadata values are portable strings;
- required references, templates, schema, examples, and helpers exist;
- all Python helpers, including the optional CadQuery backend, compile.

The supplied `surfacing-spec.yaml` template also passed the portable validator.

Evidence:

- `validation/skill-validation.json`
- `validation/spec-validation.json`
- `validation/install-smoke.txt`

A project-local installation into a temporary repository also passed skill validation; the `/design-freeform-surface` command was present and retained `$ARGUMENTS` without a hard-coded model.

## Automated tests

**19/19 tests passed.** The suite covered:

- regularized fairing and closed Fourier filtering;
- curvature-variation regression;
- seam-aligned closed-section loft topology;
- closed profile extrusion;
- CAD-patch vertex welding;
- identity and protected-region Bernstein FFD;
- method routing and companion-skill selection;
- point/axis/plane hardpoint comparison;
- project initialization and OpenCode frontmatter;
- all three example builds;
- SciPy B-spline fitting;
- Trimesh reference-section extraction;
- CadQuery/OpenCascade STEP lofting.

Full output: `validation/unittest.txt`.

## Example builds

Both `draft` and `print` quality builds completed successfully for:

1. barefoot shoe envelope;
2. organic bowl;
3. RC car body envelope and separate chassis.

The package's own edge-incidence checks reported one connected component, zero boundary/non-manifold edges, zero degenerate faces, and positive volume for each intended solid.

Independent Trimesh validation of the print-quality STL files reported:

| Artifact | Faces | Watertight | Winding consistent | Bodies | Positive volume |
|---|---:|---:|---:|---:|---:|
| Barefoot shoe | 5,152 | yes | yes | 1 | yes |
| Organic bowl | 69,888 | yes | yes | 1 | yes |
| RC body envelope | 5,376 | yes | yes | 1 | yes |
| RC chassis | 1,024 | yes | yes | 1 | yes |

Evidence:

- `validation/examples-draft-summary.json`
- `validation/examples-print-summary.json`
- `validation/examples-print-trimesh-validation.json`

## CadQuery/OpenCascade STEP smoke test

The optional backend generated a valid loft solid and exported STEP plus STL:

- CadQuery `Solid.isValid()`: true
- solid volume: 38,183.59 mm³
- welded tessellation: watertight, one connected component, no boundary edges

The raw OpenCascade patch tessellation duplicates coincident vertices across CAD faces. The report therefore preserves both the raw patch metrics and the correctly welded mesh metrics instead of misclassifying CAD face seams as physical holes.

Evidence: `validation/cadquery-smoke/report.json` and its generated `outputs/`.

## Not validated at package level

The following remain `NOT_RUN` or `REVIEW_REQUIRED` for each real product:

- exact G2/G3 surface matching in Rhino, Alias, or another continuity-aware CAD system;
- Blender SubD/Lattice template execution;
- FreeCAD, build123d, geomdl, PyGeM, Houdini/OpenVDB, or nTop workflows;
- AI model generation or licensing/provenance of external reference assets;
- self-intersection testing for every possible user parameter combination;
- slicer preview, support/seam decisions, variable layer height, and printer-specific compensation;
- physical printing, footwear fit, structural/crash testing, food-contact safety, or regulatory certification.

A successful package test proves reproducible helper behavior and example topology. It does not certify a final product.
