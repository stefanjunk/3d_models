#!/usr/bin/env bash
set -euo pipefail

ROOT="$(cd "$(dirname "${BASH_SOURCE[0]}")" && pwd)"
SKILL_NAME="parametric-freeform-surfacing"
FORCE=0
MODE=""
TARGET=""

usage() {
  cat <<USAGE
Usage:
  ./install.sh --project /absolute/path/to/project [--force]
  ./install.sh --global [--force]
USAGE
}

while [[ $# -gt 0 ]]; do
  case "$1" in
    --project)
      MODE="project"; TARGET="${2:-}"; shift 2 ;;
    --global)
      MODE="global"; shift ;;
    --force)
      FORCE=1; shift ;;
    -h|--help)
      usage; exit 0 ;;
    *)
      echo "Unknown argument: $1" >&2; usage >&2; exit 2 ;;
  esac
done

if [[ "$MODE" == "project" ]]; then
  [[ -n "$TARGET" ]] || { echo "--project requires a path" >&2; exit 2; }
  TARGET="$(mkdir -p "$TARGET" && cd "$TARGET" && pwd)"
  DEST="$TARGET/.opencode/skills/$SKILL_NAME"
  CMD_DEST="$TARGET/.opencode/commands/design-freeform-surface.md"
elif [[ "$MODE" == "global" ]]; then
  DEST="${XDG_CONFIG_HOME:-$HOME/.config}/opencode/skills/$SKILL_NAME"
  CMD_DEST=""
else
  usage >&2; exit 2
fi

copy_path() {
  local src="$1" dst="$2"
  if [[ -e "$dst" && "$FORCE" -ne 1 ]]; then
    echo "Refusing to overwrite existing path: $dst (use --force)" >&2
    exit 3
  fi
  rm -rf "$dst"
  mkdir -p "$(dirname "$dst")"
  cp -R "$src" "$dst"
}

copy_path "$ROOT/.opencode/skills/$SKILL_NAME" "$DEST"
if [[ -n "$CMD_DEST" ]]; then
  copy_path "$ROOT/.opencode/commands/design-freeform-surface.md" "$CMD_DEST"
fi

echo "Installed skill: $DEST"
[[ -z "$CMD_DEST" ]] || echo "Installed command: $CMD_DEST"
