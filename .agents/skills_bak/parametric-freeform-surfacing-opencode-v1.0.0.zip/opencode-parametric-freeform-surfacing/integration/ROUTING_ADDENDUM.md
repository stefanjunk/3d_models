# Routing addendum for the existing 3D-design skill family

Add this specialist without merging its responsibilities into the existing modules.

## Extended MECE model

| Module | Owns | Does not own |
|---|---|---|
| Functional design | requirements, mechanical core, interfaces, materials, tolerances, assemblies, print configuration | premium freeform surface construction; dense source preservation |
| Parametric freeform surfacing | fair curves, aesthetic envelopes, NURBS/lofts, SubD/FFD/morphs, local SDF blends, reference fitting, continuity and tessellation evidence | general mechanical design; destructive edits to a protected dense source mesh |
| Organic mesh functionalization | preservation, ROI/transition/keep-out planning, local edits and functional integration in an existing dense mesh | generation of a new editable premium envelope from first principles |
| Height-map relief | physical image sampling, mapping, emboss/engrave patches | base product form and general mesh repair |
| Negative molds/casting | process, shrinkage, parting, draft, vents, drains, mold architecture | final-product surfacing except where tooling requires it |

## Route to this skill when

- a dimension-driven model looks boxy despite fillets;
- the silhouette, roofline, sole, rim, shoulder, or section flow is a primary requirement;
- a good AI or manually sculpted form should become an editable product family;
- style variants should preserve wheelbase, axle axes, mounting faces, foot landmarks, or other hardpoints;
- a local union or rib transition requires an implicit blend but the rest of the part must remain exact.

## Composite sequencing

For a new product:

```text
functional contract and hardpoints
→ parametric freeform curves/envelope
→ regenerate exact interfaces and print splits
→ optional relief
→ slicer/physical validation
→ optional mold derivation
```

For an existing AI/scan mesh that must be preserved:

```text
organic-mesh preservation contract
→ retopology/cage or fitted envelope in allowed regions
→ parametric functional integration
→ exact-feature regeneration
→ validation
```

Do not route every rounded object here. Simple mechanical fillets and ordinary lofts remain in `functional-3d-design`; this specialist is for visible form quality, curvature control, style parameterization, or reference reconstruction.
