# Changelog

## 2.1.0

- Clarified that AI generation requires a linked physical size, requested PPI, and minimum native pixel dimensions; a DPI phrase alone is not sufficient.
- Split resolution into requested generation PPI, actual effective source PPI, and final printer-processing PPI.
- Made AI-generation PPI isotropic by default because source raster pixels are square.
- Added physical-coordinate image fitting so anisotropic final X/Y print pitch does not distort motifs.
- Added a replaceable-source contract with source hashes, manifests, stable build paths, and one-command replacement.
- Added `init_relief_job.py` for job manifests and generation prompts.
- Added `rebuild_relief_job.py` for one-command source replacement, deterministic 16-bit reprocessing, and optional geometry rebuild.
- Added an example `relief-job.json` with a project-specific geometry adapter command.

## 2.0.0

- Added hard rule: keep processed relief maps continuous and 16-bit by default.
- Added explicit warning against accidental 2-level or 3-level posterization.
- Added DPI/PPI planning, persistence, and sidecar metadata guidance.
- Added resizing limits and advice to crop/repeat seamless textures instead of over-stretching them.
- Added placement guidance for non-seamless subject images, including people, animals, objects, and writing.
- Added mapping guidance for flat, cylindrical, spherical, ellipsoidal, rounded-corner, and arbitrary UV surfaces.
