---
name: 3d-print-heightmap-relief
description: Plan, preprocess, scale, and place grayscale height maps for 3D-printable engraving and embossing on flat and curved surfaces. Preserve grayscale fidelity, specify and register AI-generated source masters at an explicit physical authoring scale and PPI, derive replaceable surface-specific 16-bit build heightmaps, and guide OpenSCAD, CadQuery, FreeCAD, and Blender workflows.
license: MIT
compatibility: OpenCode and other Agent-Skills-compatible runtimes
metadata:
  version: "2.1.0"
  domain: "3d-printing"
  output_units: "mm"
  source_master_format: "16-bit PNG"
  surface_build_format: "16-bit PNG"
---

# 3D print heightmap relief

Use this skill whenever an image, texture, logo, portrait, text, or other visual motif must be engraved or embossed on a printable 3D object.

## Read only what the task needs

- Overall rules and workflow: `references/principles.md`
- Bit depth, grayscale fidelity, and height resolution: `references/bit-depth-and-height-resolution.md`
- AI image generation, source-master DPI/PPI, and traceability: `references/ai-generated-source-masters.md`
- Surface-build DPI/PPI, target raster size, and resizing limits: `references/dpi-and-pixel-resolution.md`
- Rebuildable jobs and one-command source replacement: `references/rebuildable-jobs.md`
- Persistent job fields and geometry-command placeholders: `references/relief-job-format.md`
- Texture images vs object/person/animal/text images: `references/image-types-and-placement.md`
- Surface mapping on flat and curved geometry: `references/surface-mapping.md`
- Structural limits and visibility guidance: `references/depth-visibility-and-structure.md`
- Tool guidance for OpenSCAD, CadQuery, FreeCAD, and Blender: `references/tool-guidance.md`
- Practical examples: `references/examples.md`
- Execution checklist: `references/agent-checklist.md`

## Hard rules

1. **Do not reduce a relief image to binary or a tiny number of grayscale steps unless the user explicitly asks for a stepped or posterized relief.**
2. **Maintain two explicit image stages:** a reusable **source master** and a target-specific **surface build heightmap**. Preserve both as 16-bit grayscale PNG by default; use 8-bit only for previews or when explicitly justified.
3. **Increase visual strength with physical depth, feature width, image scale, contrast shaping, or emboss direction — not by throwing away grayscale resolution.**
4. **When an AI generates a new image, specify its intended physical authoring width/height, square-pixel authoring PPI, and computed pixel dimensions before generation.** Persist the requested generation specification, prompt, actual pixel dimensions, effective PPI, bit depth, polarity, and seamless/repeating intent in a source manifest.
5. **Always persist target processing metadata.** Store at least width_mm, height_mm, pitch_x_mm, pitch_y_mm, dpi_x, dpi_y, pixel_width, pixel_height, bit_depth, fit_mode, invert, gamma, source asset ID/hash, and intended surface mapping in a build sidecar JSON.
6. **Treat DPI/PPI as secondary metadata, not the only source of truth.** Image generators and CAD/mesh tools may ignore it. Always store physical dimensions and pixel dimensions too.
7. **For seamless textures, prefer crop/repeat over large stretching.** For motifs, portraits, animals, objects, and writing, prefer contain or controlled cover/crop over stretch.
8. **Choose a placement chart intentionally.** A repeating texture can wrap continuously over multiple faces. A subject image usually belongs on a specific patch and must not be unintentionally repeated.
9. **For engravings, preserve wall thickness.** If the desired visual effect requires more depth than the wall can safely lose, switch to embossing or thicken the base wall.
10. **Make image exchange reproducible.** Keep mapping, printer, processing, and relief settings in a persistent job JSON. The agent that creates the model must also provide a deterministic geometry build script/command referencing the stable target heightmap path, so one command can replace the source, rebuild the heightmap, and rebuild the engraving/embossing geometry.
11. **Validate both geometry and appearance.** A watertight mesh is not enough; the image still must remain legible in the slicer preview and on a real print.

## Mandatory workflow

### 1. Classify the image

Classify the source as one of:
- repeating texture;
- non-repeating motif/logo;
- text/writing;
- object/person/animal image;
- hand-authored depth map;
- photograph that still needs cleanup.

This classification affects generation instructions, fit mode, allowed stretching, recommended depth range, and surface mapping.

### 2. Determine the target surface patch

Decide whether the image is placed on:
- one flat face;
- a full cylindrical wrap;
- a continuous rounded-rectangle side wall;
- a spherical or ellipsoidal patch;
- a top face plus side walls;
- all visible faces as a repeating texture;
- an arbitrary UV-mapped region.

For a seamless texture, distinguish the **physical tile size** from the larger **mapped target area**. For a person, animal, object, logo, or writing, the source usually represents one full placement patch.

### 3. Plan printer-specific sampling

If explicit pitch is not given, compute it from the fabrication process.

Default FDM starting values:
- image axis that maps mainly in printed XY: `pitch_xy ≈ nozzle_mm * 0.5`;
- image axis that maps mainly along model Z on a side wall: `pitch_z ≈ layer_height_mm * 1.0`.

Example:
- nozzle 0.4 mm → XY pitch about 0.20 mm → about 127 PPI;
- layer height 0.12 mm → Z-oriented pitch about 0.12 mm → about 212 PPI.

Then calculate the final processed raster from physical dimensions and pitch. The final output may intentionally have different X/Y PPI when its surface axes are manufactured differently.

### 4. When AI generates the source image, specify generation resolution before generation

AI-generated raster sources should normally use square pixels and therefore one isotropic generation PPI. Use at least the larger of the two printer-processing PPI values, normally with about 1.5–2× oversampling.

Before generation, define and persist:
- physical source size: the repeat tile size for a seamless texture, or the full image-placement size for a subject;
- requested generation PPI;
- calculated minimum native pixel width and height;
- the exact generation prompt.

After generation, record:
- actual pixel dimensions;
- embedded DPI metadata, if present;
- actual effective PPI at the intended physical source size;
- source hash and provenance.

Never assume that writing “300 DPI” in a generation prompt guarantees 300 DPI. The generator must receive physical size plus pixel dimensions, and the returned file must be inspected.

Use `scripts/init_relief_job.py` to create the job and generation brief.

### 5. Derive the deterministic surface build heightmap

Create a new surface-specific build heightmap from the registered source master:
- default output: 16-bit grayscale PNG;
- embed final printer-processing DPI/PPI metadata when possible;
- store the same values in the job manifest and sidecar JSON;
- preserve continuous grayscale values;
- only quantize intentionally;
- fit in physical coordinates so non-square printer sampling does not distort the subject.

Use `scripts/rebuild_relief_job.py` or `scripts/prepare_heightmap.py`.

### 6. Choose depth from the print and wall constraints

Choose depth after preserving grayscale quality.

Typical starting ranges:
- subtle texture engraving: 0.10–0.35 mm;
- readable engraved logo/text/object motif: 0.30–0.80 mm;
- visible embossed logo/text/object motif: 0.50–1.50 mm;
- strong decorative bas-relief on a large object: 1.5–3.0 mm if wall thickness and object scale allow.

If the image is visually weak, first consider:
- larger placement size;
- greater absolute depth;
- stronger local contrast or gamma shaping;
- emboss instead of engrave;
- lighting and print orientation.

Do **not** fix poor visibility by collapsing grayscale into black/white.

### 7. Map intentionally

- Repeating textures may repeat and wrap continuously.
- Non-repeating subjects should normally be placed once on a defined patch.
- Text should preserve aspect ratio and often benefits from vector reconstruction.
- Portraits and animal/object images should usually be background-cleaned and tone-shaped before use.

Read `references/image-types-and-placement.md` and `references/surface-mapping.md`.

### 8. Keep the source swappable and rebuild geometry

The project must retain:
- `source/source-master.png` as the replaceable registered source;
- `source/source-master.png.source.json` as source provenance and PPI metadata;
- `relief-job.json` as the stable processing/placement contract;
- `build/current-heightmap.png` as the reproducible surface build heightmap;
- a project-specific geometry command that consumes `{heightmap}`.

A replacement image should require one command, not manual edits to the CAD model:

```bash
python scripts/rebuild_relief_job.py path/to/relief-job.json \
  --source new-generated-or-supplied-image.png \
  --register-source \
  --source-kind ai-generated \
  --run-geometry
```

### 9. Validate

Validate:
- mesh watertightness;
- remaining wall thickness;
- seam quality;
- actual legibility in the slicer;
- whether the chosen depth creates enough real printed layers or extrusion contrast;
- whether the rebuilt model actually uses the newly selected source hash.

## Helper scripts

- `scripts/init_relief_job.py` — initializes a source-swappable job, generation specification, and generation prompt.
- `scripts/plan_ai_source.py` — creates a generation specification and prompt fragment with physical authoring size, PPI, and requested pixels.
- `scripts/register_source_master.py` — registers the generated/supplied image as a reusable 16-bit source master and records requested versus actual/effective PPI.
- `scripts/prepare_heightmap.py` — derives the target-specific 16-bit surface build heightmap with physical scale and DPI metadata.
- `scripts/rebuild_relief_job.py` — can register a raw replacement into the canonical source master, rebuild the stable 16-bit heightmap, and optionally run the configured geometry command in one command.
- `scripts/recommend_relief_plan.py` — recommends pitch, DPI, fit mode, depth range, and wall-safety guidance for a given print setup and image type.

## Deliverable contract

When using this skill, always report:
- source asset ID/path and whether it was AI-generated or supplied;
- requested source authoring size/PPI/pixels and actual/effective source PPI;
- image class;
- surface type and placement patch;
- fit mode;
- target size in mm;
- target pixel size;
- pitch_x_mm and pitch_y_mm;
- DPI/PPI;
- bit depth;
- invert/gamma/levels decisions;
- chosen depth range and why;
- wall-safety assumptions;
- requested and actual generation PPI/pixels when AI generated the source;
- source path/hash, persistent job path, and exact one-command source-replacement/rebuild command;
- any warnings about upscaling, cropping, pole distortion, seams, or weak visibility.
