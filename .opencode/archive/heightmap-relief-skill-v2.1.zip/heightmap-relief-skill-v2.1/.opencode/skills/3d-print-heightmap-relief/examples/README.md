# Example job specs

These YAML files are planning examples, not locked schemas.

They demonstrate:
- a non-repeating unicorn motif on a cylinder;
- a repeating carbon texture around a rounded organizer;
- a wood texture across multiple shelf surface families;
- a person image on a spherical patch;
- text on a flat box face.

Use them as starting points when preparing a new heightmap and deciding placement, DPI/PPI, and depth.


The `rebuildable-carbon-job/` example demonstrates the persistent two-stage image flow:

1. AI generation specification with physical authoring size, PPI, and pixels.
2. Registered reusable source master.
3. Stable target-specific 16-bit heightmap.
4. One-command source replacement and optional geometry rebuild.
