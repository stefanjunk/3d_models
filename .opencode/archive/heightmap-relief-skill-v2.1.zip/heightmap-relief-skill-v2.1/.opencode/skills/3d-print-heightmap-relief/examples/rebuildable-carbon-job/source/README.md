1. Generate/select an image using generation-prompt.txt.
2. Run rebuild_relief_job.py ../relief-job.json --source NEW_IMAGE --register-source.
3. Add --run-geometry after geometry.command is configured to rebuild the final model too.
Do not edit build/current-heightmap.png directly; it is reproducible.
