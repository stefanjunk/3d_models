# Agent execution checklist

Before source generation or processing:
- [ ] classify the image: texture, text, logo, subject, portrait, object, animal;
- [ ] classify the surface: plane, cube face, cylinder, rounded box, sphere, ellipsoid, arbitrary UV;
- [ ] decide whether the source will be AI-generated, supplied, vector-derived, or procedural;
- [ ] decide whether the image repeats or is placed once;
- [ ] decide whether aspect ratio may change.
- [ ] if AI is generating the source, define intended physical size, requested generation PPI, and minimum native pixel dimensions before generation;
- [ ] persist the exact generation prompt and later record actual source pixels, effective PPI, and file hash;

During AI source generation/registration:
- [ ] choose intended source-master width/height in mm;
- [ ] choose square-pixel authoring PPI and compute requested pixels;
- [ ] put physical size, PPI, pixel dimensions, seamless intent, polarity, and no-posterization rule in the generation instruction;
- [ ] preserve the prompt/specification;
- [ ] inspect actual generated pixels/mode instead of assuming compliance;
- [ ] register a reusable 16-bit source master and source manifest with requested versus effective PPI;

During surface build preparation:
- [ ] derive a new surface-specific build heightmap from the source master;
- [ ] use 16-bit grayscale PNG by default;
- [ ] preserve grayscale continuity;
- [ ] avoid thresholding or palette reduction unless explicitly requested;
- [ ] compute pitch and DPI/PPI from nozzle/layer or printer pixel size;
- [ ] store physical dimensions, target dpi_x/dpi_y, source asset ID/hash, and processing settings in a JSON sidecar.
- [ ] keep the target output path stable in a persistent job JSON so the source can be swapped and rebuilt.

Placement decisions:
- [ ] choose contain/cover/crop/stretch/repeat intentionally;
- [ ] crop/repeat textures instead of over-stretching them;
- [ ] keep subject images off poles, sharp corners, and problematic seams unless intended;
- [ ] use a bounded patch for portraits, animals, objects, and writing when distortion would be obvious.

Depth and structure:
- [ ] compute safe engraving depth from wall thickness;
- [ ] if more effect is needed, consider embossing or a thicker base wall;
- [ ] do not increase effect by destroying grayscale precision.

Source replacement check:
- [ ] verify that `rebuild_relief_job.py JOB --source NEW_IMAGE --register-source` can register the replacement and regenerate the stable build heightmap;
- [ ] if a geometry command is configured, run it only with explicit authorization/flag and verify the rebuilt model.

Replaceability and rebuild:
- [ ] keep the source master separate from the processed 16-bit heightmap;
- [ ] include `relief-job.json` or an equivalent stable manifest;
- [ ] include a one-command source-swap/reprocess path;
- [ ] configure a geometry command that consumes the canonical processed heightmap when delivering a complete model pipeline;

Before delivery:
- [ ] report source authoring width/height, requested PPI/pixels, actual/effective PPI, and source asset ID;
- [ ] report target width_mm, height_mm, pixel_width, pixel_height;
- [ ] report pitch_x_mm, pitch_y_mm, dpi_x, dpi_y;
- [ ] report fit mode, bit depth, and image class;
- [ ] report chosen depth range and wall-safety assumptions;
- [ ] report any warnings about upscaling, seams, distortion, or weak visibility.
