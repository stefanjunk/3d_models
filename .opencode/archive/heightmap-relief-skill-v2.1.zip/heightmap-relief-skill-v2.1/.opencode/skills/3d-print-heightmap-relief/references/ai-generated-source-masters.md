# AI-generated source masters: authoring scale, PPI, and traceability

## The intended meaning of DPI/PPI at image-generation time

When an agent asks an image model to create a new texture, motif, portrait-style relief source, animal, object, or writing image, it must define the image as a **physical authoring asset**, not merely request “a high-resolution picture.”

Before generation, specify:

- intended physical authoring width and height in millimetres;
- one square-pixel authoring PPI value;
- the corresponding requested pixel width and height;
- whether the source is seamless and on which axes;
- whether it is a repeating texture or a single placed subject;
- grayscale height polarity, such as white = high and black = low;
- continuous tonal output with no thresholding or posterization;
- background, crop, direction, and placement requirements.

Example calculation:

```text
physical tile: 50 × 50 mm
authoring PPI: 300
requested pixels: round(50 / 25.4 × 300) = 591
request: 591 × 591 px
```

The generation instruction should contain all three representations:

```text
Create a seamless grayscale height-map source representing a 50 × 50 mm tile at
300 PPI, requested raster 591 × 591 pixels, square pixels. Preserve continuous
grayscale; do not threshold or posterize. White means high, black means low.
Make opposite borders tile seamlessly. Avoid perspective, cast shadows,
highlights, labels, and photographic lighting that would become false geometry.
```

## PPI is a specification, not a guarantee from the image model

Most AI image generators fundamentally create pixels. They may ignore embedded DPI metadata, choose only supported raster sizes, output RGB rather than grayscale, and return 8-bit data even when 16-bit is requested.

Therefore the agent must not claim that the generator honored the requested PPI or bit depth without inspection.

After generation:

1. inspect the actual pixel dimensions and mode;
2. register the image with `scripts/register_source_master.py`;
3. calculate effective PPI from actual pixels and intended physical dimensions;
4. embed the effective PPI in the registered PNG where possible;
5. persist requested and actual/effective values in the source manifest;
6. preserve the generated prompt and generation specification.

If the generator returns a different raster size, either:

- preserve the pixels and record the resulting effective PPI; or
- resample to the requested pixel dimensions within the documented resizing limits.

Do not silently pretend that a 1024 × 1024 output is 591 × 591 or that an 8-bit generated image contains native 16-bit source precision.

## Source master versus surface build heightmap

### Reusable source master

The source master is the replaceable design asset. It has:

- an authoring physical size;
- square-pixel authoring/effective PPI;
- continuous grayscale in a 16-bit PNG container;
- a source manifest;
- a stable asset ID/hash;
- generation prompt/specification if AI-generated.

It should not yet be distorted for one printer orientation or one specific surface unless the asset is inherently surface-specific.

### Surface build heightmap

The surface build heightmap is derived later for one model/surface. It has:

- mapped width and height in mm;
- possibly different X and Y pitch;
- target dpi_x and dpi_y based on nozzle, layer height, resin pixel size, and mapping direction;
- contain/cover/repeat/crop decisions;
- invert/gamma/levels and masks;
- a stable output path consumed by the CAD/mesh build.

Keeping these stages separate makes source replacement easy and prevents generation-time DPI from being confused with final printer sampling.

## Choosing authoring PPI

The source master should normally oversample the finest expected target build raster without becoming wastefully large.

Recommended starting policy:

- determine the highest expected target PPI on either axis;
- choose source authoring PPI around 1.5× that value;
- round to a practical value such as 300, 450, 600, 900, or 1200 PPI;
- use at least 300 PPI for newly generated general-purpose FDM assets when size remains reasonable;
- use 600 PPI or more for small fine-detail/resin assets when the generator and memory budget support it.

The PPI only has meaning together with the physical authoring size. A 300 PPI texture at 25 mm is a different source asset from the same pixels interpreted at 100 mm.

## Prompt guidance by image class

### Seamless texture

Include:

- physical tile size and requested pixels;
- seamless X/Y requirement;
- preferred weave/grain direction;
- no perspective or directional lighting;
- luminance represents height, not surface color;
- no isolated border features that break repetition.

### Person, animal, or object

Include:

- physical authoring rectangle and requested pixels;
- single non-repeating subject;
- centered composition and protected margins;
- cleaned or simple background;
- no crop of important features;
- no cast shadows/highlights unless deliberately part of the relief;
- continuous tonal bas-relief rather than black/white silhouette.

### Text or writing

Prefer vector generation or direct CAD text when possible. If AI-generated handwriting or decorative lettering is required, specify:

- exact physical authoring rectangle and requested pixels;
- isolated high-contrast lettering with protected margins;
- no decorative background unless desired;
- continuous antialiased edges;
- exact spelling must be verified after generation.

## Commands

Create a generation specification and prompt:

```bash
python scripts/plan_ai_source.py \
  --description "fine carbon fibre weave height map" \
  --physical-size-mm 50x50 \
  --authoring-ppi 300 \
  --image-class texture \
  --seamless-x --seamless-y \
  --output-spec assets/carbon.source-spec.json \
  --output-prompt assets/carbon.prompt.txt
```

After the AI image is generated:

```bash
python scripts/register_source_master.py generated.png assets/carbon.master.png \
  --spec assets/carbon.source-spec.json \
  --source-kind ai-generated \
  --pixel-policy preserve
```

The resulting `assets/carbon.master.png.source.json` is the authoritative source manifest.
