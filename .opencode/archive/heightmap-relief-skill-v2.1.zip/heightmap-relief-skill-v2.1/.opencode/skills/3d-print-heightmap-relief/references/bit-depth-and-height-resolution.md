# Bit depth, grayscale fidelity, and height resolution

## Never confuse tonal resolution with physical depth

Tonal resolution answers: how finely can the image represent a value between black and white?

Physical depth answers: how much millimetre difference exists between the shallowest and deepest part of the relief?

These are independent design dimensions.

## Why low-level quantization is harmful

If a flow quantizes an image to two, three, or a few levels:
- skin, fur, feathers, cloth, and wood lose subtle variation;
- smooth shading becomes terraces;
- anti-aliased text edges break into jagged bands;
- object relief becomes unreadable.

That is acceptable only when the intended style is explicitly stepped, like contour lines or a comic-like posterization.

## Default policy

- Keep reusable source masters and target surface build heightmaps in **16-bit grayscale** containers by default.
- Keep internal processing in floating point or at least 16-bit integer.
- Export 8-bit only when the target workflow truly needs it and the tonal range is still sufficient.
- Do not apply indexed/palette image export for relief maps.

## What 16-bit does and does not guarantee

16-bit design precision helps keep smooth transitions during preprocessing and mapping, but the printed object still has physical limits:

### FDM

- top-facing relief height is quantized by layer height;
- side-wall appearance also depends on XY feature width and the staircase formed by layers;
- a 0.6 mm relief at 0.12 mm layers yields only about 5 major vertical steps if printed face-up.

### Resin

- XY is limited by optical pixel size and light bleed;
- Z is limited by layer height and curing behavior.

So 16-bit does not magically create infinite physical levels. It simply prevents the design process from destroying information before the printer even has a chance.

## Guidance for agents

Agents using this skill should assume:

- **default master bit depth: 16-bit**;
- **default continuous relief: yes**;
- **default posterization: no**.

Only choose deliberate quantization when one of these is true:

- the user asks for a stepped or topographic style;
- a logo should use a fixed number of discrete height bands;
- a downstream manufacturing process explicitly requires a limited set of heights.

Even then, preserve an unquantized master if later revision may be needed.

## Handling weak visibility correctly

When the result is too weak, do not threshold first. Instead:

- expand the physical depth range;
- re-center the tonal distribution with levels;
- adjust gamma to favor useful mids;
- isolate the subject from the background;
- enlarge the subject on the surface;
- use emboss rather than engrave;
- choose a surface and print orientation that gives light-catching geometry.

## Text and logos

For text, symbols, or crisp logos:
- vector geometry is often better than raster height data for the main outline;
- a raster height map can still add bevels, rounded edges, or subtle texture;
- keep anti-aliased edge information if using a raster workflow.

## Portraits, people, animals, and objects

These almost always suffer if reduced to a few tones. Recommended approach:

- clean the background;
- keep grayscale continuous;
- use modest local contrast and edge reinforcement if needed;
- select a larger depth range or a larger image footprint before considering any stylization.
