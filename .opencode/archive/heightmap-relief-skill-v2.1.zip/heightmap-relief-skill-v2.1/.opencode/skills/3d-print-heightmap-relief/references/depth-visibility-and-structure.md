# Depth, visibility, and structural safety

## Start from the available wall budget

For engravings, compute:

`max_safe_engrave_depth ≈ wall_thickness - minimum_remaining_wall`

A practical starting rule for FDM is:
- `minimum_remaining_wall = max(1.2 mm, 3 * nozzle_mm)`

Increase that reserve if:
- the part is load-bearing;
- the material is brittle;
- the relief covers a large percentage of the wall;
- the wall already contains cutouts or fasteners.

If the desired effect exceeds the safe engraving depth:
- switch to embossing; or
- increase the base wall thickness.

## Suggested depth ranges

These are starting ranges, not fixed rules.

### Texture

- subtle engraving: 0.10–0.25 mm;
- stronger engraving: 0.25–0.40 mm;
- subtle emboss: 0.20–0.50 mm.

### Text, logos, objects, animals, portraits

- engraved motif: 0.30–0.80 mm;
- embossed motif: 0.50–1.50 mm;
- large decorative bas-relief: 1.5–3.0 mm if the object scale and structure allow.

## Why emboss can be the right answer

If the visual effect is weak and the wall cannot safely lose more depth, embossing may be better because:
- it preserves the interior or structural wall;
- it creates stronger highlights and shadows;
- it can use larger physical height without cutting too deep.

## Visibility depends on more than depth

A relief can remain invisible even with technically correct grayscale if:
- the image is physically too small;
- the features are too narrow for the nozzle or print orientation;
- the image contains only low-contrast large gradients;
- the print is viewed under flat lighting;
- the material color and finish hide shallow surface changes.

Therefore check:
- feature width;
- actual number of meaningful printed layers or extrusion bands;
- image scale on the object;
- whether the subject needs stronger local contrast;
- whether a texture should become coarser.

## How to strengthen appearance without destroying grayscale

1. Increase depth.
2. Increase the placed image size.
3. Adjust levels and gamma.
4. Isolate the subject from the background.
5. Use a front patch instead of wrapping over corners or poles.
6. Prefer emboss for stronger shadowing.
7. Thicken the base wall and keep the full 16-bit master.

## Text readability guidance

Text relief needs both depth and width.

- Increase stroke width or font size before simply adding depth.
- Avoid very fine script on rough FDM side walls unless enlarged.
- Consider embossing for better readability.
- Keep the main outline crisp; use bevels as secondary decoration.
