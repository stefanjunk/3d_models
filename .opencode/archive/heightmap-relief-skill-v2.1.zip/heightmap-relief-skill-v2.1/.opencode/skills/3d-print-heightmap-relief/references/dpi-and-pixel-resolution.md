# Surface-build DPI/PPI, target raster size, and resizing limits

This document concerns the **target-specific surface build heightmap**. For generation-time source-master PPI, read `ai-generated-source-masters.md`.

## Two DPI/PPI stages

### Source authoring PPI

- square-pixel scale assigned when an AI-generated or supplied image becomes a reusable source master;
- persisted in the source manifest;
- describes the physical design scale of the reusable image asset.

### Surface build dpi_x / dpi_y

- computed for one mapped surface and one print process;
- may be anisotropic because one image axis can map to printed XY and another to model Z;
- persisted in the build sidecar;
- used to derive the exact target raster consumed by the relief workflow.

Do not overwrite the source master merely because a particular print needs a different target sampling grid. Derive a new build heightmap instead.

## Formula

For one axis:

- `pitch_mm_per_pixel = physical_mm / pixel_count`
- `ppi = 25.4 / pitch_mm_per_pixel`
- `pixel_count = round(physical_mm / pitch_mm_per_pixel)`

If the two target axes use different pitches, keep separate values:

- `pitch_x_mm`, `pitch_y_mm`
- `dpi_x`, `dpi_y`

Store physical dimensions, pixel dimensions, and DPI/PPI together. CAD and mesh tools may ignore embedded image metadata.

## Recommended starting pitch for FDM

These are conservative starting values, not hard laws.

### Image axis mapped mainly to printed XY

Start with:

- `pitch_xy ≈ nozzle_mm × 0.5`

Examples:

- 0.40 mm nozzle → about 0.20 mm pitch → about 127 PPI
- 0.60 mm nozzle → about 0.30 mm pitch → about 85 PPI
- 0.25 mm nozzle → about 0.125 mm pitch → about 203 PPI

### Image axis mapped mainly to model Z on a side wall

Start with:

- `pitch_z ≈ layer_height_mm × 1.0`

Examples:

- 0.20 mm layer height → about 127 PPI
- 0.12 mm layer height → about 212 PPI
- 0.08 mm layer height → about 318 PPI

### Flat top face

Both image axes are generally XY-oriented, so start from nozzle-based pitch.

### Cylinder or rounded side wall

- around the circumference/perimeter: use XY/nozzle-based pitch;
- vertically: use layer-height-based pitch.

Non-square target pixels can therefore be correct. This anisotropic build raster is derived from, not confused with, the square-pixel source master.

## Resin guidance

Use known optical pixel size as the starting XY pitch and layer height as the Z-oriented pitch. Keep the reusable and build assets 16-bit even though the physical print has finite steps.

## Resizing from source master to build heightmap

### Seamless repeating textures

Because the source repeats, it is usually acceptable to:

- crop to a cleaner repeating tile;
- repeat more or fewer tiles;
- make mild scale adjustments to hit a target repeat count.

Guidance:

- up to about **125%** source upscaling: normally fine;
- **125–150%**: acceptable with inspection;
- **150–200%**: warning zone; verify the source still contains useful detail;
- above **200%**: normally obtain/regenerate a better source master or use a smaller physical tile/repeat period.

For textures, prefer crop and repeat over non-uniform stretch.

### Non-repeating subject images

A portrait, person, animal, object, logo, or text image should normally preserve aspect ratio.

Guidance:

- non-uniform aspect stretch should normally remain within about **±5%**;
- upscaling above **125–150%** deserves a warning;
- above **150%**, prefer regenerating/replacing the source at a higher authoring PPI or reducing physical placement size.

### Downscaling

Downscaling is acceptable when it preserves the printable features. Apply antialiasing and derive directly from the reusable source master rather than repeatedly resampling an already processed build image.

## Persistent job and source replacement

A relief job should keep stable target settings in JSON:

- target physical size;
- printer parameters and axis mapping;
- fit/repeat behavior;
- levels, gamma, invert, masks;
- relief mode and depth;
- stable output heightmap path;
- optional geometry rebuild command.

Only the source path changes when replacing artwork.

Example:

```bash
python scripts/rebuild_relief_job.py jobs/organizer.json \
  --source assets/new-carbon.master.png \
  --persist-source
```

The script rebuilds the same target heightmap path. The OpenSCAD, CadQuery, FreeCAD, or Blender build can continue to reference that stable file.

## Required build metadata

Every surface build heightmap should have a sidecar containing at least:

```json
{
  "source_asset_id": "sha256-prefix-or-stable-id",
  "source_path": "assets/carbon.master.png",
  "width_mm": 120.0,
  "height_mm": 70.0,
  "pitch_x_mm": 0.20,
  "pitch_y_mm": 0.12,
  "dpi_x": 127.0,
  "dpi_y": 211.67,
  "pixel_width": 600,
  "pixel_height": 583,
  "bit_depth": 16,
  "fit_mode": "repeat",
  "image_class": "texture",
  "surface_type": "rounded_box",
  "placement_mode": "continuous_perimeter_wrap"
}
```
