# Examples

## 1. Unicorn on a cylindrical gift box

Goal:
- single non-repeating unicorn image;
- engraved or embossed on the outside of a cylindrical box;
- the image should sit correctly on the visible front region, not be distorted or repeated unintentionally.

Recommended decisions:
- image class: single-subject motif;
- fit mode: contain or controlled cover;
- placement: front cylindrical patch, not full repeating wrap;
- registered source master: 16-bit PNG with authoring size/PPI manifest;
- derived surface build heightmap: 16-bit PNG with target width/height and dpi metadata;
- depth: start around 0.40–1.00 mm depending style and wall thickness.

If the unicorn needs a stronger visual effect, increase depth or image size before reducing tonal precision.

## 2. Carbon fibre texture around a rounded desk organizer

Goal:
- repeating texture around front, left, back, and right side walls;
- continuous wrap around rounded corners.

Recommended decisions:
- image class: repeating texture;
- fit mode: repeat;
- placement: one continuous rounded-rectangle perimeter map;
- crop the source tile if that gives a cleaner repeating unit;
- registered source master and derived surface build heightmap: 16-bit PNG;
- depth: subtle to moderate, around 0.15–0.35 mm for engraving or 0.20–0.50 mm for emboss.

Here it is acceptable to crop or cut the source tile to preserve high local quality.

## 3. Wood texture on a honeycomb wall shelf

Goal:
- wood-like texture on multiple visible shelf surfaces;
- preserve one clear wood-grain direction.

Recommended decisions:
- image class: repeating texture;
- placement: per surface family with controlled global grain direction;
- outer and inner walls may use perimeter coordinates;
- front and back faces may use planar mapping;
- derived surface build heightmaps may differ per surface family while the reusable source master remains replaceable; all remain 16-bit containers.

Do not rotate the wood grain arbitrarily on each face unless that is an intentional design choice.

## 4. Animal or person image on a sphere or ellipsoid

Goal:
- place a face or animal image on a rounded object.

Recommended decisions:
- image class: single subject;
- placement: bounded front patch, not full-pole wrap;
- fit mode: contain;
- use a mask or fade near patch boundaries;
- preserve continuous grayscale;
- prefer emboss if safe inward depth is limited.

## 5. Writing on a cube or rounded box

Goal:
- readable text on a flat or gently curved surface.

Recommended decisions:
- reconstruct vector text if possible;
- preserve aspect ratio;
- use contain or explicit layout margins;
- avoid carrying critical lettering over sharp corners;
- increase stroke width or physical size before only increasing depth.


## Replacing an image without redesigning the model

Store the surface and processing rules in a job JSON. The model consumes a stable file such as `build/current-heightmap.png`. To exchange the artwork:

```bash
python scripts/rebuild_relief_job.py jobs/unicorn-cylinder.json \
  --source assets/new-unicorn.master.png \
  --persist-source
```

Then rerun the same CAD/mesh build. If `geometry.command` is present in the job, the explicit `--run-geometry` flag can execute it after image preprocessing.
