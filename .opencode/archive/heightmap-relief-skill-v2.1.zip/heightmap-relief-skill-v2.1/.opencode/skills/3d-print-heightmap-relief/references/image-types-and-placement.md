# Texture images versus single-subject images

## Two fundamentally different cases

### A. Repeating textures

Examples:
- carbon fibre;
- wood grain;
- fabric;
- stone;
- brushed or hammered metal.

Typical properties:
- seamless or made seamless;
- can repeat;
- often can be cropped;
- orientation matters;
- may span many faces or the full object.

### B. Single-subject images

Examples:
- a unicorn drawing;
- a logo;
- text or handwriting;
- a person portrait;
- an animal;
- a product photo or simplified object illustration.

Typical properties:
- must be placed once or a small number of times;
- aspect ratio should be preserved;
- crop must be controlled;
- background often needs cleanup;
- seams and distortion are much less acceptable.

## Recommended fit modes

### Repeating textures

Preferred order:
1. repeat
2. cover/crop
3. contain
4. stretch only when distortion is acceptable

Because the pattern repeats, cropping away some source area is often harmless and can even improve quality by isolating a cleaner tile.

### Single-subject images

Preferred order:
1. contain
2. controlled cover/crop
3. stretch only as a last resort

For text and logos, prefer vector reconstruction when possible.

## Background handling for single-subject images

For people, animals, and objects:
- remove or simplify the background;
- reduce large smooth lighting gradients if they do not represent desired geometry;
- preserve the subject silhouette;
- consider a subject mask and a soft edge fade into the surrounding base.

## Text and writing

Text is special:
- readability depends heavily on stroke width, not only on depth;
- very fine script often needs enlargement or embossing rather than deeper engraving;
- vector outlines are usually best for the primary letter shape;
- 16-bit raster relief can still add bevels or a stamped effect.

## When to use emboss versus engrave

### Texture

- engrave for subtle tactile texture and easier cleaning on some parts;
- emboss when shadows and highlights are important or when wall loss is undesirable.

### Single subject

- engrave when the subject should look carved or inset;
- emboss when the subject should stand proud, remain visible under shallow lighting, or when inward depth would weaken the part too much.

### Person/object/animal images

Emboss often shows better than engrave when the available wall thickness is limited, because you can add outward height instead of removing too much inward material.

## Placement strategy by image class

### Texture

- can wrap over full side walls;
- can continue over rounded corners;
- may use a single global object-space direction;
- may repeat over top, front, and side surfaces if that suits the design.

### Subject image

- usually choose a clear focal patch;
- avoid sending the face of a portrait over a corner or pole;
- keep writing on a relatively flat and readable area;
- for a cylinder, a subject can occupy a front patch while the back seam remains unused.

## Pole and corner warnings

A person, animal, or object image usually should not be stretched over:
- a sharp cube corner;
- the poles of a sphere;
- the narrow tip of a cone.

Instead:
- place the image on a bounded patch;
- use a fade or border before the problematic region;
- split the image into multiple designed panels if needed.
