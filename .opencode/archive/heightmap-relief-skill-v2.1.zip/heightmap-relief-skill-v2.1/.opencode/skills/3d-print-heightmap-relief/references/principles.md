# Principles and updated workflow

## The main failure to avoid

A common failure in image-based engraving or embossing is accidental tonal collapse:

- a grayscale image is thresholded;
- the image is exported as a low-bit or palette image;
- the relief generator treats it as essentially black and white;
- the resulting surface contains only two or three real height bands.

That destroys portraits, objects, animals, textures, shading, and subtle relief.

This skill therefore assumes a strict separation:

1. **Tonal precision in the master image** — keep continuous grayscale, normally 16-bit.
2. **Absolute physical relief depth** — choose the min-to-max physical depth in millimetres later.
3. **Manufacturing resolution** — the print process will still discretize the result, but that is the final fabrication limit, not an excuse to quantize the design early.

## 16-bit is the default design master

A 16-bit grayscale image does not mean the print will physically realize 65,536 distinct height levels. FDM still produces layers, and resin still has pixel and exposure limits. The benefit of 16-bit is that the design flow keeps smooth tonal information during:

- resize and filtering;
- gamma and contrast shaping;
- wrapping around geometry;
- conversion to meshes, displacement, or cutters.

The rule is simple:

- source master and target surface build heightmap: **16-bit grayscale PNG** by default;
- 8-bit only for previews or when clearly sufficient;
- binary or stepped levels only when intentionally requested.

## Absolute depth comes later

There are two distinct questions:

- **How many tonal levels should the image preserve?** → usually as many as practical, thus 16-bit processing.
- **How much physical height difference should the print use?** → chosen from wall safety, printer capability, and desired visual strength.

Do not confuse them. A shallow relief can still preserve all grayscale levels. A deep relief can still preserve all grayscale levels. Posterization is not a substitute for physical depth.

## When more visual effect is required

If a relief is too weak, use these levers first:

1. Increase the physical depth range.
2. Increase the physical size of the placed image so features become wider.
3. Use emboss instead of engrave when outward relief is structurally easier.
4. Adjust gamma or local contrast while keeping continuous tone.
5. Remove weak background gradients that consume the available depth range.
6. Use lighting-aware placement and print orientation.
7. Increase base wall thickness or shell thickness to allow more safe depth.

Only use deliberate stepping when a stylistic, topographic, or manufacturing reason exists.

## Two-stage image asset model

Use two persisted stages:

1. **Source master:** reusable AI-generated, supplied, or procedural image with an intended physical authoring size, square-pixel authoring/effective PPI, prompt/specification, and source manifest.
2. **Surface build heightmap:** target-specific 16-bit map derived from the source for one surface, printer, fit mode, and mapping orientation.

The CAD or mesh workflow should reference a stable build-heightmap path. Replacing the source and rerunning the job must rebuild that path without changing the placement logic.

## When the agent generates the source image

Before calling an AI image generator, define the intended physical image or tile size, requested generation PPI, and corresponding minimum native pixel dimensions. Include all three in the generation brief. After generation, inspect the actual file and calculate its effective PPI at the intended size; do not assume that a DPI phrase in the prompt was honored.

Keep the returned source untouched and place it in a replaceable source location. Generate the printer-specific 16-bit heightmap deterministically from a job manifest. See `rebuildable-jobs.md`.

## DPI/PPI matters, but mm matters more

For AI-generated images, the skill first creates a generation specification with physical authoring dimensions, square-pixel PPI, and requested pixels. After generation it registers the actual output and effective PPI. It then derives a separate target build image with explicit dpi_x/dpi_y because this improves traceability and interop. But many CAD and mesh workflows ignore DPI/PPI and use only raw pixel dimensions.

Therefore both stages require metadata. The source manifest contains requested and actual generation properties; every target build image must be paired with sidecar metadata containing:

- physical width and height in mm;
- pitch_x_mm and pitch_y_mm;
- dpi_x and dpi_y;
- pixel width and height;
- surface type and placement intent.

The source master plus source manifest define the replaceable asset. The persistent job JSON plus target build image and sidecar define the mapped engraving/embossing build.

## Textures and single subjects are different jobs

A seamless texture may be cropped, tiled, or repeated. A portrait, logo, person, animal, object, or single text mark normally should not.

The workflow must ask:

- Is the image supposed to repeat?
- Is the image allowed to be cropped?
- Is aspect ratio sacred?
- Should the image wrap continuously around edges or stay on one face only?
- Is it a global texture or a single placed graphic?

## Surface placement must match the surface class

Examples:

- **Flat face / cube side:** direct planar placement.
- **Cylinder:** cylindrical unwrap. One subject can be centered on a front patch, or a texture can wrap continuously around 360°.
- **Rounded box:** use one continuous side-wall coordinate if the design should continue across front, corners, and sides.
- **Sphere / ellipsoid:** use a bounded patch. Avoid forcing a single image over the poles unless distortion is acceptable.
- **Arbitrary mesh:** use UV mapping or local patch projection.

## Basic execution sequence

1. Classify the image.
2. Select the placement patch on the object.
3. Compute target pitch and pixel size.
4. Generate or register the reusable source master with authoring PPI metadata.
5. Derive the target-specific 16-bit surface build heightmap.
6. Choose depth from structure and visual goals.
7. Map to the chosen surface.
8. Build the relief with a deterministic geometry command.
9. Validate both geometry and appearance.
