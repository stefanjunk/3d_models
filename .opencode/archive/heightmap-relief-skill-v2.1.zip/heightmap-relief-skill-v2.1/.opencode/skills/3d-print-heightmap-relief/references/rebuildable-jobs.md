# Rebuildable relief jobs and image exchange

## Goal

The source artwork must be replaceable without editing the CAD placement logic, re-entering printer settings, or manually repeating image preprocessing.

A relief job therefore owns stable settings and paths:

```text
job/
├── relief-job.json
├── source/
│   ├── source-spec.json
│   ├── generation-prompt.txt
│   ├── source-master.png
│   └── source-master.png.source.json
└── build/
    ├── current-heightmap.png
    ├── current-heightmap.png.json
    ├── current-heightmap.png.build.json
    └── final-model.stl / STEP / 3MF
```

The CAD/mesh build references `build/current-heightmap.png`. That path stays the same when the source changes.

## Initialize a job

```bash
python scripts/init_relief_job.py jobs/carbon-organizer \
  --name carbon-organizer \
  --target-size-mm 220x45 \
  --source-size-mm 20x20 \
  --authoring-ppi 450 \
  --description "fine diagonal carbon-fibre weave height texture" \
  --image-class texture \
  --surface-type rounded_box \
  --placement-mode continuous_perimeter_wrap \
  --repeating --seamless-x --seamless-y \
  --process fdm --nozzle-mm 0.4 --layer-height-mm 0.2 \
  --axis-mode xy-z --fit repeat --tile-mm 20x20 \
  --mode engrave --depth-mm 0.25
```

This creates the source-generation prompt/specification and the persistent target-processing job.

## Register the first source and build

Separate commands:

```bash
python scripts/register_source_master.py generated-carbon.png \
  jobs/carbon-organizer/source/source-master.png \
  --spec jobs/carbon-organizer/source/source-spec.json \
  --source-kind ai-generated

python scripts/rebuild_relief_job.py jobs/carbon-organizer/relief-job.json
```

Or perform registration and rebuild in one command:

```bash
python scripts/rebuild_relief_job.py jobs/carbon-organizer/relief-job.json \
  --source generated-carbon.png \
  --register-source \
  --source-kind ai-generated
```

## Exchange the image later

```bash
python scripts/rebuild_relief_job.py jobs/carbon-organizer/relief-job.json \
  --source replacement-carbon.png \
  --register-source \
  --source-kind ai-generated \
  --run-geometry
```

That command:

1. applies the saved authoring size/PPI specification to the new source;
2. writes the canonical 16-bit source master and source manifest;
3. regenerates the stable target heightmap and build metadata;
4. optionally reruns the configured geometry command.

## Geometry command requirement

When an agent creates the actual OpenSCAD, CadQuery, FreeCAD, or Blender model, it should also populate `geometry.command` in `relief-job.json`. The command must be a JSON array, not a shell string. This avoids quoting ambiguity and is executed only when `--run-geometry` is explicitly supplied.

Example OpenSCAD command array:

```json
{
  "geometry": {
    "output_path": "build/final-model.stl",
    "cwd": ".",
    "command": [
      "openscad",
      "-o",
      "build/final-model.stl",
      "-D",
      "heightmap_file=\"{heightmap}\"",
      "-D",
      "relief_depth_mm={depth_mm}",
      "model.scad"
    ]
  }
}
```

Example CadQuery command array:

```json
{
  "geometry": {
    "command": [
      "python",
      "build_model.py",
      "--heightmap",
      "{heightmap}",
      "--heightmap-metadata",
      "{heightmap_metadata}",
      "--mode",
      "{mode}",
      "--depth-mm",
      "{depth_mm}",
      "--output",
      "build/final-model.step"
    ]
  }
}
```

Supported placeholders include:

- `{heightmap}` or `{processed_image}`
- `{heightmap_metadata}`
- `{build_manifest}`
- `{source}` or `{source_image}`
- `{source_manifest}`
- `{job}` or `{job_json}`
- `{job_dir}`
- `{output_model}`
- `{mode}`
- `{depth_mm}`

## Source replacement rules

- Use `--register-source` for a raw AI-generated or supplied image.
- Use plain `--source` only when the file is already a registered source master or intentionally bypasses source registration.
- Regenerate from the source master, never from an old target build heightmap.
- Preserve job settings unless the physical placement, printer, or relief intent genuinely changes.
- Verify the new source's crop, aspect ratio, seams, polarity, and slicer appearance after each replacement.
