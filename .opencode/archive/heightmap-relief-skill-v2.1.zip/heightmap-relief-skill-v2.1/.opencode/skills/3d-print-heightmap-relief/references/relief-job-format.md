# Rebuildable relief-job format

`relief-job.json` is the stable contract between the replaceable source image,
the deterministic heightmap processor, and the project-specific CAD/mesh build.

## Required sections

```json
{
  "schema_version": 1,
  "job_name": "example",
  "source": {},
  "target": {},
  "printer": {},
  "mapping": {},
  "classification": {},
  "processing": {},
  "relief": {},
  "outputs": {},
  "geometry": {}
}
```

### `source`

- `master_path`: active reusable 16-bit source master;
- `manifest_path`: source manifest containing authoring size/PPI, actual pixels,
  effective PPI, generation specification, and hash;
- `asset_id`: current source hash identifier;
- `generation_spec_path` and `generation_prompt_path`: AI-generation planning
  files used again when a raw replacement image is registered.

### `target`

Mapped physical width and height in millimetres. This is the complete surface
build area and may be much larger than one repeating source tile.

### `printer`

Process, nozzle/pixel size, and layer height used to derive the final target
pitch and `dpi_x`/`dpi_y`.

### `mapping`

Surface class, placement mode, and `axis_mode`. The axis mode records whether an
image direction follows printed XY or model Z.

### `classification`

Image class and whether it repeats. This controls safe fit and resizing rules.

### `processing`

Stable parameters such as fit mode, physical tile period, levels, gamma, invert,
and background. These settings must not be hidden in ad-hoc manual edits.

### `relief`

Emboss/engrave mode, physical depth, and wall-safety assumptions.

### `outputs`

Stable paths for the current 16-bit build heightmap, sidecar metadata, and build
manifest. The geometry stage consumes these paths.

### `geometry`

A project-specific command-array adapter. It runs only with `--run-geometry`.
Supported placeholders include:

- `{heightmap}` / `{processed_image}`;
- `{heightmap_metadata}`;
- `{build_manifest}`;
- `{source}` / `{source_image}`;
- `{source_manifest}`;
- `{job}` / `{job_json}`;
- `{job_dir}`;
- `{output_model}`;
- `{mode}` and `{depth_mm}`.

Use a JSON string array, never a shell command string. This keeps quoting
predictable and makes the rebuild inspectable.
