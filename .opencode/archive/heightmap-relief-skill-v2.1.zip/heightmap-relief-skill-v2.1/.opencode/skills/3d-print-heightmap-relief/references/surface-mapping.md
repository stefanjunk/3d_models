# Mapping to flat and curved surfaces

## Flat faces and cubes

For a single flat face on a cube or box, use a planar map. This is the cleanest case.

Guidance:
- textures may cover the full face or repeat;
- subject images should usually sit within margins;
- if the image should continue onto neighbouring rounded faces, switch to a continuous perimeter map rather than separate planar maps.

## Cylinders

Use cylindrical unwrapping.

Two distinct placement modes are common:

### Full-wrap texture or decorative band

- image repeats or spans 360°;
- seam should be hidden on the back or at a chosen start angle;
- around-cylinder axis uses nozzle-based XY pitch;
- vertical axis uses layer-height-based pitch on side walls.

### Front patch subject placement

- the image occupies only a front section of the cylinder;
- preserve aspect ratio;
- use contain or controlled cover;
- keep unused cylinder area as clean base or secondary texture.

## Rounded-rectangle side walls

If the design should continue around front, corners, and side walls, use one continuous perimeter coordinate based on arc length.

This is the correct approach for:
- carbon weave around a rounded organizer;
- lettering wrapped around a rounded box;
- a texture that should not rotate at each corner.

If the subject image belongs only on the front face, do not force it over the corner. Use a front patch and fade before the fillet radius.

## Spheres and balls

A full equirectangular map on a sphere creates severe distortion near the poles. That can be acceptable for global textures but is usually poor for a face, logo, or animal image.

Recommended modes:
- **front hemisphere patch** for portraits, animals, objects, and writing;
- **latitude-bounded decorative band** for textures or ornamental wraps;
- **full texture** only when distortion is acceptable or artistically desired.

Avoid placing critical eyes, letters, or facial landmarks near the poles.

## Ellipsoids

Ellipsoids behave like spheres with even more non-uniform distortion. Treat them as bounded-patch surfaces unless the image is a forgiving texture.

## Rounded edges and fillets

There are two valid strategies:

### Continuous wrap

Use when a texture or decorative band should travel naturally over the rounded edge.

### Patch plus margin/fade

Use when a subject image should remain visually undistorted on the main face.

Do not accidentally combine both. A portrait should usually stop before a tight corner.

## Cones and frustums

Conical surfaces unwrap into circular sectors. Width changes with height, so a vertically centered object image can distort if forced to full width. Prefer bounded patches for single-subject images.

## Arbitrary freeform surfaces

Use one of:
- UV unwrapping and displacement;
- local patch projection with trimming;
- object-space or triplanar texture projection for repeating textures.

### For repeating textures

Triplanar or object-space projection can be excellent when the goal is continuous texture and not a single undistorted picture.

### For single-subject images

UV mapping is usually the best option because it allows deliberate placement and distortion control.

## Choosing between one patch and full wrapping

Use **full wrapping** when:
- the image is a repeatable texture;
- the image is a decorative border designed to span the whole perimeter;
- seam placement is acceptable.

Use a **single bounded patch** when:
- the image is a person, animal, object, text, or logo;
- distortion would be visually obvious;
- the target surface includes poles or sharp corners.
