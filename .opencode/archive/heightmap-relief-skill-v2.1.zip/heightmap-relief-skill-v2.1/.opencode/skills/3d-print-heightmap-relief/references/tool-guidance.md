# Tool guidance: OpenSCAD, CadQuery, FreeCAD, Blender

## Common guidance for all tools

Before geometry generation:
- register a reusable source master with source manifest;
- derive a target-specific 16-bit surface build heightmap;
- compute and persist its physical scale and DPI/PPI;
- decide whether the image is a repeating texture or a single placed subject;
- avoid accidental palette export or thresholding.

## OpenSCAD

Best for:
- parametric base geometry;
- explicit procedural relationships;
- importing a prepared cutter or emboss tool.

Guidance:
- use OpenSCAD for the base object and for Boolean application when practical;
- do not rely on OpenSCAD to infer physical image scale from DPI alone;
- pass mm dimensions explicitly;
- for curved surfaces, prefer importing a pre-wrapped mesh cutter rather than trying to bend a flat raster workflow.

For text and logos, an SVG or vector route is often better for the main outline than a pure raster path.

## CadQuery

Best for:
- parametric solids and mechanical base geometry;
- generating clean cylinders, rounded boxes, shelves, and wall bodies;
- combining with imported mesh relief or displacement-generated cutters.

Guidance:
- keep the functional base parametric;
- treat dense image relief as a dedicated surface or mesh tool;
- store source and target image scaling metadata outside the CAD model as well;
- reference a stable build-heightmap path from the model so source replacement does not require editing CAD code.

## FreeCAD

Best for:
- hybrid CAD and mesh workflows;
- inspection and refinement;
- manual review and repair.

Guidance:
- import the prepared image-derived tool with explicit physical dimensions already decided;
- validate the result after Boolean operations;
- avoid workflows that silently simplify the image into too few levels.

## Blender

Best for:
- arbitrary UV mapping;
- displacement on curved and organic surfaces;
- placement of single-subject images on spheres, ellipsoids, and complex forms;
- repeating textures on freeform surfaces.

Guidance:
- use UVs for deliberate single-image placement;
- use triplanar or object-space projection for forgiving repeating textures;
- keep the image non-color and preserve 16-bit data where possible;
- add enough geometry density before displacement;
- check that the displacement scale, not the image bit depth, controls the visual strength.

## When to choose vector instead of raster

Prefer vector for:
- text;
- logos;
- crisp icons;
- sharp graphic symbols.

Prefer raster height maps for:
- textures;
- portraits;
- animal/object shading;
- bevels and rounded letterforms;
- deliberately tonal relief.

Hybrid workflows are often best: vector main outline plus raster microtexture or bevel map.
