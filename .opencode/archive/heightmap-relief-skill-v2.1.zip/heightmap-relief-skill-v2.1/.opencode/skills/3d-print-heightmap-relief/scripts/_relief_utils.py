#!/usr/bin/env python3
from __future__ import annotations

from dataclasses import dataclass, asdict
from pathlib import Path
import json
import math
from typing import Tuple

import numpy as np
from PIL import Image


@dataclass
class PitchRecommendation:
    pitch_x_mm: float
    pitch_y_mm: float
    dpi_x: float
    dpi_y: float
    pixel_width: int
    pixel_height: int
    axis_mode: str
    notes: list[str]

    def to_dict(self) -> dict:
        return asdict(self)


def clamp(value: float, low: float, high: float) -> float:
    return max(low, min(high, value))


def mm_to_dpi(mm_per_pixel: float) -> float:
    if mm_per_pixel <= 0:
        raise ValueError("mm_per_pixel must be > 0")
    return 25.4 / mm_per_pixel


def recommend_pitch(
    width_mm: float,
    height_mm: float,
    process: str = "fdm",
    nozzle_mm: float = 0.4,
    layer_height_mm: float = 0.2,
    resin_xy_mm: float = 0.05,
    axis_mode: str = "xy-z",
) -> PitchRecommendation:
    process = process.lower()
    axis_mode = axis_mode.lower()
    notes: list[str] = []

    if process == "fdm":
        pitch_xy = clamp(nozzle_mm * 0.5, 0.08, nozzle_mm * 0.75)
        pitch_z = clamp(layer_height_mm * 1.0, 0.04, 0.30)
        notes.append(
            f"FDM heuristic: pitch_xy=nozzle*0.5={pitch_xy:.4g} mm, pitch_z=layer_height*1.0={pitch_z:.4g} mm"
        )
    elif process in {"resin", "sla", "msla", "dlp"}:
        pitch_xy = clamp(resin_xy_mm, 0.01, 0.10)
        pitch_z = clamp(layer_height_mm, 0.01, 0.10)
        notes.append(
            f"Resin heuristic: pitch_xy≈pixel_size={pitch_xy:.4g} mm, pitch_z≈layer_height={pitch_z:.4g} mm"
        )
    else:
        raise ValueError("process must be one of: fdm, resin, sla, msla, dlp")

    if axis_mode == "xy-xy":
        pitch_x = pitch_xy
        pitch_y = pitch_xy
        notes.append("Both image axes map mainly to printed XY directions.")
    elif axis_mode == "xy-z":
        pitch_x = pitch_xy
        pitch_y = pitch_z
        notes.append("Image X maps mainly to printed XY; image Y maps mainly to model Z.")
    elif axis_mode == "z-xy":
        pitch_x = pitch_z
        pitch_y = pitch_xy
        notes.append("Image X maps mainly to model Z; image Y maps mainly to printed XY.")
    elif axis_mode == "mixed":
        pitch_x = pitch_xy
        pitch_y = min(pitch_xy, max(pitch_z, pitch_xy * 0.75))
        notes.append("Mixed curved-surface heuristic used; inspect for oversampling or undersampling.")
    else:
        raise ValueError("axis_mode must be one of: xy-xy, xy-z, z-xy, mixed")

    pixel_width = max(1, int(round(width_mm / pitch_x)))
    pixel_height = max(1, int(round(height_mm / pitch_y)))

    return PitchRecommendation(
        pitch_x_mm=pitch_x,
        pitch_y_mm=pitch_y,
        dpi_x=mm_to_dpi(pitch_x),
        dpi_y=mm_to_dpi(pitch_y),
        pixel_width=pixel_width,
        pixel_height=pixel_height,
        axis_mode=axis_mode,
        notes=notes,
    )


def load_grayscale_float(path: str | Path, background: int = 255) -> tuple[np.ndarray, dict]:
    """Load image as float32 grayscale in [0,1], preserving as much tonal info as practical.

    - If the input is 16-bit grayscale, it is normalized from 0..65535.
    - If the input has alpha, alpha is composited over a solid grayscale background.
    - Color images are converted with luminance weights.
    """
    p = Path(path)
    with Image.open(p) as im:
        info = {
            "source_mode": im.mode,
            "source_size": list(im.size),
        }
        if im.mode in {"I;16", "I;16L", "I;16B"}:
            arr = np.array(im, dtype=np.uint16).astype(np.float32) / 65535.0
            info["source_bit_depth_guess"] = 16
            return arr, info
        if im.mode == "L":
            arr = np.array(im, dtype=np.uint8).astype(np.float32) / 255.0
            info["source_bit_depth_guess"] = 8
            return arr, info

        rgba = np.array(im.convert("RGBA"), dtype=np.float32) / 255.0
        bg = float(background) / 255.0
        rgb = rgba[..., :3]
        alpha = rgba[..., 3:4]
        comp = rgb * alpha + bg * (1.0 - alpha)
        gray = 0.2126 * comp[..., 0] + 0.7152 * comp[..., 1] + 0.0722 * comp[..., 2]
        info["source_bit_depth_guess"] = 8
        return gray.astype(np.float32), info


def float_to_pil_f(arr: np.ndarray) -> Image.Image:
    arr = np.asarray(arr, dtype=np.float32)
    return Image.fromarray(arr, mode="F")


def resize_float(arr: np.ndarray, size: Tuple[int, int]) -> np.ndarray:
    im = float_to_pil_f(arr)
    out = im.resize(size, resample=Image.Resampling.LANCZOS)
    return np.asarray(out, dtype=np.float32)


def fit_image(
    arr: np.ndarray,
    target_size: Tuple[int, int],
    fit: str = "contain",
    background_value: float = 1.0,
    tile_size: Tuple[int, int] | None = None,
) -> tuple[np.ndarray, dict]:
    target_w, target_h = target_size
    src_h, src_w = arr.shape
    fit = fit.lower()
    meta: dict = {"fit_mode": fit}

    if fit == "stretch":
        out = resize_float(arr, (target_w, target_h))
        meta["aspect_ratio_preserved"] = False
        meta["scale_x"] = target_w / src_w
        meta["scale_y"] = target_h / src_h
        return out, meta

    if fit in {"contain", "cover"}:
        src_ratio = src_w / src_h
        dst_ratio = target_w / target_h
        if fit == "contain":
            scale = min(target_w / src_w, target_h / src_h)
        else:
            scale = max(target_w / src_w, target_h / src_h)
        new_w = max(1, int(round(src_w * scale)))
        new_h = max(1, int(round(src_h * scale)))
        resized = resize_float(arr, (new_w, new_h))
        meta["aspect_ratio_preserved"] = True
        meta["scale_uniform"] = scale
        if fit == "contain":
            out = np.full((target_h, target_w), background_value, dtype=np.float32)
            x0 = (target_w - new_w) // 2
            y0 = (target_h - new_h) // 2
            out[y0:y0 + new_h, x0:x0 + new_w] = resized
            meta["padding"] = {"left": x0, "right": target_w - new_w - x0, "top": y0, "bottom": target_h - new_h - y0}
            return out, meta
        # cover
        x0 = max(0, (new_w - target_w) // 2)
        y0 = max(0, (new_h - target_h) // 2)
        out = resized[y0:y0 + target_h, x0:x0 + target_w]
        meta["crop_from_resized"] = {"left": x0, "top": y0}
        return out, meta

    if fit == "repeat":
        if tile_size is None:
            tile_w, tile_h = src_w, src_h
        else:
            tile_w, tile_h = tile_size
        tile = resize_float(arr, (max(1, tile_w), max(1, tile_h)))
        reps_x = int(math.ceil(target_w / tile.shape[1]))
        reps_y = int(math.ceil(target_h / tile.shape[0]))
        out = np.tile(tile, (reps_y, reps_x))[:target_h, :target_w]
        meta["aspect_ratio_preserved"] = True
        meta["tile_size_px"] = [tile.shape[1], tile.shape[0]]
        meta["repeat_counts"] = [reps_x, reps_y]
        return out.astype(np.float32), meta

    raise ValueError("fit must be one of: contain, cover, stretch, repeat")


def apply_levels_gamma(
    arr: np.ndarray,
    black_point: float = 0.0,
    white_point: float = 1.0,
    gamma: float = 1.0,
    invert: bool = False,
) -> np.ndarray:
    if white_point <= black_point:
        raise ValueError("white_point must be greater than black_point")
    out = np.clip((arr - black_point) / (white_point - black_point), 0.0, 1.0)
    if invert:
        out = 1.0 - out
    if gamma != 1.0:
        gamma = max(1e-6, gamma)
        out = np.power(out, gamma)
    return np.clip(out, 0.0, 1.0).astype(np.float32)


def save_16bit_png(arr: np.ndarray, path: str | Path, dpi_x: float, dpi_y: float) -> None:
    p = Path(path)
    p.parent.mkdir(parents=True, exist_ok=True)
    u16 = np.clip(np.round(np.asarray(arr, dtype=np.float32) * 65535.0), 0, 65535).astype(np.uint16)
    im = Image.fromarray(u16, mode="I;16")
    # Pillow can embed a dpi tuple for PNG; the sidecar JSON remains authoritative.
    im.save(p, dpi=(float(dpi_x), float(dpi_y)))


def sidecar_path(output_path: str | Path) -> Path:
    p = Path(output_path)
    return p.with_suffix(p.suffix + ".json")


def write_json(path: str | Path, data: dict) -> None:
    p = Path(path)
    p.parent.mkdir(parents=True, exist_ok=True)
    p.write_text(json.dumps(data, indent=2, sort_keys=True), encoding="utf-8")


def estimate_upscale(src_size: tuple[int, int], target_size: tuple[int, int], preserve_ar: bool) -> dict:
    src_w, src_h = src_size
    dst_w, dst_h = target_size
    sx = dst_w / src_w
    sy = dst_h / src_h
    warnings: list[str] = []
    if preserve_ar:
        s = max(sx, sy)
        if s > 2.0:
            warnings.append("Upscaling exceeds 200%; strongly consider a better source or smaller placement.")
        elif s > 1.5:
            warnings.append("Upscaling exceeds 150%; inspect for softness or missing detail.")
        elif s > 1.25:
            warnings.append("Upscaling exceeds 125%; acceptable only after inspection.")
    else:
        if max(sx, sy) > 1.5:
            warnings.append("Non-uniform or strong upscaling may visibly degrade image quality.")
        stretch = max(sx / sy if sy else float('inf'), sy / sx if sx else float('inf'))
        if stretch > 1.10:
            warnings.append("Aspect-ratio stretch exceeds 10%; use only when distortion is acceptable.")
        elif stretch > 1.05:
            warnings.append("Aspect-ratio stretch exceeds 5%; unsuitable for most subject images and text.")
    return {
        "scale_x": sx,
        "scale_y": sy,
        "warnings": warnings,
    }


def recommended_depth_range(image_class: str, mode: str) -> tuple[tuple[float, float], str]:
    image_class = image_class.lower()
    mode = mode.lower()
    if image_class in {"texture", "pattern", "carbon", "wood"}:
        return ((0.10, 0.35) if mode == "engrave" else (0.20, 0.50), "Texture heuristic.")
    if image_class in {"text", "logo", "motif"}:
        return ((0.30, 0.80) if mode == "engrave" else (0.50, 1.20), "Text/logo heuristic.")
    if image_class in {"object", "person", "animal", "portrait", "photo", "subject"}:
        return ((0.30, 0.90) if mode == "engrave" else (0.60, 1.50), "Single-subject image heuristic.")
    return ((0.20, 0.60) if mode == "engrave" else (0.50, 1.00), "General heuristic.")


def minimum_remaining_wall(nozzle_mm: float) -> float:
    return max(1.2, 3.0 * nozzle_mm)


def sha256_file(path: str | Path) -> str:
    import hashlib

    h = hashlib.sha256()
    with Path(path).open("rb") as f:
        for chunk in iter(lambda: f.read(1024 * 1024), b""):
            h.update(chunk)
    return h.hexdigest()


def read_json(path: str | Path) -> dict:
    return json.loads(Path(path).read_text(encoding="utf-8"))


def pixels_for_physical_size(width_mm: float, height_mm: float, ppi: float) -> tuple[int, int]:
    if width_mm <= 0 or height_mm <= 0 or ppi <= 0:
        raise ValueError("physical size and ppi must be positive")
    return (
        max(1, int(round(width_mm / 25.4 * ppi))),
        max(1, int(round(height_mm / 25.4 * ppi))),
    )


def effective_ppi(pixel_width: int, pixel_height: int, width_mm: float, height_mm: float) -> tuple[float, float]:
    if pixel_width <= 0 or pixel_height <= 0 or width_mm <= 0 or height_mm <= 0:
        raise ValueError("pixels and physical size must be positive")
    return (
        pixel_width / (width_mm / 25.4),
        pixel_height / (height_mm / 25.4),
    )


def seam_metrics(arr: np.ndarray) -> dict[str, float]:
    """Return normalized mean/max edge mismatch for X and Y borders."""
    a = np.asarray(arr, dtype=np.float32)
    if a.ndim != 2 or min(a.shape) < 2:
        return {"x_mean_abs": 0.0, "x_max_abs": 0.0, "y_mean_abs": 0.0, "y_max_abs": 0.0}
    x = np.abs(a[:, 0] - a[:, -1])
    y = np.abs(a[0, :] - a[-1, :])
    return {
        "x_mean_abs": float(np.mean(x)),
        "x_max_abs": float(np.max(x)),
        "y_mean_abs": float(np.mean(y)),
        "y_max_abs": float(np.max(y)),
    }


def fit_image_physical(
    arr: np.ndarray,
    target_size: Tuple[int, int],
    target_size_mm: Tuple[float, float],
    pitch_mm: Tuple[float, float],
    fit: str = "contain",
    background_value: float = 1.0,
    tile_size_mm: Tuple[float, float] | None = None,
    source_size_mm: Tuple[float, float] | None = None,
) -> tuple[np.ndarray, dict]:
    """Fit an image in physical coordinates, allowing non-square output pixels.

    Source pixels are assumed square, as is standard for AI-generated and most
    raster images. The output may intentionally have different X/Y pitch because
    one surface axis can be nozzle-limited while another is layer-height-limited.
    """
    target_w_px, target_h_px = target_size
    target_w_mm, target_h_mm = target_size_mm
    pitch_x_mm, pitch_y_mm = pitch_mm
    src_h, src_w = arr.shape
    fit = fit.lower()
    if source_size_mm is not None:
        source_w_mm, source_h_mm = source_size_mm
        if source_w_mm <= 0 or source_h_mm <= 0:
            raise ValueError("source_size_mm must be positive")
        src_aspect = source_w_mm / source_h_mm
        source_aspect_basis = "source_manifest_physical_size"
    else:
        src_aspect = src_w / src_h
        source_aspect_basis = "square_source_pixels"
    target_aspect = target_w_mm / target_h_mm
    meta: dict = {
        "fit_mode": fit,
        "physical_coordinate_fit": True,
        "source_aspect_basis": source_aspect_basis,
        "source_size_mm": list(source_size_mm) if source_size_mm is not None else None,
        "source_aspect_ratio": src_aspect,
        "target_physical_aspect_ratio": target_aspect,
    }

    if fit == "stretch":
        out = resize_float(arr, (target_w_px, target_h_px))
        meta["aspect_ratio_preserved_physically"] = False
        meta["placed_size_mm"] = [target_w_mm, target_h_mm]
        return out, meta

    if fit in {"contain", "cover"}:
        if fit == "contain":
            if src_aspect >= target_aspect:
                placed_w_mm = target_w_mm
                placed_h_mm = target_w_mm / src_aspect
            else:
                placed_h_mm = target_h_mm
                placed_w_mm = target_h_mm * src_aspect
        else:  # cover
            if src_aspect >= target_aspect:
                placed_h_mm = target_h_mm
                placed_w_mm = target_h_mm * src_aspect
            else:
                placed_w_mm = target_w_mm
                placed_h_mm = target_w_mm / src_aspect

        placed_w_px = max(1, int(round(placed_w_mm / pitch_x_mm)))
        placed_h_px = max(1, int(round(placed_h_mm / pitch_y_mm)))
        resized = resize_float(arr, (placed_w_px, placed_h_px))
        meta["aspect_ratio_preserved_physically"] = True
        meta["placed_size_mm"] = [placed_w_mm, placed_h_mm]
        meta["placed_size_px"] = [placed_w_px, placed_h_px]

        if fit == "contain":
            out = np.full((target_h_px, target_w_px), background_value, dtype=np.float32)
            x0 = max(0, (target_w_px - placed_w_px) // 2)
            y0 = max(0, (target_h_px - placed_h_px) // 2)
            x1 = min(target_w_px, x0 + placed_w_px)
            y1 = min(target_h_px, y0 + placed_h_px)
            out[y0:y1, x0:x1] = resized[: y1 - y0, : x1 - x0]
            meta["padding_px"] = {
                "left": x0,
                "right": target_w_px - x1,
                "top": y0,
                "bottom": target_h_px - y1,
            }
            return out, meta

        crop_x = max(0, (placed_w_px - target_w_px) // 2)
        crop_y = max(0, (placed_h_px - target_h_px) // 2)
        out = resized[crop_y:crop_y + target_h_px, crop_x:crop_x + target_w_px]
        if out.shape != (target_h_px, target_w_px):
            padded = np.full((target_h_px, target_w_px), background_value, dtype=np.float32)
            padded[: out.shape[0], : out.shape[1]] = out
            out = padded
        meta["crop_px"] = {"left": crop_x, "top": crop_y}
        return out, meta

    if fit == "repeat":
        if tile_size_mm is None:
            tile_w_mm, tile_h_mm = target_w_mm, target_h_mm
            meta["repeat_without_explicit_tile_mm"] = True
        else:
            tile_w_mm, tile_h_mm = tile_size_mm
            meta["repeat_without_explicit_tile_mm"] = False
        tile_w_px = max(1, int(round(tile_w_mm / pitch_x_mm)))
        tile_h_px = max(1, int(round(tile_h_mm / pitch_y_mm)))
        tile = resize_float(arr, (tile_w_px, tile_h_px))
        reps_x = int(math.ceil(target_w_px / tile_w_px))
        reps_y = int(math.ceil(target_h_px / tile_h_px))
        out = np.tile(tile, (reps_y, reps_x))[:target_h_px, :target_w_px]
        meta["aspect_ratio_preserved_physically"] = True
        meta["tile_size_mm"] = [tile_w_mm, tile_h_mm]
        meta["tile_size_px"] = [tile_w_px, tile_h_px]
        meta["repeat_counts"] = [reps_x, reps_y]
        return out.astype(np.float32), meta

    raise ValueError("fit must be one of: contain, cover, stretch, repeat")
