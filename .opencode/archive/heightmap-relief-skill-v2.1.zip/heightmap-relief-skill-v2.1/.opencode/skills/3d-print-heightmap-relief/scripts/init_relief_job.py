#!/usr/bin/env python3
"""Initialize a source-swappable relief job plus AI source-generation specification."""
from __future__ import annotations

import argparse
import json
import math
from pathlib import Path
import re

from _relief_utils import recommend_pitch, recommended_depth_range, write_json


def parse_pair(text: str) -> tuple[float, float]:
    for sep in ("x", "X", ",", ";", " "):
        if sep in text:
            a, b = text.split(sep, 1)
            return float(a), float(b)
    value = float(text)
    return value, value


def safe_name(value: str) -> str:
    value = re.sub(r"[^A-Za-z0-9._-]+", "-", value.strip()).strip("-")
    return value or "relief-job"


def round_authoring_ppi(value: float) -> float:
    common = [300, 450, 600, 900, 1200]
    for ppi in common:
        if ppi >= value:
            return float(ppi)
    return float(math.ceil(value / 100.0) * 100.0)


def main() -> int:
    p = argparse.ArgumentParser(description="Create a persistent relief job, AI source spec, and prompt.")
    p.add_argument("job_dir")
    p.add_argument("--name", default="relief-job")
    p.add_argument("--target-size-mm", required=True, type=parse_pair, help="Mapped surface area, e.g. 120x70")
    p.add_argument("--source-size-mm", type=parse_pair, help="Reusable source/tile authoring size; defaults to target size")
    p.add_argument("--authoring-ppi", type=float, help="Source-master PPI; defaults to 1.5x finest target PPI rounded up")
    p.add_argument("--description", required=True)
    p.add_argument("--image-class", default="texture")
    p.add_argument("--surface-type", default="plane")
    p.add_argument("--placement-mode", default="single_patch")
    p.add_argument("--repeating", action="store_true")
    p.add_argument("--seamless-x", action="store_true")
    p.add_argument("--seamless-y", action="store_true")
    p.add_argument("--polarity", default="white-high", choices=["white-high", "white-low"])
    p.add_argument("--mode", choices=["engrave", "emboss"], default="engrave")
    p.add_argument("--process", choices=["fdm", "resin", "sla", "msla", "dlp"], default="fdm")
    p.add_argument("--nozzle-mm", type=float, default=0.4)
    p.add_argument("--layer-height-mm", type=float, default=0.2)
    p.add_argument("--resin-xy-mm", type=float, default=0.05)
    p.add_argument("--axis-mode", choices=["xy-xy", "xy-z", "z-xy", "mixed"], default="xy-z")
    p.add_argument("--fit", choices=["contain", "cover", "stretch", "repeat"])
    p.add_argument("--tile-mm", type=parse_pair)
    p.add_argument("--depth-mm", type=float)
    p.add_argument("--wall-thickness-mm", type=float, default=2.0)
    args = p.parse_args()

    job_dir = Path(args.job_dir).resolve()
    source_dir = job_dir / "source"
    build_dir = job_dir / "build"
    source_dir.mkdir(parents=True, exist_ok=True)
    build_dir.mkdir(parents=True, exist_ok=True)

    width_mm, height_mm = args.target_size_mm
    source_width_mm, source_height_mm = args.source_size_mm or args.tile_mm or args.target_size_mm

    rec = recommend_pitch(
        width_mm=width_mm,
        height_mm=height_mm,
        process=args.process,
        nozzle_mm=args.nozzle_mm,
        layer_height_mm=args.layer_height_mm,
        resin_xy_mm=args.resin_xy_mm,
        axis_mode=args.axis_mode,
    )
    authoring_ppi = args.authoring_ppi or round_authoring_ppi(max(rec.dpi_x, rec.dpi_y) * 1.5)
    source_px_w = max(1, int(round(source_width_mm / 25.4 * authoring_ppi)))
    source_px_h = max(1, int(round(source_height_mm / 25.4 * authoring_ppi)))
    fit = args.fit or ("repeat" if args.repeating else "contain")
    depth_range, depth_note = recommended_depth_range(args.image_class, args.mode)
    depth_mm = args.depth_mm if args.depth_mm is not None else sum(depth_range) / 2.0

    source_spec_rel = "source/source-spec.json"
    prompt_rel = "source/generation-prompt.txt"
    master_rel = "source/source-master.png"
    manifest_rel = "source/source-master.png.source.json"
    heightmap_rel = "build/current-heightmap.png"
    heightmap_meta_rel = "build/current-heightmap.png.json"
    build_manifest_rel = "build/current-heightmap.png.build.json"

    source_spec = {
        "schema_version": 1,
        "stage": "ai_generation_spec",
        "description": args.description,
        "image_class": args.image_class,
        "physical_authoring": {
            "width_mm": source_width_mm,
            "height_mm": source_height_mm,
            "authoring_ppi": authoring_ppi,
            "square_pixels": True,
        },
        "requested_raster": {
            "pixel_width": source_px_w,
            "pixel_height": source_px_h,
            "requested_bit_depth": 16,
            "requested_color_mode": "grayscale",
        },
        "semantic": {
            "polarity": args.polarity,
            "seamless_x": args.seamless_x,
            "seamless_y": args.seamless_y,
            "repeating": args.repeating,
        },
    }

    prompt = (
        "Create a grayscale height-map source image for 3D-print relief.\n\n"
        f"Subject: {args.description}\n"
        f"Physical authoring size: {source_width_mm:g} × {source_height_mm:g} mm\n"
        f"Authoring density: {authoring_ppi:g} PPI with square pixels\n"
        f"Requested raster: {source_px_w} × {source_px_h} pixels\n"
        f"Image class: {args.image_class}\n\n"
        "Preserve continuous grayscale and smooth tonal transitions. Do not threshold, posterize, dither, or reduce the image to a small number of levels. "
        "Request 16-bit grayscale when supported; otherwise use the highest continuous-tone output available and report actual pixels. "
        f"Polarity: {args.polarity}. "
        f"Repeating: {args.repeating}; seamless X: {args.seamless_x}; seamless Y: {args.seamless_y}. "
        "Luminance must represent intended relief rather than photographic lighting. Avoid false geometry from cast shadows, highlights, perspective, watermarks, or presentation mockups. "
        "The actual output will be inspected and registered; do not claim the requested PPI or bit depth was honored without verification.\n"
    )
    source_spec["generation_prompt"] = prompt

    job = {
        "schema_version": 1,
        "skill_version": "2.1.0",
        "job_name": safe_name(args.name),
        "source": {
            "master_path": master_rel,
            "manifest_path": manifest_rel,
            "generation_spec_path": source_spec_rel,
            "generation_prompt_path": prompt_rel,
            "asset_id": None,
        },
        "target": {
            "width_mm": width_mm,
            "height_mm": height_mm,
        },
        "printer": {
            "process": args.process,
            "nozzle_mm": args.nozzle_mm,
            "layer_height_mm": args.layer_height_mm,
            "resin_xy_mm": args.resin_xy_mm,
        },
        "mapping": {
            "axis_mode": args.axis_mode,
            "surface_type": args.surface_type,
            "placement_mode": args.placement_mode,
        },
        "classification": {
            "image_class": args.image_class,
            "surface_type": args.surface_type,
            "placement_mode": args.placement_mode,
            "repeating": args.repeating,
        },
        "processing": {
            "fit_mode": fit,
            "tile_mm": list(args.tile_mm) if args.tile_mm else None,
            "black_point": 0.0,
            "white_point": 1.0,
            "gamma": 1.0,
            "invert": False,
            "background_gray": 255,
        },
        "relief": {
            "mode": args.mode,
            "depth_mm": depth_mm,
            "recommended_depth_range_mm": list(depth_range),
            "recommendation_note": depth_note,
            "wall_thickness_mm": args.wall_thickness_mm,
        },
        "outputs": {
            "heightmap": heightmap_rel,
            "heightmap_metadata": heightmap_meta_rel,
            "build_manifest": build_manifest_rel,
        },
        "geometry": {
            "output_path": "build/final-model.stl",
            "command": [],
            "cwd": ".",
            "help": "Optional command array. Supported placeholders include {heightmap}/{processed_image}, {heightmap_metadata}, {build_manifest}, {source}/{source_image}, {source_manifest}, {job}/{job_json}, {job_dir}, {output_model}, {mode}, and {depth_mm}.",
        },
        "notes": "Use rebuild_relief_job.py --source NEW_IMAGE --register-source to replace artwork; do not hand-edit build/current-heightmap.png.",
    }

    write_json(job_dir / "relief-job.json", job)
    write_json(job_dir / source_spec_rel, source_spec)
    (job_dir / prompt_rel).write_text(prompt, encoding="utf-8")
    (source_dir / "README.md").write_text(
        "1. Generate/select an image using generation-prompt.txt.\n"
        "2. Run rebuild_relief_job.py ../relief-job.json --source NEW_IMAGE --register-source.\n"
        "3. Add --run-geometry after geometry.command is configured to rebuild the final model too.\n"
        "Do not edit build/current-heightmap.png directly; it is reproducible.\n",
        encoding="utf-8",
    )

    print(f"Created job: {job_dir / 'relief-job.json'}")
    print(f"Created generation spec: {job_dir / source_spec_rel}")
    print(f"Created generation prompt: {job_dir / prompt_rel}")
    print(f"Requested source: {source_px_w}x{source_px_h} px at {authoring_ppi:.2f} PPI for {source_width_mm:g}x{source_height_mm:g} mm")
    print(f"Target build recommendation: {rec.pixel_width}x{rec.pixel_height} px at {rec.dpi_x:.2f}x{rec.dpi_y:.2f} PPI")
    print("After generation, register the image and rebuild the job.")
    return 0


if __name__ == "__main__":
    raise SystemExit(main())
