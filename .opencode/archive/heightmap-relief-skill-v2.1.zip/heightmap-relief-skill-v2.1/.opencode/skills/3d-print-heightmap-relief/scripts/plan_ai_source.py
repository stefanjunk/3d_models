#!/usr/bin/env python3
"""Create a reproducible generation specification for an AI-created relief source image."""
from __future__ import annotations

import argparse
from pathlib import Path

from _relief_utils import pixels_for_physical_size, write_json


def parse_pair(text: str) -> tuple[float, float]:
    for sep in ("x", ",", ";", " "):
        if sep in text:
            a, b = text.split(sep, 1)
            return float(a), float(b)
    raise argparse.ArgumentTypeError("expected pair like 50x50")


def main() -> int:
    p = argparse.ArgumentParser(
        description="Plan an AI-generated grayscale relief source with explicit physical size, authoring PPI, and requested pixels."
    )
    p.add_argument("--description", required=True, help="Semantic description of the desired image")
    p.add_argument("--physical-size-mm", required=True, type=parse_pair, help="Authoring size, e.g. 50x50")
    p.add_argument("--authoring-ppi", required=True, type=float, help="Square-pixel authoring PPI, e.g. 300")
    p.add_argument("--image-class", default="texture", help="texture, motif, text, person, animal, object, portrait, etc.")
    p.add_argument("--polarity", default="white-high", choices=["white-high", "white-low"])
    p.add_argument("--seamless-x", action="store_true")
    p.add_argument("--seamless-y", action="store_true")
    p.add_argument("--preferred-direction", default="", help="Optional grain/weave/artwork direction")
    p.add_argument("--background", default="neutral clean background")
    p.add_argument("--output-spec", required=True)
    p.add_argument("--output-prompt", required=True)
    args = p.parse_args()

    width_mm, height_mm = args.physical_size_mm
    pixel_width, pixel_height = pixels_for_physical_size(width_mm, height_mm, args.authoring_ppi)
    is_texture = args.image_class.lower() in {"texture", "pattern", "wood", "carbon", "fabric", "stone"}

    seamless_parts: list[str] = []
    if args.seamless_x:
        seamless_parts.append("left and right borders must tile seamlessly")
    if args.seamless_y:
        seamless_parts.append("top and bottom borders must tile seamlessly")
    if seamless_parts:
        seamless_sentence = "; ".join(seamless_parts) + "."
    else:
        seamless_sentence = "This is a single non-repeating image; do not tile or duplicate the subject."

    polarity_sentence = (
        "White represents higher/outward relief and black represents lower/inward relief."
        if args.polarity == "white-high"
        else "White represents lower/inward relief and black represents higher/outward relief."
    )

    class_sentence = (
        "Treat it as a repeatable material height texture with no perspective, directional lighting, cast shadows, glossy highlights, labels, or isolated border features."
        if is_texture
        else "Treat it as one clearly placed subject. Preserve aspect ratio, protect important features from cropping, use a simple clean background, and do not repeat the subject."
    )

    direction_sentence = f"Preferred physical direction: {args.preferred_direction}." if args.preferred_direction else ""

    prompt = f"""Create a grayscale height-map source image for 3D-print relief.

Subject: {args.description}
Physical authoring size: {width_mm:g} × {height_mm:g} mm
Authoring density: {args.authoring_ppi:g} PPI with square pixels
Requested raster: {pixel_width} × {pixel_height} pixels
Image class: {args.image_class}

Preserve continuous grayscale and smooth tonal transitions. Do not threshold, posterize, dither, or reduce the image to a small number of levels. Request 16-bit grayscale output when supported; otherwise return the highest continuous-tone output available for later 16-bit registration. {polarity_sentence}

{class_sentence}
{seamless_sentence}
{direction_sentence}
Background requirement: {args.background}.

Luminance must describe intended physical relief, not photographic illumination. Avoid false geometry caused by shadows, highlights, perspective, color-only variation, text labels, frames, or watermarks. Return the closest supported raster and aspect ratio, but do not claim the requested PPI was honored; the actual output will be inspected and registered afterward."""

    warnings: list[str] = []
    total_pixels = pixel_width * pixel_height
    if total_pixels > 20_000_000:
        warnings.append("Requested source exceeds 20 million pixels; consider a smaller authoring area/PPI or a tiled procedural source.")
    elif total_pixels > 8_000_000:
        warnings.append("Requested source exceeds 8 million pixels; confirm the generator and memory budget support it.")

    spec = {
        "schema_version": 1,
        "stage": "ai_generation_spec",
        "description": args.description,
        "image_class": args.image_class,
        "physical_authoring": {
            "width_mm": width_mm,
            "height_mm": height_mm,
            "authoring_ppi": args.authoring_ppi,
            "square_pixels": True,
        },
        "requested_raster": {
            "pixel_width": pixel_width,
            "pixel_height": pixel_height,
            "requested_bit_depth": 16,
            "requested_color_mode": "grayscale",
        },
        "semantic": {
            "polarity": args.polarity,
            "seamless_x": args.seamless_x,
            "seamless_y": args.seamless_y,
            "preferred_direction": args.preferred_direction,
            "background": args.background,
            "repeating": bool(args.seamless_x or args.seamless_y or is_texture),
        },
        "generation_prompt": prompt,
        "warnings": warnings,
        "verification_required": [
            "actual pixel dimensions",
            "actual image mode and source precision",
            "effective PPI at intended physical size",
            "seam mismatch when seamless output was requested",
            "absence of thresholding/posterization",
        ],
    }

    write_json(args.output_spec, spec)
    out_prompt = Path(args.output_prompt)
    out_prompt.parent.mkdir(parents=True, exist_ok=True)
    out_prompt.write_text(prompt + "\n", encoding="utf-8")

    print(f"Wrote generation spec: {args.output_spec}")
    print(f"Wrote prompt: {args.output_prompt}")
    print(f"Requested: {pixel_width}x{pixel_height} px for {width_mm:g}x{height_mm:g} mm at {args.authoring_ppi:g} PPI")
    for warning in warnings:
        print(f"warning: {warning}")
    return 0


if __name__ == "__main__":
    raise SystemExit(main())
