#!/usr/bin/env python3
"""Derive a target-specific 16-bit surface build heightmap from a reusable source master."""
from __future__ import annotations

import argparse
from pathlib import Path
from typing import Any

from _relief_utils import (
    apply_levels_gamma,
    estimate_upscale,
    fit_image_physical,
    load_grayscale_float,
    read_json,
    recommend_pitch,
    save_16bit_png,
    sha256_file,
    sidecar_path,
    write_json,
)


def parse_mm_pair(text: str) -> tuple[float, float]:
    for sep in ("x", ",", ";", " "):
        if sep in text:
            a, b = text.split(sep, 1)
            return float(a), float(b)
    raise argparse.ArgumentTypeError("expected pair like 120x70")


def prepare_heightmap(
    *,
    input_image: str | Path,
    output_png: str | Path,
    width_mm: float,
    height_mm: float,
    pitch_mm: tuple[float, float] | None = None,
    process: str = "fdm",
    nozzle_mm: float = 0.4,
    layer_height_mm: float = 0.2,
    resin_xy_mm: float = 0.05,
    axis_mode: str = "xy-z",
    fit: str = "contain",
    tile_mm: tuple[float, float] | None = None,
    image_class: str = "subject",
    surface_type: str = "plane",
    placement_mode: str = "single_patch",
    black_point: float = 0.0,
    white_point: float = 1.0,
    gamma: float = 1.0,
    invert: bool = False,
    background_gray: int = 255,
    notes: str = "",
    source_manifest: str | Path | None = None,
    source_asset_id: str | None = None,
    job_name: str | None = None,
    metadata_path: str | Path | None = None,
) -> dict[str, Any]:
    if width_mm <= 0 or height_mm <= 0:
        raise ValueError("Target size must be positive.")

    if pitch_mm:
        pitch_x_mm, pitch_y_mm = pitch_mm
        if pitch_x_mm <= 0 or pitch_y_mm <= 0:
            raise ValueError("Pitch must be positive.")
        pixel_width = max(1, int(round(width_mm / pitch_x_mm)))
        pixel_height = max(1, int(round(height_mm / pitch_y_mm)))
        dpi_x = 25.4 / pitch_x_mm
        dpi_y = 25.4 / pitch_y_mm
        pitch_info = {
            "pitch_x_mm": pitch_x_mm,
            "pitch_y_mm": pitch_y_mm,
            "dpi_x": dpi_x,
            "dpi_y": dpi_y,
            "pixel_width": pixel_width,
            "pixel_height": pixel_height,
            "axis_mode": axis_mode,
            "notes": ["Explicit pitch provided."],
        }
    else:
        rec = recommend_pitch(
            width_mm=width_mm,
            height_mm=height_mm,
            process=process,
            nozzle_mm=nozzle_mm,
            layer_height_mm=layer_height_mm,
            resin_xy_mm=resin_xy_mm,
            axis_mode=axis_mode,
        )
        pitch_info = rec.to_dict()
        pitch_x_mm = rec.pitch_x_mm
        pitch_y_mm = rec.pitch_y_mm
        dpi_x = rec.dpi_x
        dpi_y = rec.dpi_y
        pixel_width = rec.pixel_width
        pixel_height = rec.pixel_height

    input_path = Path(input_image)
    arr, source_info = load_grayscale_float(input_path, background=background_gray)
    src_h, src_w = arr.shape

    source_manifest_content: dict | None = None
    if source_manifest:
        source_manifest_content = read_json(source_manifest)
        source_asset_id = source_asset_id or source_manifest_content.get("asset_id")
    source_digest = sha256_file(input_path)
    source_asset_id = source_asset_id or f"sha256:{source_digest[:16]}"

    source_size_mm: tuple[float, float] | None = None
    if source_manifest_content:
        authoring = source_manifest_content.get("requested_authoring") or source_manifest_content.get("physical_authoring")
        if isinstance(authoring, dict) and authoring.get("width_mm") and authoring.get("height_mm"):
            source_size_mm = (float(authoring["width_mm"]), float(authoring["height_mm"]))

    prepared, fit_meta = fit_image_physical(
        arr,
        target_size=(pixel_width, pixel_height),
        target_size_mm=(width_mm, height_mm),
        pitch_mm=(pitch_x_mm, pitch_y_mm),
        fit=fit,
        background_value=float(background_gray) / 255.0,
        tile_size_mm=tile_mm if fit == "repeat" else None,
        source_size_mm=source_size_mm,
    )
    tile_size_px = fit_meta.get("tile_size_px")
    prepared = apply_levels_gamma(
        prepared,
        black_point=black_point,
        white_point=white_point,
        gamma=gamma,
        invert=invert,
    )

    output_path = Path(output_png)
    save_16bit_png(prepared, output_path, dpi_x=dpi_x, dpi_y=dpi_y)
    output_digest = sha256_file(output_path)

    upscale_info = estimate_upscale(
        (src_w, src_h),
        (pixel_width, pixel_height),
        bool(fit_meta.get("aspect_ratio_preserved_physically", True)),
    )
    warnings: list[str] = []
    warnings.extend(pitch_info.get("notes", []))
    warnings.extend(upscale_info.get("warnings", []))
    if fit == "stretch" and image_class.lower() not in {"texture", "pattern", "carbon", "wood", "fabric", "stone"}:
        warnings.append("Stretch mode on a non-texture image may visibly distort the subject.")
    if fit == "repeat" and image_class.lower() not in {"texture", "pattern", "carbon", "wood", "fabric", "stone"}:
        warnings.append("Repeat mode on a non-texture image may be semantically wrong.")
    if fit == "repeat" and tile_mm is None:
        warnings.append("Repeat mode has no explicit tile_mm; the full target area is treated as one tile. Persist a physical tile size for replaceable textures.")
    if source_info.get("source_bit_depth_guess", 8) < 16:
        warnings.append("The source appears to have less than 16-bit native precision; the 16-bit build container preserves processing precision but cannot recover lost source tones.")

    meta: dict[str, Any] = {
        "schema_version": 1,
        "stage": "surface_build_heightmap",
        "job_name": job_name,
        "source": {
            "path": str(input_path),
            "sha256": source_digest,
            "asset_id": source_asset_id,
            "manifest_path": str(Path(source_manifest)) if source_manifest else None,
            "manifest": source_manifest_content,
            **source_info,
        },
        "output": {
            "path": str(output_path),
            "sha256": output_digest,
            "bit_depth": 16,
            "pixel_width": pixel_width,
            "pixel_height": pixel_height,
            "dpi_x": dpi_x,
            "dpi_y": dpi_y,
        },
        "physical": {
            "width_mm": width_mm,
            "height_mm": height_mm,
            "pitch_x_mm": pitch_x_mm,
            "pitch_y_mm": pitch_y_mm,
        },
        "printer": {
            "process": process,
            "nozzle_mm": nozzle_mm,
            "layer_height_mm": layer_height_mm,
            "resin_xy_mm": resin_xy_mm,
            "axis_mode": axis_mode,
        },
        "classification": {
            "image_class": image_class,
            "surface_type": surface_type,
            "placement_mode": placement_mode,
        },
        "processing": {
            "fit_mode": fit,
            "tile_mm": list(tile_mm) if tile_mm else None,
            "tile_size_px": list(tile_size_px) if tile_size_px else None,
            "black_point": black_point,
            "white_point": white_point,
            "gamma": gamma,
            "invert": invert,
            "background_gray": background_gray,
        },
        "fit_meta": fit_meta,
        "scaling": upscale_info,
        "notes": notes,
        "warnings": warnings,
    }
    metadata_output = Path(metadata_path) if metadata_path else sidecar_path(output_path)
    write_json(metadata_output, meta)
    meta["metadata_path"] = str(metadata_output)
    return meta


def parse_args() -> argparse.Namespace:
    p = argparse.ArgumentParser(description="Derive a target-specific 16-bit heightmap with physical scale and DPI/PPI metadata.")
    p.add_argument("input_image")
    p.add_argument("output_png")
    p.add_argument("--size-mm", required=True, type=parse_mm_pair, help="Target physical size in mm, e.g. 120x70")
    p.add_argument("--pitch-mm", type=parse_mm_pair, help="Explicit pitch in mm/pixel, e.g. 0.2x0.12")
    p.add_argument("--process", default="fdm", choices=["fdm", "resin", "sla", "msla", "dlp"])
    p.add_argument("--nozzle-mm", type=float, default=0.4)
    p.add_argument("--layer-height-mm", type=float, default=0.2)
    p.add_argument("--resin-xy-mm", type=float, default=0.05)
    p.add_argument("--axis-mode", default="xy-z", choices=["xy-xy", "xy-z", "z-xy", "mixed"])
    p.add_argument("--fit", default="contain", choices=["contain", "cover", "stretch", "repeat"])
    p.add_argument("--tile-mm", type=parse_mm_pair, help="For repeat mode: physical tile size in mm")
    p.add_argument("--image-class", default="subject")
    p.add_argument("--surface-type", default="plane")
    p.add_argument("--placement-mode", default="single_patch")
    p.add_argument("--black-point", type=float, default=0.0)
    p.add_argument("--white-point", type=float, default=1.0)
    p.add_argument("--gamma", type=float, default=1.0)
    p.add_argument("--invert", action="store_true")
    p.add_argument("--background-gray", type=int, default=255)
    p.add_argument("--source-manifest")
    p.add_argument("--source-asset-id")
    p.add_argument("--job-name")
    p.add_argument("--metadata")
    p.add_argument("--notes", default="")
    return p.parse_args()


def main() -> int:
    args = parse_args()
    width_mm, height_mm = args.size_mm
    meta = prepare_heightmap(
        input_image=args.input_image,
        output_png=args.output_png,
        width_mm=width_mm,
        height_mm=height_mm,
        pitch_mm=args.pitch_mm,
        process=args.process,
        nozzle_mm=args.nozzle_mm,
        layer_height_mm=args.layer_height_mm,
        resin_xy_mm=args.resin_xy_mm,
        axis_mode=args.axis_mode,
        fit=args.fit,
        tile_mm=args.tile_mm,
        image_class=args.image_class,
        surface_type=args.surface_type,
        placement_mode=args.placement_mode,
        black_point=args.black_point,
        white_point=args.white_point,
        gamma=args.gamma,
        invert=args.invert,
        background_gray=args.background_gray,
        notes=args.notes,
        source_manifest=args.source_manifest,
        source_asset_id=args.source_asset_id,
        job_name=args.job_name,
        metadata_path=args.metadata,
    )

    out = meta["output"]
    phys = meta["physical"]
    print(f"Wrote surface build heightmap: {out['path']}")
    print(f"Wrote metadata: {meta['metadata_path']}")
    print(f"Source asset: {meta['source']['asset_id']}")
    print(f"Target: {out['pixel_width']}x{out['pixel_height']} px at {phys['width_mm']}x{phys['height_mm']} mm")
    print(f"Pitch: {phys['pitch_x_mm']:.4f}x{phys['pitch_y_mm']:.4f} mm/px")
    print(f"DPI/PPI: {out['dpi_x']:.2f}x{out['dpi_y']:.2f}")
    for warning in meta["warnings"]:
        print(f"warning: {warning}")
    return 0


if __name__ == "__main__":
    raise SystemExit(main())
