#!/usr/bin/env python3
"""Rebuild a stable surface heightmap from a persistent relief job, optionally swapping the source asset."""
from __future__ import annotations

import argparse
import json
from pathlib import Path
import subprocess
import sys
from typing import Any

from _relief_utils import read_json, sha256_file, write_json
from prepare_heightmap import prepare_heightmap


def resolve_path(job_dir: Path, value: str | None) -> Path | None:
    if not value:
        return None
    p = Path(value)
    return p if p.is_absolute() else (job_dir / p).resolve()


def portable_path(job_dir: Path, path: Path) -> str:
    try:
        return str(path.resolve().relative_to(job_dir.resolve()))
    except ValueError:
        return str(path.resolve())


def substitute_command(parts: list[str], values: dict[str, Any]) -> list[str]:
    class StrictDict(dict):
        def __missing__(self, key: str) -> str:
            raise KeyError(f"unknown geometry command placeholder {{{key}}}")

    strings = StrictDict({k: str(v) for k, v in values.items()})
    return [part.format_map(strings) for part in parts]


def main() -> int:
    p = argparse.ArgumentParser(description="Rebuild a relief job and optionally replace its source master.")
    p.add_argument("job_json")
    p.add_argument("--source", help="Override source master, or raw/generated image when --register-source is used")
    p.add_argument("--register-source", action="store_true", help="Register --source into the job's canonical source master using its saved generation spec before rebuilding")
    p.add_argument("--source-kind", default="supplied", choices=["ai-generated", "supplied", "procedural", "vector-derived"])
    p.add_argument("--pixel-policy", default="preserve", choices=["preserve", "contain", "cover", "stretch"], help="Registration policy used with --register-source")
    p.add_argument("--force-upscale", action="store_true", help="Allow registration upscaling beyond normal limits")
    p.add_argument("--source-manifest", help="Override source manifest")
    p.add_argument("--persist-source", action="store_true", help="Write source override back into the job JSON")
    p.add_argument("--run-geometry", action="store_true", help="Run explicitly configured geometry.command after preprocessing")
    p.add_argument("--dry-run", action="store_true")
    args = p.parse_args()

    job_path = Path(args.job_json).resolve()
    job_dir = job_path.parent
    job = read_json(job_path)

    source_cfg = job.setdefault("source", {})
    canonical_master = resolve_path(job_dir, source_cfg.get("master_path") or source_cfg.get("path"))
    canonical_manifest = resolve_path(job_dir, source_cfg.get("manifest_path"))

    if args.register_source:
        if not args.source:
            raise SystemExit("--register-source requires --source RAW_OR_GENERATED_IMAGE")
        raw_source = resolve_path(job_dir, args.source)
        if not raw_source or not raw_source.is_file():
            raise SystemExit(f"Replacement source image not found: {raw_source}")
        if canonical_master is None:
            raise SystemExit("job.source.master_path is required for --register-source")
        if canonical_manifest is None:
            canonical_manifest = canonical_master.with_suffix(canonical_master.suffix + ".source.json")
        spec_path = resolve_path(job_dir, source_cfg.get("generation_spec_path"))
        if not spec_path or not spec_path.is_file():
            raise SystemExit("--register-source requires an existing job.source.generation_spec_path")
        register_script = Path(__file__).with_name("register_source_master.py")
        register_command = [
            sys.executable,
            str(register_script),
            str(raw_source),
            str(canonical_master),
            "--spec",
            str(spec_path),
            "--source-kind",
            args.source_kind,
            "--pixel-policy",
            args.pixel_policy,
            "--manifest",
            str(canonical_manifest),
        ]
        if args.force_upscale:
            register_command.append("--force-upscale")
        print("Registering replacement source:" if not args.dry_run else "Would register replacement source:")
        print(json.dumps(register_command, indent=2))
        source_path = canonical_master
        source_manifest = canonical_manifest
        if not args.dry_run:
            subprocess.run(register_command, check=True, shell=False)
            registered_manifest = read_json(source_manifest)
            source_cfg["master_path"] = portable_path(job_dir, source_path)
            source_cfg["manifest_path"] = portable_path(job_dir, source_manifest)
            source_cfg["asset_id"] = registered_manifest.get("asset_id")
            write_json(job_path, job)
    else:
        source_path = resolve_path(job_dir, args.source) if args.source else canonical_master
        if not source_path or not source_path.is_file():
            raise SystemExit(f"Source master not found: {source_path}")
        manifest_value = args.source_manifest or source_cfg.get("manifest_path")
        source_manifest = resolve_path(job_dir, manifest_value)
        if source_manifest is None:
            candidate = source_path.with_suffix(source_path.suffix + ".source.json")
            if candidate.is_file():
                source_manifest = candidate

    target = job.get("target", {})
    width_mm = float(target["width_mm"])
    height_mm = float(target["height_mm"])
    pitch_cfg = target.get("pitch_mm")
    pitch_mm = tuple(map(float, pitch_cfg)) if pitch_cfg else None

    printer = job.get("printer", {})
    mapping = job.get("mapping", {})
    processing = job.get("processing", {})
    classification = job.get("classification", {})
    outputs = job.get("outputs", {})
    relief = job.get("relief", {})

    heightmap_path = resolve_path(job_dir, outputs.get("heightmap"))
    if heightmap_path is None:
        raise SystemExit("job.outputs.heightmap is required")
    metadata_path = resolve_path(job_dir, outputs.get("heightmap_metadata"))
    if metadata_path is None:
        metadata_path = heightmap_path.with_suffix(heightmap_path.suffix + ".json")
    build_manifest_path = resolve_path(job_dir, outputs.get("build_manifest"))
    if build_manifest_path is None:
        build_manifest_path = heightmap_path.with_suffix(heightmap_path.suffix + ".build.json")

    tile_cfg = processing.get("tile_mm")
    tile_mm = tuple(map(float, tile_cfg)) if tile_cfg else None

    if args.persist_source and not args.register_source:
        source_cfg["master_path"] = portable_path(job_dir, source_path)
        source_cfg["manifest_path"] = portable_path(job_dir, source_manifest) if source_manifest else None
        if source_manifest and source_manifest.is_file():
            source_cfg["asset_id"] = read_json(source_manifest).get("asset_id")
        else:
            source_cfg["asset_id"] = f"sha256:{sha256_file(source_path)[:16]}"
        if not args.dry_run:
            write_json(job_path, job)

    plan = {
        "job": str(job_path),
        "source": str(source_path),
        "source_manifest": str(source_manifest) if source_manifest else None,
        "heightmap": str(heightmap_path),
        "heightmap_metadata": str(metadata_path),
        "build_manifest": str(build_manifest_path),
        "run_geometry": args.run_geometry,
    }
    print(json.dumps(plan, indent=2))
    if args.dry_run:
        return 0

    meta = prepare_heightmap(
        input_image=source_path,
        output_png=heightmap_path,
        width_mm=width_mm,
        height_mm=height_mm,
        pitch_mm=pitch_mm,
        process=str(printer.get("process", "fdm")),
        nozzle_mm=float(printer.get("nozzle_mm", 0.4)),
        layer_height_mm=float(printer.get("layer_height_mm", 0.2)),
        resin_xy_mm=float(printer.get("resin_xy_mm", 0.05)),
        axis_mode=str(mapping.get("axis_mode", "xy-z")),
        fit=str(processing.get("fit_mode", "contain")),
        tile_mm=tile_mm,
        image_class=str(classification.get("image_class", "subject")),
        surface_type=str(classification.get("surface_type", mapping.get("surface_type", "plane"))),
        placement_mode=str(classification.get("placement_mode", mapping.get("placement_mode", "single_patch"))),
        black_point=float(processing.get("black_point", 0.0)),
        white_point=float(processing.get("white_point", 1.0)),
        gamma=float(processing.get("gamma", 1.0)),
        invert=bool(processing.get("invert", False)),
        background_gray=int(processing.get("background_gray", 255)),
        notes=str(job.get("notes", "")),
        source_manifest=source_manifest,
        source_asset_id=source_cfg.get("asset_id"),
        job_name=str(job.get("job_name", job_path.stem)),
        metadata_path=metadata_path,
    )

    build_manifest = {
        "schema_version": 1,
        "stage": "relief_job_build",
        "job_name": job.get("job_name", job_path.stem),
        "job_path": str(job_path),
        "job_sha256": sha256_file(job_path),
        "source": meta["source"],
        "surface_build": {
            "heightmap": meta["output"],
            "metadata_path": str(metadata_path),
        },
        "target": target,
        "printer": printer,
        "mapping": mapping,
        "processing": processing,
        "classification": classification,
        "relief": relief,
        "geometry": job.get("geometry"),
        "warnings": meta["warnings"],
    }
    write_json(build_manifest_path, build_manifest)
    print(f"Wrote build manifest: {build_manifest_path}")

    if args.run_geometry:
        geometry = job.get("geometry", {})
        command = geometry.get("command")
        if not isinstance(command, list) or not command or not all(isinstance(x, str) for x in command):
            raise SystemExit("--run-geometry requires geometry.command as a non-empty JSON string array; shell strings are intentionally unsupported.")
        output_model = resolve_path(job_dir, geometry.get("output_path")) or (job_dir / "build" / "final-model.stl")
        values = {
            "heightmap": heightmap_path,
            "processed_image": heightmap_path,
            "heightmap_metadata": metadata_path,
            "build_manifest": build_manifest_path,
            "source": source_path,
            "source_image": source_path,
            "source_manifest": source_manifest or "",
            "job": job_path,
            "job_json": job_path,
            "job_dir": job_dir,
            "output_model": output_model,
            "mode": relief.get("mode", "engrave"),
            "depth_mm": relief.get("depth_mm", ""),
        }
        resolved_command = substitute_command(command, values)
        cwd = resolve_path(job_dir, geometry.get("cwd")) or job_dir
        print("Running geometry command:")
        print(json.dumps(resolved_command, indent=2))
        subprocess.run(resolved_command, cwd=cwd, check=True, shell=False)

    return 0


if __name__ == "__main__":
    raise SystemExit(main())
