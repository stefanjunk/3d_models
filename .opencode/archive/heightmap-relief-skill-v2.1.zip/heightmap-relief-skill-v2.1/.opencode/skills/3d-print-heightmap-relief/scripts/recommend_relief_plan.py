#!/usr/bin/env python3
from __future__ import annotations

import argparse
import json
from pathlib import Path

from _relief_utils import minimum_remaining_wall, recommend_pitch, recommended_depth_range


def parse_mm_pair(text: str) -> tuple[float, float]:
    for sep in ("x", ",", ";", " "):
        if sep in text:
            a, b = text.split(sep, 1)
            return float(a), float(b)
    raise argparse.ArgumentTypeError("expected pair like 120x70")


def default_fit_mode(image_class: str, repeating: bool) -> str:
    c = image_class.lower()
    if repeating or c in {"texture", "pattern", "carbon", "wood"}:
        return "repeat"
    if c in {"text", "logo", "motif", "person", "animal", "object", "portrait", "subject"}:
        return "contain"
    return "contain"


def placement_notes(surface_type: str, image_class: str, repeating: bool) -> list[str]:
    s = surface_type.lower()
    c = image_class.lower()
    notes: list[str] = []
    if s in {"cylinder", "cylinder_side"}:
        if repeating or c in {"texture", "pattern", "wood", "carbon"}:
            notes.append("Use cylindrical wrapping with a hidden seam on the back or chosen start angle.")
        else:
            notes.append("Use a bounded front cylindrical patch and preserve aspect ratio.")
    elif s in {"rounded_box", "rounded_rect", "rounded_organizer"}:
        if repeating or c in {"texture", "pattern", "wood", "carbon"}:
            notes.append("Use one continuous perimeter coordinate over front, sides, back, and rounded corners.")
        else:
            notes.append("Place the subject on the main face and stop or fade before tight corners.")
    elif s in {"sphere", "sphere_patch", "ellipsoid", "ellipsoid_patch", "ball"}:
        if repeating or c in {"texture", "pattern", "wood", "carbon"}:
            notes.append("Use a bounded band or controlled full texture; inspect pole distortion.")
        else:
            notes.append("Use a front patch; avoid forcing the subject over the poles.")
    elif s in {"plane", "cube", "cube_face", "flat"}:
        notes.append("Use planar placement; keep margins for subject images and text.")
    else:
        notes.append("For arbitrary surfaces, use UV mapping for single subjects or triplanar/object-space projection for repeating textures.")
    return notes


def main() -> int:
    p = argparse.ArgumentParser(description="Recommend pitch, DPI, fit mode, and depth range for image-based embossing/engraving.")
    p.add_argument("--size-mm", required=True, type=parse_mm_pair, help="Placed image size in mm, e.g. 120x70")
    p.add_argument("--process", default="fdm", choices=["fdm", "resin", "sla", "msla", "dlp"])
    p.add_argument("--nozzle-mm", type=float, default=0.4)
    p.add_argument("--layer-height-mm", type=float, default=0.2)
    p.add_argument("--resin-xy-mm", type=float, default=0.05)
    p.add_argument("--axis-mode", default="xy-z", choices=["xy-xy", "xy-z", "z-xy", "mixed"])
    p.add_argument("--surface-type", default="plane")
    p.add_argument("--image-class", default="subject")
    p.add_argument("--mode", default="engrave", choices=["engrave", "emboss"])
    p.add_argument("--repeating", action="store_true")
    p.add_argument("--wall-thickness-mm", type=float, default=2.0)
    p.add_argument("--output-json", help="Optional JSON output path")
    args = p.parse_args()

    width_mm, height_mm = args.size_mm
    rec = recommend_pitch(
        width_mm=width_mm,
        height_mm=height_mm,
        process=args.process,
        nozzle_mm=args.nozzle_mm,
        layer_height_mm=args.layer_height_mm,
        resin_xy_mm=args.resin_xy_mm,
        axis_mode=args.axis_mode,
    )
    depth_range, depth_note = recommended_depth_range(args.image_class, args.mode)
    reserve = minimum_remaining_wall(args.nozzle_mm)
    max_safe_engrave = max(0.0, args.wall_thickness_mm - reserve)
    fit = default_fit_mode(args.image_class, args.repeating)

    warnings: list[str] = []
    if args.mode == "engrave" and max_safe_engrave <= 0:
        warnings.append("Current wall thickness is below the conservative remaining-wall reserve; embossing or a thicker wall is strongly recommended.")
    elif args.mode == "engrave" and depth_range[1] > max_safe_engrave:
        warnings.append(
            f"Recommended engraving range extends beyond the conservative safe depth budget ({max_safe_engrave:.2f} mm). Consider embossing or thickening the wall."
        )
    if fit == "repeat" and args.image_class.lower() not in {"texture", "pattern", "wood", "carbon"}:
        warnings.append("Repeat fit was suggested only because --repeating was set; confirm that repetition is actually desired.")

    result = {
        "image_class": args.image_class,
        "surface_type": args.surface_type,
        "mode": args.mode,
        "repeating": args.repeating,
        "size_mm": {"width_mm": width_mm, "height_mm": height_mm},
        "pitch_and_resolution": rec.to_dict(),
        "recommended_fit_mode": fit,
        "recommended_master_bit_depth": 16,
        "recommended_depth_range_mm": {"min": depth_range[0], "max": depth_range[1], "note": depth_note},
        "wall_safety": {
            "wall_thickness_mm": args.wall_thickness_mm,
            "minimum_remaining_wall_mm": reserve,
            "max_safe_engrave_depth_mm": max_safe_engrave,
        },
        "placement_notes": placement_notes(args.surface_type, args.image_class, args.repeating),
        "warnings": warnings,
    }

    text = json.dumps(result, indent=2, sort_keys=True)
    if args.output_json:
        Path(args.output_json).write_text(text, encoding="utf-8")
    print(text)
    return 0


if __name__ == "__main__":
    raise SystemExit(main())
