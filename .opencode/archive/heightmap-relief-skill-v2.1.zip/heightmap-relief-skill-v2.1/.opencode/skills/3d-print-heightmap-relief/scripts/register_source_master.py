#!/usr/bin/env python3
"""Register an AI-generated or supplied image as a reusable 16-bit relief source master."""
from __future__ import annotations

import argparse
from pathlib import Path

from _relief_utils import (
    effective_ppi,
    estimate_upscale,
    fit_image,
    load_grayscale_float,
    pixels_for_physical_size,
    read_json,
    save_16bit_png,
    seam_metrics,
    sha256_file,
    write_json,
)


def parse_pair(text: str) -> tuple[float, float]:
    for sep in ("x", ",", ";", " "):
        if sep in text:
            a, b = text.split(sep, 1)
            return float(a), float(b)
    raise argparse.ArgumentTypeError("expected pair like 50x50")


def default_manifest_path(output: Path) -> Path:
    return output.with_suffix(output.suffix + ".source.json")


def main() -> int:
    p = argparse.ArgumentParser(description="Create a reusable 16-bit source master and source manifest.")
    p.add_argument("input_image")
    p.add_argument("output_master")
    p.add_argument("--spec", help="Generation spec from plan_ai_source.py")
    p.add_argument("--physical-size-mm", type=parse_pair, help="Required when --spec is omitted")
    p.add_argument("--authoring-ppi", type=float, help="Required when --spec is omitted")
    p.add_argument("--image-class", default="subject")
    p.add_argument("--source-kind", default="supplied", choices=["ai-generated", "supplied", "procedural", "vector-derived"])
    p.add_argument("--polarity", default="white-high", choices=["white-high", "white-low"])
    p.add_argument("--seamless-x", action="store_true")
    p.add_argument("--seamless-y", action="store_true")
    p.add_argument("--pixel-policy", default="preserve", choices=["preserve", "contain", "cover", "stretch"], help="How to match the requested raster")
    p.add_argument("--background-gray", type=int, default=255)
    p.add_argument("--force-upscale", action="store_true")
    p.add_argument("--manifest", help="Output manifest path")
    args = p.parse_args()

    spec: dict | None = read_json(args.spec) if args.spec else None
    if spec:
        phys = spec["physical_authoring"]
        requested = spec["requested_raster"]
        width_mm = float(phys["width_mm"])
        height_mm = float(phys["height_mm"])
        authoring_ppi = float(phys["authoring_ppi"])
        expected_w = int(requested["pixel_width"])
        expected_h = int(requested["pixel_height"])
        image_class = str(spec.get("image_class", args.image_class))
        semantic = spec.get("semantic", {})
        polarity = str(semantic.get("polarity", args.polarity))
        seamless_x = bool(semantic.get("seamless_x", args.seamless_x))
        seamless_y = bool(semantic.get("seamless_y", args.seamless_y))
    else:
        if not args.physical_size_mm or not args.authoring_ppi:
            raise SystemExit("Provide --spec or both --physical-size-mm and --authoring-ppi.")
        width_mm, height_mm = args.physical_size_mm
        authoring_ppi = args.authoring_ppi
        expected_w, expected_h = pixels_for_physical_size(width_mm, height_mm, authoring_ppi)
        image_class = args.image_class
        polarity = args.polarity
        seamless_x = args.seamless_x
        seamless_y = args.seamless_y

    arr, source_info = load_grayscale_float(args.input_image, background=args.background_gray)
    src_h, src_w = arr.shape
    warnings: list[str] = []

    if args.pixel_policy == "preserve":
        registered = arr
        fit_meta = {"pixel_policy": "preserve", "aspect_ratio_preserved": True}
    else:
        is_texture = image_class.lower() in {"texture", "pattern", "wood", "carbon", "fabric", "stone"}
        scaling = estimate_upscale((src_w, src_h), (expected_w, expected_h), args.pixel_policy != "stretch")
        max_scale = max(float(scaling["scale_x"]), float(scaling["scale_y"]))
        limit = 2.0 if is_texture else 1.5
        if max_scale > limit and not args.force_upscale:
            raise SystemExit(
                f"Refusing {max_scale:.2f}x upscaling for {image_class}; limit is {limit:.2f}x. "
                "Regenerate a better source, use --pixel-policy preserve, or pass --force-upscale explicitly."
            )
        registered, fit_meta = fit_image(
            arr,
            target_size=(expected_w, expected_h),
            fit=args.pixel_policy,
            background_value=float(args.background_gray) / 255.0,
        )
        warnings.extend(scaling.get("warnings", []))

    out_h, out_w = registered.shape
    eff_x, eff_y = effective_ppi(out_w, out_h, width_mm, height_mm)
    aspect_error = abs((out_w / out_h) / (width_mm / height_mm) - 1.0)
    if aspect_error > 0.01:
        warnings.append(
            f"Actual pixel aspect versus physical authoring aspect differs by {aspect_error * 100:.2f}%; effective PPI is anisotropic."
        )

    source_precision = int(source_info.get("source_bit_depth_guess", 8))
    if source_precision < 16:
        warnings.append(
            "The registered master uses a 16-bit PNG container, but the input appears to have 8-bit source precision; conversion does not invent missing tonal information."
        )

    seams = seam_metrics(registered)
    if seamless_x and seams["x_mean_abs"] > 0.02:
        warnings.append(f"Requested seamless X, but mean left/right mismatch is {seams['x_mean_abs']:.4f}.")
    if seamless_y and seams["y_mean_abs"] > 0.02:
        warnings.append(f"Requested seamless Y, but mean top/bottom mismatch is {seams['y_mean_abs']:.4f}.")

    output = Path(args.output_master)
    save_16bit_png(registered, output, dpi_x=eff_x, dpi_y=eff_y)
    digest = sha256_file(output)
    asset_id = f"sha256:{digest[:16]}"

    manifest_path = Path(args.manifest) if args.manifest else default_manifest_path(output)
    manifest = {
        "schema_version": 1,
        "stage": "registered_source_master",
        "asset_id": asset_id,
        "sha256": digest,
        "source_kind": args.source_kind,
        "input": {
            "path": str(Path(args.input_image)),
            **source_info,
        },
        "generation_spec": {
            "path": str(Path(args.spec)) if args.spec else None,
            "content": spec,
        },
        "semantic": {
            "image_class": image_class,
            "polarity": polarity,
            "seamless_x": seamless_x,
            "seamless_y": seamless_y,
        },
        "requested_authoring": {
            "width_mm": width_mm,
            "height_mm": height_mm,
            "authoring_ppi": authoring_ppi,
            "pixel_width": expected_w,
            "pixel_height": expected_h,
            "square_pixels": True,
        },
        "registered_master": {
            "path": str(output),
            "container_bit_depth": 16,
            "source_precision_bit_depth_guess": source_precision,
            "pixel_width": out_w,
            "pixel_height": out_h,
            "effective_ppi_x": eff_x,
            "effective_ppi_y": eff_y,
            "pixel_policy": args.pixel_policy,
            "fit_meta": fit_meta,
        },
        "seam_metrics_normalized": seams,
        "warnings": warnings,
    }
    write_json(manifest_path, manifest)

    print(f"Wrote source master: {output}")
    print(f"Wrote source manifest: {manifest_path}")
    print(f"Asset ID: {asset_id}")
    print(f"Requested: {expected_w}x{expected_h} px at {authoring_ppi:.2f} PPI")
    print(f"Registered: {out_w}x{out_h} px at effective {eff_x:.2f}x{eff_y:.2f} PPI")
    for warning in warnings:
        print(f"warning: {warning}")
    return 0


if __name__ == "__main__":
    raise SystemExit(main())
