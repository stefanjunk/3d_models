#!/usr/bin/env python3
from __future__ import annotations

import hashlib
import json
from pathlib import Path
import subprocess
import sys
import tempfile

import numpy as np
from PIL import Image


ROOT = Path(__file__).resolve().parents[1]
SCRIPTS = ROOT / "scripts"


def run(*args: str) -> None:
    subprocess.run([sys.executable, *args], check=True)


def digest(path: Path) -> str:
    return hashlib.sha256(path.read_bytes()).hexdigest()


def make_image(path: Path, variant: int) -> None:
    w = h = 192
    y, x = np.mgrid[0:h, 0:w]
    if variant == 1:
        arr = 0.5 + 0.5 * np.sin(2 * np.pi * x / 32.0) * np.cos(2 * np.pi * y / 24.0)
    else:
        radius = np.sqrt((x - w / 2) ** 2 + (y - h / 2) ** 2)
        arr = np.clip(radius / (w * 0.65), 0.0, 1.0)
    Image.fromarray(np.round(arr * 255).astype(np.uint8)).save(path)


def main() -> int:
    with tempfile.TemporaryDirectory(prefix="relief-skill-test-") as tmp:
        temp = Path(tmp)
        image1 = temp / "generated-1.png"
        image2 = temp / "generated-2.png"
        make_image(image1, 1)
        make_image(image2, 2)

        spec = temp / "standalone-spec.json"
        prompt = temp / "standalone-prompt.txt"
        run(
            str(SCRIPTS / "plan_ai_source.py"),
            "--description", "continuous grayscale test texture",
            "--physical-size-mm", "20x20",
            "--authoring-ppi", "450",
            "--image-class", "texture",
            "--seamless-x",
            "--seamless-y",
            "--output-spec", str(spec),
            "--output-prompt", str(prompt),
        )
        spec_data = json.loads(spec.read_text(encoding="utf-8"))
        assert spec_data["requested_raster"]["pixel_width"] == 354
        assert spec_data["requested_raster"]["pixel_height"] == 354
        assert "Do not threshold" in prompt.read_text(encoding="utf-8")

        job_dir = temp / "job"
        run(
            str(SCRIPTS / "init_relief_job.py"),
            str(job_dir),
            "--name", "swap-test",
            "--target-size-mm", "80x30",
            "--source-size-mm", "20x20",
            "--authoring-ppi", "450",
            "--description", "continuous grayscale test texture",
            "--image-class", "texture",
            "--surface-type", "rounded_box",
            "--placement-mode", "continuous_perimeter_wrap",
            "--repeating",
            "--seamless-x",
            "--seamless-y",
            "--mode", "engrave",
            "--process", "fdm",
            "--nozzle-mm", "0.4",
            "--layer-height-mm", "0.2",
            "--axis-mode", "xy-z",
            "--fit", "repeat",
            "--tile-mm", "20x20",
            "--depth-mm", "0.25",
        )

        job_path = job_dir / "relief-job.json"
        job = json.loads(job_path.read_text(encoding="utf-8"))
        # Exercise explicit geometry-command rebuilding without a shell.
        job["geometry"]["command"] = [
            sys.executable,
            "-c",
            "from pathlib import Path; import sys; Path(sys.argv[2]).write_text(Path(sys.argv[1]).name, encoding='utf-8')",
            "{heightmap}",
            "build/geometry-marker.txt",
        ]
        job_path.write_text(json.dumps(job, indent=2), encoding="utf-8")

        run(
            str(SCRIPTS / "rebuild_relief_job.py"),
            str(job_path),
            "--source", str(image1),
            "--register-source",
            "--source-kind", "ai-generated",
            "--run-geometry",
        )

        build_path = job_dir / "build" / "current-heightmap.png"
        build_meta_path = job_dir / "build" / "current-heightmap.png.json"
        source_manifest_path = job_dir / "source" / "source-master.png.source.json"
        marker_path = job_dir / "build" / "geometry-marker.txt"
        first_hash = digest(build_path)
        first_output_path = build_path.resolve()

        with Image.open(build_path) as im:
            assert im.mode in {"I;16", "I"}
            assert im.size == (400, 150)
            assert im.info.get("dpi") is not None
            assert len(np.unique(np.asarray(im))) > 32

        source_manifest = json.loads(source_manifest_path.read_text(encoding="utf-8"))
        build_meta = json.loads(build_meta_path.read_text(encoding="utf-8"))
        assert build_meta["fit_meta"]["physical_coordinate_fit"] is True
        assert source_manifest["asset_id"] == build_meta["source"]["asset_id"]
        assert source_manifest["requested_authoring"]["authoring_ppi"] == 450
        assert source_manifest["registered_master"]["container_bit_depth"] == 16
        assert marker_path.read_text(encoding="utf-8") == "current-heightmap.png"

        # A dry-run must not register, overwrite, or update the active source/job.
        source_master_path = job_dir / "source" / "source-master.png"
        source_before_dry_run = digest(source_master_path)
        job_before_dry_run = digest(job_path)
        run(
            str(SCRIPTS / "rebuild_relief_job.py"),
            str(job_path),
            "--source", str(image2),
            "--register-source",
            "--source-kind", "ai-generated",
            "--dry-run",
        )
        assert digest(source_master_path) == source_before_dry_run
        assert digest(job_path) == job_before_dry_run

        run(
            str(SCRIPTS / "rebuild_relief_job.py"),
            str(job_path),
            "--source", str(image2),
            "--register-source",
            "--source-kind", "ai-generated",
            "--run-geometry",
        )
        second_hash = digest(build_path)
        assert build_path.resolve() == first_output_path
        assert second_hash != first_hash

        second_source_manifest = json.loads(source_manifest_path.read_text(encoding="utf-8"))
        second_build_meta = json.loads(build_meta_path.read_text(encoding="utf-8"))
        assert second_source_manifest["asset_id"] == second_build_meta["source"]["asset_id"]
        assert second_source_manifest["asset_id"] != source_manifest["asset_id"]

        # Verify physical-aspect preservation with anisotropic target sampling:
        # 80x40 mm source/placement, 0.20 mm X pitch and 0.12 mm Y pitch.
        subject = temp / "subject-16bit.png"
        sw, sh = 800, 400
        sy, sx = np.mgrid[0:sh, 0:sw]
        field = np.clip(0.05 + 0.9 * (1.0 - ((sx - sw / 2) / (sw * 0.45)) ** 2 - ((sy - sh / 2) / (sh * 0.45)) ** 2), 0.0, 1.0)
        Image.fromarray(np.round(field * 65535).astype(np.uint16)).save(subject)
        subject_manifest = temp / "subject.source.json"
        subject_manifest.write_text(json.dumps({
            "asset_id": "test-subject",
            "requested_authoring": {"width_mm": 80.0, "height_mm": 40.0, "authoring_ppi": 254.0}
        }), encoding="utf-8")
        subject_build = temp / "subject-build.png"
        run(
            str(SCRIPTS / "prepare_heightmap.py"),
            str(subject),
            str(subject_build),
            "--size-mm", "80x40",
            "--process", "fdm",
            "--nozzle-mm", "0.4",
            "--layer-height-mm", "0.12",
            "--axis-mode", "xy-z",
            "--fit", "contain",
            "--image-class", "animal",
            "--surface-type", "cylinder",
            "--placement-mode", "front_patch",
            "--source-manifest", str(subject_manifest),
        )
        subject_meta = json.loads(subject_build.with_suffix(subject_build.suffix + ".json").read_text(encoding="utf-8"))
        with Image.open(subject_build) as im:
            assert im.size == (400, 333)
            assert im.mode in {"I;16", "I"}
            assert len(np.unique(np.asarray(im))) > 1000
        assert subject_meta["fit_meta"]["source_aspect_basis"] == "source_manifest_physical_size"
        assert subject_meta["fit_meta"]["placed_size_mm"] == [80.0, 40.0]

    print("All source-generation, registration, swap, physical-coordinate fitting, continuous-tone 16-bit, DPI/PPI, and geometry-command tests passed.")
    return 0


if __name__ == "__main__":
    raise SystemExit(main())
