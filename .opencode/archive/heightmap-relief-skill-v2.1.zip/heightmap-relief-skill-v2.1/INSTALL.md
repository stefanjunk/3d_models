# Install

Copy the `.opencode` directory into the root of an OpenCode project, or copy the
skill directory into the configured OpenCode skills directory.

```text
<project>/
  .opencode/
    skills/
      3d-print-heightmap-relief/
        SKILL.md
        references/
        scripts/
        examples/
        tests/
```

Install the helper-script dependencies:

```bash
python -m pip install -r \
  .opencode/skills/3d-print-heightmap-relief/requirements.txt
```

Run the self-test:

```bash
python .opencode/skills/3d-print-heightmap-relief/tests/self_test.py
```
