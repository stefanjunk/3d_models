# 3D Print Heightmap Relief Skill v2.1

An OpenCode/Agent-Skills package for high-fidelity image-based embossing and
engraving on flat and curved 3D-printable objects.

## Clarified DPI/PPI meaning

The package now distinguishes two persisted image stages.

### 1. Reusable source master

When an agent asks an AI image model to generate a new texture, object, person,
animal, logo, or writing image, it first defines:

- intended physical authoring width and height in millimetres;
- one square-pixel authoring PPI value;
- corresponding requested native pixel width and height;
- grayscale polarity, seamless/repeating intent, and exact generation prompt.

The prompt contains all of those values. Because image generators may ignore DPI
metadata, support only selected raster sizes, or return 8-bit RGB, the result is
then inspected and registered. The source manifest records requested versus
actual/effective PPI, actual pixels, detected source precision, prompt/spec,
seam checks, and a SHA-256 asset ID.

### 2. Surface build heightmap

The reusable source is transformed into a separate target-specific 16-bit
heightmap using the mapped surface dimensions, printer/nozzle/layer setup, fit
mode, repeat period, gamma, invert, and other placement settings. Target
`dpi_x` and `dpi_y` may differ when one image axis maps to printed XY and the
other maps to model Z.

This separation prevents one printer or surface mapping from overwriting the
original image asset.

## Replace an image and rebuild

Initialize a reproducible job:

```bash
python .opencode/skills/3d-print-heightmap-relief/scripts/init_relief_job.py \
  jobs/my-relief \
  --name my-relief \
  --description "seamless carbon weave height texture" \
  --target-size-mm 220x45 \
  --source-size-mm 20x20 \
  --authoring-ppi 450 \
  --image-class texture \
  --surface-type rounded_box \
  --placement-mode continuous_perimeter_wrap \
  --repeating --seamless-x --seamless-y \
  --fit repeat --tile-mm 20x20
```

Generate an image from the saved prompt. Then register it and rebuild the stable
heightmap in one command:

```bash
python .opencode/skills/3d-print-heightmap-relief/scripts/rebuild_relief_job.py \
  jobs/my-relief/relief-job.json \
  --source generated.png \
  --register-source \
  --source-kind ai-generated
```

Later, exchange the artwork with the same command:

```bash
python .opencode/skills/3d-print-heightmap-relief/scripts/rebuild_relief_job.py \
  jobs/my-relief/relief-job.json \
  --source replacement.png \
  --register-source \
  --source-kind ai-generated \
  --run-geometry
```

`--run-geometry` executes the explicit JSON-array command configured in the job.
This lets the same command regenerate the source master, target heightmap, and
final OpenSCAD/CadQuery/FreeCAD/Blender model without manually editing image
paths in CAD code.

## Quality rules

- 16-bit grayscale source/build containers by default.
- No automatic thresholding, posterization, or low-level height quantization.
- Physical emboss/engrave depth is independent from tonal precision.
- Seamless textures are cropped/repeated instead of over-stretched.
- People, animals, objects, logos, and writing are normally bounded,
  non-repeating placements.
- Physical-coordinate fitting preserves subject proportions even when final
  `dpi_x` and `dpi_y` differ.
- A generator's claimed DPI is never trusted until actual pixels are inspected.

## Key files

- `.opencode/skills/3d-print-heightmap-relief/SKILL.md`
- `references/ai-generated-source-masters.md`
- `references/rebuildable-jobs.md`
- `scripts/init_relief_job.py`
- `scripts/register_source_master.py`
- `scripts/rebuild_relief_job.py`
- `tests/self_test.py`
