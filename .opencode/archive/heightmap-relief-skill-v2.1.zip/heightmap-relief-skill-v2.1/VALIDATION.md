# Validation

The v2.1 package was tested end-to-end with Python, Pillow, and NumPy.

## Automated self-test coverage

Run:

```bash
python .opencode/skills/3d-print-heightmap-relief/tests/self_test.py
```

The packaged test verifies:

- generation planning stores physical authoring size, square-pixel authoring
  PPI, requested pixels, polarity, seamless intent, and the exact prompt;
- a 20 × 20 mm source at 450 PPI requests 354 × 354 pixels;
- generated/supplied images are registered into a 16-bit PNG source-master
  container;
- source manifests distinguish requested PPI from actual/effective PPI and
  retain the source asset hash;
- an 8-bit input triggers an explicit warning that conversion to a 16-bit
  container does not recover missing native tonal information;
- a raw replacement image can be registered, processed, and passed into a
  geometry command in one `rebuild_relief_job.py` invocation;
- dry-run mode does not overwrite the canonical source or job;
- source replacement changes the source asset ID and regenerated heightmap hash
  while preserving the stable build path;
- a repeating 80 × 30 mm FDM target produces a 400 × 150 pixel, 16-bit build
  heightmap at approximately 127 × 127 PPI;
- continuous-tone output is not collapsed to two or three levels;
- a non-repeating 80 × 40 mm subject mapped with 0.20 mm X pitch and 0.12 mm Y
  pitch produces a 400 × 333 pixel build at approximately 127 × 211.67 PPI;
- the subject's 2:1 physical proportions remain 80 × 40 mm even though the
  target raster has non-square physical pixel pitch;
- the anisotropic subject build retains more than 1,000 distinct 16-bit sample
  values in the synthetic regression fixture;
- explicit JSON-array geometry commands execute without a shell and receive the
  canonical processed-heightmap path.

## Additional manual smoke tests

Separate texture and subject runs confirmed:

- a 20 × 20 mm source tile at 300 PPI was persisted independently from a
  220 × 45 mm mapped surface;
- the tile was resampled to a physical 100 × 100 pixel repeat at 0.20 mm pitch
  and repeated 11 × 3 times over the target raster;
- replacing the source changed the build manifest source hash and regenerated
  the geometry-adapter output.
