# Changelog

## 2.2.0

- Added physical-aspect invariant throughout generation, registration, preprocessing, and rebuild.
- `contain`, `cover`, and crop now fit in millimetres before rasterization.
- `stretch` is rejected by default under `aspect_policy=preserve`.
- Added explicit source/target/raster/physical-pixel aspect metadata and error tolerance.
- Added square-pixel human preview for anisotropic geometry rasters.
- Added metric mapping guidance for cylinders, rounded boxes, spheres, ellipsoids, and arbitrary UV meshes.
- Added no-accumulated-resizing rule.
- Added `validate_aspect_ratio.py` and `make_aspect_test_image.py`.
- Added regression tests proving a circle remains physically circular with 0.20×0.10 mm target sampling.

## 2.1.0

- Added generation-time source PPI, source registration, persistent rebuild job, and easy source replacement.

## 2.0.0

- Added 16-bit default and no-posterization guidance.
