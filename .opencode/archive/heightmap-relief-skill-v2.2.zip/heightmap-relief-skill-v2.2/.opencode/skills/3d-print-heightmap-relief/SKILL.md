---
name: 3d-print-heightmap-relief
description: Plan, generate, preprocess, scale, place, rebuild, and validate continuous-tone image relief for 3D-printable engraving and embossing. Preserve 16-bit grayscale masters, generation-time PPI, physical aspect ratio, and surface scale across flat and curved geometry in OpenSCAD, CadQuery, FreeCAD, Blender, and hybrid workflows.
license: MIT
compatibility: OpenCode and other Agent-Skills-compatible runtimes
metadata:
  version: "2.2.0"
  domain: "3d-printing"
  units: "mm"
  master_format: "16-bit grayscale PNG"
  aspect_model: "physical-coordinate invariant"
---

# 3D print heightmap relief

Use this skill whenever an image, texture, logo, writing, portrait, person, animal, object, photograph, or authored depth map must become engraving or embossing on a 3D-printable object.

## Read only what the task needs

- Physical aspect ratio and non-square target sampling: `references/aspect-ratio-and-physical-coordinates.md`
- Source generation and source-master PPI: `references/ai-generated-source-masters.md`
- DPI/PPI, nozzle/layer sampling, and resizing: `references/dpi-and-pixel-resolution.md`
- Continuous grayscale and 16-bit height resolution: `references/bit-depth-and-height-resolution.md`
- Texture versus single-subject placement: `references/image-types-and-placement.md`
- Plane/cube/cylinder/rounded box/sphere/ellipsoid/freeform mapping: `references/surface-mapping.md`
- Replaceable source images and one-command rebuilding: `references/rebuildable-jobs.md`
- Persistent job fields: `references/relief-job-format.md`
- Relief depth, visibility, and wall safety: `references/depth-visibility-and-structure.md`
- OpenSCAD/CadQuery/FreeCAD/Blender guidance: `references/tool-guidance.md`
- Agent checklist: `references/agent-checklist.md`
- Examples: `references/examples.md`

## Hard rules

1. **Preserve PHYSICAL aspect ratio by default.** For a recognizable image, the invariant is `placed_width_mm / placed_height_mm`, not raw PNG `pixel_width / pixel_height`.
2. **Never independently scale X and Y for a subject unless the user explicitly authorizes distortion.** `stretch` must fail under `aspect_policy=preserve`.
3. **Non-square build sampling is allowed and often correct.** A 0.20 mm X pitch and 0.12 mm Y pitch intentionally create a raster whose raw pixel aspect differs from the physical image aspect.
4. **Never "correct" a geometry heightmap merely because it looks stretched in a normal image viewer.** Generate a separate square-pixel preview for human inspection. Never use that preview as geometry input.
5. **Fit in millimetre space first, rasterize second.** `contain`, `cover`, and crop compute one uniform physical scale before converting X/Y distances to pixels.
6. **Use actual surface distance for curved mappings.** Cylinder horizontal distance is arc length `s = R*theta`; rounded-box horizontal distance is perimeter arc length; arbitrary UVs require distortion review.
7. **Do not reduce continuous relief to two or a few grayscale levels unless explicitly requested.** Processed source/build masters remain 16-bit grayscale by default.
8. **For AI-generated sources, request a physical authoring size, isotropic authoring PPI, and matching native pixel dimensions.** Persist requested and actual values.
9. **Keep the source master immutable and rebuild target images directly from it.** Never cascade resize from an old processed heightmap.
10. **Keep images replaceable.** Persist placement, printer, fit, aspect policy, and geometry command in a job JSON; rebuild a replacement with one command.
11. **Validate before geometry generation.** For non-texture subjects, default physical aspect tolerance is about 0.75%; stop if exceeded rather than generating a large wrong mesh.
12. **Protect wall thickness.** If adequate visual depth is unsafe as engraving, emboss or thicken the wall instead of sacrificing structure.

## Required coordinate model

Always distinguish:

```text
SOURCE SPACE
  source master, usually square pixels
          ↓ uniform physical placement
SURFACE SPACE
  millimetres on the intended surface patch  ← aspect invariant lives here
          ↓ independent fabrication sampling per surface axis
RASTER SPACE
  target heightmap pixels; pixel aspect may be non-square physically
          ↓ metric-aware mapping
3D SURFACE
  actual printed geometry; must recover SURFACE SPACE dimensions
```

A 2:1 physical image can legitimately have a 400×333 build raster if X and Y use different mm/pixel. The physical result is correct when `400*pitch_x / (333*pitch_y) ≈ 2`.

## Mandatory workflow

### 1. Classify image and surface

Image: repeating texture, logo/motif, text, person/animal/object, photograph, authored height/depth map.

Surface: plane/cube face, cylinder, rounded perimeter, cone/frustum, sphere/ellipsoid patch, multiple faces, arbitrary UV/freeform mesh.

Decide whether the image repeats or is placed once.

### 2. Establish the source physical aspect

For AI generation, define physical authoring width/height and isotropic PPI before generation. For a supplied square-pixel image with no physical metadata, its pixel width/height defines the natural source aspect.

If a generator returns the wrong raster aspect, do not stretch it into compliance. Register it with `contain` or controlled `cover/crop`, then warn.

### 3. Select the final surface patch in millimetres

For a single subject, choose a bounded patch where the subject remains readable. For a texture, define either its physical tile size or global mapping scale.

### 4. Select target print pitch

FDM starting points:
- surface axis printed mainly in XY: about `0.5 * nozzle_mm` per sample;
- surface axis running mainly in model Z on a side wall: about `layer_height_mm` per sample.

Resin: use actual XY printer pixel size and layer height as starting references.

### 5. Prepare target heightmap in physical coordinates

Use:

```bash
python scripts/prepare_heightmap.py source/source-master.png build/current-heightmap.png \
  --source-manifest source/source-master.png.source.json \
  --size-mm 80x40 \
  --pitch-mm 0.20x0.12 \
  --fit contain \
  --aspect-policy preserve \
  --image-class person \
  --preview build/current-heightmap.preview.png
```

The geometry file may look squashed in a square-pixel viewer. The preview must look correct.

### 6. Validate physical aspect before mesh/CAD work

```bash
python scripts/validate_aspect_ratio.py build/current-heightmap.png.json
```

Do not proceed after a failed validation unless the user deliberately approved distortion.

### 7. Map using surface distance

Read `references/surface-mapping.md`. On a cylinder, map image X to physical arc length. On a rounded box, map X to accumulated perimeter length. On spheres/ellipsoids, keep recognizable subjects on bounded low-distortion patches. On arbitrary meshes, inspect UV metric distortion or use a local surface patch.

### 8. Choose depth independently of grayscale precision

Increase visual strength through physical depth, image size, contrast/gamma shaping, or embossing—not posterization.

### 9. Rebuild only from the source master

```bash
python scripts/rebuild_relief_job.py jobs/my-job/relief-job.json \
  --source replacement.png --register-source --run-geometry
```

The command must regenerate the build heightmap from the canonical source master, validate aspect, then run the configured geometry command.

### 10. If mapping is suspect, use the diagnostic image

```bash
python scripts/make_aspect_test_image.py aspect-test.png \
  --size-mm 80x40 --ppi 200 --marker-mm 20
```

Map this through the exact production pipeline. A 20 mm circle must remain physically circular and a 20×20 mm square must remain square in the final CAD/mesh. Remove diagnostic artwork for production.

## Helper scripts

- `plan_ai_source.py` — generation-time physical size/PPI/pixel brief.
- `register_source_master.py` — registers raw/generated art without silent anisotropic stretching.
- `prepare_heightmap.py` — physical-coordinate fit, 16-bit geometry map, aspect validation, square-pixel preview.
- `validate_aspect_ratio.py` — early failure gate before expensive geometry.
- `make_aspect_test_image.py` — known-size circle/square diagnostic.
- `surface_patch_metrics.py` — cylinder arc-length, rounded-perimeter, sphere, and ellipsoid local metric calculations.
- `init_relief_job.py` — initializes a source-swappable job.
- `rebuild_relief_job.py` — source replacement → master → target map → validation → optional geometry command.
- `recommend_relief_plan.py` — print-pitch, fit, aspect, wall/depth starting plan.

## Deliverable contract

Always report:
- source image class and provenance;
- source physical size/aspect and authoring PPI;
- target surface patch in mm;
- target X/Y pitch and PPI;
- geometry raster pixel size and raw raster aspect;
- physical pixel aspect;
- fit and aspect policy;
- reconstructed physical aspect and percentage error;
- 16-bit/continuous-tone status;
- preview path when target X/Y pitches differ;
- mapping model and seam/patch location;
- depth and remaining-wall assumptions;
- replacement/rebuild command;
- warnings about crop, upscaling, UV distortion, poles, corners, or intentional aspect distortion.
