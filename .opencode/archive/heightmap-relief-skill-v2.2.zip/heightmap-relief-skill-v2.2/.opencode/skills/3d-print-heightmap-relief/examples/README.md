# Examples

`person-cylinder-job.json` demonstrates the critical anisotropic sampling case:

- physical patch: 80×40 mm;
- X pitch: 0.20 mm/px;
- Y pitch: 0.12 mm/px;
- `aspect_policy: preserve`;
- `fit_mode: contain`;
- square-pixel human preview enabled by the rebuild job.

The geometry raster's raw pixel aspect is not expected to equal the physical image aspect.
