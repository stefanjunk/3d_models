# Agent checklist

Before processing:
- [ ] classify image and surface;
- [ ] record source physical or square-pixel natural aspect;
- [ ] record target patch in millimetres;
- [ ] choose repeat vs single placement;
- [ ] set `aspect_policy=preserve` unless distortion is explicitly approved.

During processing:
- [ ] create/register a 16-bit source master;
- [ ] compute fit in millimetres, not raster pixels;
- [ ] calculate target X/Y pitch and PPI;
- [ ] generate target raster from the source master in one resampling pass;
- [ ] create a square-pixel preview when X/Y pitch differs;
- [ ] validate reconstructed physical aspect before geometry.

Surface mapping:
- [ ] plane uses mm X/Y;
- [ ] cylinder uses `R*theta` arc length;
- [ ] rounded box uses accumulated perimeter arc length;
- [ ] sphere/ellipsoid subjects stay on bounded low-distortion patches;
- [ ] arbitrary UV mapping is checked for real surface distortion.

Before delivery:
- [ ] verify aspect error is within tolerance;
- [ ] verify circle/square diagnostic when mapping is uncertain;
- [ ] verify wall thickness and relief depth;
- [ ] verify slicer appearance;
- [ ] provide the one-command source replacement/rebuild workflow.
