# Persistent relief-job format v2.2

Minimal example:

```json
{
  "schema": "heightmap-relief-job-v2.2",
  "source": {
    "spec": "source/source-spec.json",
    "master": "source/source-master.png",
    "manifest": "source/source-master.png.source.json"
  },
  "target": {
    "width_mm": 80,
    "height_mm": 40,
    "surface_type": "cylinder",
    "placement_mode": "front_patch",
    "axis_mode": "xy-z",
    "pitch_x_mm": 0.20,
    "pitch_y_mm": 0.12,
    "dpi_x": 127.0,
    "dpi_y": 211.67
  },
  "image": {
    "class": "person",
    "repeating": false,
    "fit_mode": "contain",
    "aspect_policy": "preserve",
    "allow_aspect_distortion": false,
    "aspect_tolerance_pct": 0.75,
    "bit_depth": 16
  },
  "relief": {
    "mode": "emboss",
    "depth_mm": 1.0,
    "wall_thickness_mm": 2.4
  }
}
```

## Aspect fields are mandatory design intent

The job stores physical target size and pitch separately. Never replace them with only pixel dimensions or only DPI.

`allow_aspect_distortion` must default false. An agent may set it true only after the user explicitly approves a distorted/stretch fit or when a texture intentionally needs anisotropic scaling.

## Build metadata

`prepare_heightmap.py` writes:
- source physical aspect;
- target physical/raster aspect;
- physical pixel aspect;
- placed physical aspect;
- reconstructed physical aspect after integer rasterization;
- aspect error and tolerance;
- preview path and warnings.

The geometry stage should fail/stop if the build metadata says `aspect_validation.passed=false` unless an explicit distortion override exists.
