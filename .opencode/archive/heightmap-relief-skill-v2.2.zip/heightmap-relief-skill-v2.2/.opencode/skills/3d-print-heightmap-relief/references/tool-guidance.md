# OpenSCAD, CadQuery, FreeCAD, Blender

## Common rule

Every tool must consume the target heightmap with its physical width/height and X/Y pitch from metadata. Do not infer scale from raw PNG pixel aspect alone.

## OpenSCAD

Use explicit millimetre scaling. Native planar `surface()` workflows can be useful on flat maps, but curved wrapping is better performed with a pre-wrapped tool/mesh. If the geometry heightmap has non-square physical pixels, scale X and Y according to target millimetres—not according to image-viewer appearance.

## CadQuery

Keep functional base geometry parametric. Dense image relief is often best as a separate mesh/surface tool. Any sampled relief coordinates must be generated from physical X/Y or metric surface distance before Boolean operations.

## FreeCAD

Retain physical scale during mesh import/conversion. Validate final dimensions and aspect after Boolean operations; do not rely on image DPI import behavior.

## Blender

For single subjects, use a deliberately low-distortion UV patch or metric-aware local projection. Do not assume an undistorted-looking UV island preserves physical millimetres. For textures, triplanar/object-space projection can help uniform scale. Use enough mesh density before displacement and preserve the processed image as non-color data.
