# Install

Copy `.opencode/` into an OpenCode project root, or copy the skill directory to the configured OpenCode skills location.

Install helper-script dependencies:

```bash
pip install -r .opencode/skills/3d-print-heightmap-relief/requirements.txt
```

The helper scripts require only NumPy and Pillow. CAD programs are only needed for the project-specific geometry stage.
