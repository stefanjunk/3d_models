# Heightmap Relief Skill v2.2

An OpenCode/Agent-Skills package for image-based 3D-print engraving and embossing.

v2.2 focuses on preventing misshaped artwork caused by independent X/Y resizing or confusion between raw raster aspect and physical surface aspect.

Key behavior:
- 16-bit continuous-tone source/build maps by default;
- AI-generation PPI and physical authoring size persisted;
- immutable, replaceable source master;
- physical-coordinate `contain`/`cover`/crop;
- no silent `stretch`;
- target X/Y printer sampling may differ without distorting the physical image;
- square-pixel preview for human review;
- explicit aspect-validation gate before geometry generation;
- metric-aware guidance for plane, cylinder, rounded box, sphere, ellipsoid, and arbitrary UV surfaces.

Run tests:

```bash
cd .opencode/skills/3d-print-heightmap-relief
python tests/run_tests.py
```
