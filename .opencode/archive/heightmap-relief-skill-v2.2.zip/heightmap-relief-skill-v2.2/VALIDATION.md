# Validation — v2.2

Validated in the build environment with Python 3.13, NumPy, and Pillow.

## Automated regression tests

10 tests passed:

- anisotropic X/Y target sampling preserves a circle's **physical** aspect;
- square-pixel preview restores correct human-viewing proportions;
- `stretch` is rejected when physical aspect preservation is active;
- explicit stretch opt-in records the expected distortion;
- `cover` preserves source physical aspect before cropping;
- CLI preparation writes a 16-bit target heightmap and passing aspect metadata;
- wrong-aspect AI/source raster is registered with contain rather than silent stretch;
- repeating tile aspect changes are rejected without explicit distortion permission;
- cylinder mapping uses arc length `s=R*theta`;
- sphere longitude scale correctly shrinks with `cos(latitude)`.

## End-to-end rebuild smoke test

A temporary source-swappable job was initialized with:

- target surface patch: 80×40 mm;
- target pitch: 0.20×0.10 mm/pixel;
- target raw raster: 400×400 px;
- target physical aspect: 2.0;
- target raw raster aspect: 1.0.

A procedural square-pixel source was registered into a 16-bit source master and rebuilt through `rebuild_relief_job.py`.

Result:

- physical aspect error: 0.0%;
- aspect validation: PASS;
- square-pixel preview created at the intended 2:1 display aspect;
- source registration and target rebuild used separate canonical source/build files.

This demonstrates the intentionally counter-intuitive case where a 400×400 geometry raster correctly represents an 80×40 mm physical image because X/Y physical pixel pitch differs by 2:1.

## Static checks

- all Python helper scripts compile;
- all SKILL.md reference links resolve to packaged files;
- example job JSON parses;
- no `__pycache__` or generated test artifacts are retained in the release archive.
