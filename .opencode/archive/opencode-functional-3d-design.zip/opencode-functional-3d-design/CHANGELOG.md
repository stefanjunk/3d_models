# Changelog

## 1.0.0 - 2026-08-09

- Initial OpenCode skill package.
- Added tool-selection guidance for OpenSCAD, CadQuery, FreeCAD, and Blender.
- Added print-vs-buy modes and component decision rules.
- Added broad filament and nozzle/layer guidance.
- Added validation, simulation, slicing, and physical-test workflow.
- Added reusable CLI calculators and local parts-library tooling.
- Added three requested design examples and calibration coupons.
- Added executable CadQuery/OpenSCAD builds, mesh reports, previews, and automated unit tests.
- Added automation architecture, CAD coding standards, organic-mesh, simulation-fidelity, design-pattern, and extension roadmaps.
- Added optional subagents, commands, external references, and self-learning workflow.
