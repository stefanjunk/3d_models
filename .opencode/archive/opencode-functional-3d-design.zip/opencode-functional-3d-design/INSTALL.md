# Installation and configuration

## Project-local installation

From the package root:

```bash
./install.sh --project /absolute/path/to/project
```

This merges the package's `.opencode/skills`, `.opencode/agents`, and `.opencode/commands` folders. Existing files are not overwritten unless `--force` is supplied.

## Global skill only

```bash
./install.sh --global
```

This installs the skill to:

```text
~/.config/opencode/skills/functional-3d-design
```

Agents and commands remain project-specific by default because permissions, model IDs, and shell access should be reviewed per repository.

## Fast-model subagent

The active `cad-microtask` agent deliberately inherits the invoking agent's model so the package works with every provider. To pin a fast model, copy the example:

```bash
cp config-examples/cad-microtask-spark.md .opencode/agents/cad-microtask.md
```

Then edit the model ID if your provider exposes a different identifier. Model IDs use the OpenCode `provider/model-id` form.

## Optional external references

Merge the `references` object from `config-examples/opencode.references.jsonc` into your own `opencode.jsonc`. This makes upstream documentation and libraries visible as OpenCode references without copying them into the project.

Review licenses and source provenance before redistributing generated geometry or vendored parts.

## Optional MCPs and skills

Read:

```text
.opencode/skills/functional-3d-design/references/external-integrations.md
```

The package does not silently clone, install, or execute third-party code. Use:

```bash
python .opencode/skills/functional-3d-design/scripts/external_integrations.py list
```

to print a reviewed integration plan.

## Check the environment

```bash
python .opencode/skills/functional-3d-design/scripts/environment_check.py
```

## Test the package

```bash
make test
make examples
```
