# Functional 3D Design for OpenCode

A project-local OpenCode skill package for designing functional parts that are primarily made by FDM/FFF printing and, where useful, completed with purchased standard components.

The package is source-first and validation-first. It helps an agent turn a request into:

- a measurable design specification;
- a print-vs-buy and part-consolidation decision;
- an appropriate CAD/tool route;
- parameterized source code;
- STEP/3MF/STL deliverables where the selected tool supports them;
- a bill of materials;
- a print profile recommendation;
- geometry, slicing, simulation, coupon, and physical-test plans;
- versioned evidence that can promote a design into a reusable local parts library.

## Install in the current project

Copy or merge the included `.opencode` directory into the root of your OpenCode project:

```bash
cp -R .opencode /path/to/your/project/
```

Or use the installer:

```bash
./install.sh --project /path/to/your/project
```

For a global skill installation:

```bash
./install.sh --global
```

OpenCode discovers project skills at `.opencode/skills/<name>/SKILL.md`. The included commands and subagents are project-local as well.

## Main commands

```text
/design-3d <request>
/review-3d <project directory or design report>
/cad-microtask <small bounded calculation or classification>
/learn-part <part entry or completed project>
```

The central skill can also be loaded explicitly as `functional-3d-design`.

## Included examples

1. `honeycomb-wall-shelf`: CadQuery, printed honeycomb display cell plus purchased wall fasteners.
2. `rounded-desk-organizer`: CadQuery, rounded body, two drawers, and divided top compartments.
3. `unicorn-dice-tower`: OpenSCAD, printable tower with self-supporting ramps, tray, and an original unicorn engraving.
4. `calibration-coupons`: OpenSCAD fit, wall, bridge, and engraving coupons.

The example build command is:

```bash
make examples        # deterministic source/export/mesh checks
make previews        # optional PNG previews; slower
```

Generated files are written below `generated/` and are not treated as validated production parts merely because they render successfully.

## Recommended operating model

Use a capable primary agent for requirements, architecture, failure analysis, and final review. Delegate bounded tasks—parameter extraction, library searches, formula checks, mesh-report summaries, and small edits—to a fast subagent. An optional configuration example shows how to assign GPT-5.3-Codex-Spark or another low-latency coding model when that model is available through your OpenCode provider.

## Dependency levels

The instruction skill itself is plain Markdown/YAML/JSON. Helper scripts use Python 3.11+.

```text
Core helpers:       PyYAML
Mesh validation:    trimesh, numpy
CadQuery examples:  cadquery
OpenSCAD examples:  openscad executable
Optional previews:  matplotlib
```

Install Python dependencies with:

```bash
python -m pip install -r requirements.txt
```

OpenSCAD, FreeCAD, Blender, a slicer, and simulation tools remain external applications. The skill never uploads or starts a print job automatically.

## Safety scope

This package is suitable for prototyping and engineering assistance, not certification. Human review and physical testing are mandatory for structural, child-safety, electrical, pressure-containing, medical, food-contact, fire-safety, or other safety-critical applications. Wall anchors and fasteners must match the actual wall material and load; the wall-shelf example is intentionally not supplied with a claimed safe load rating.

## Package contents

```text
.opencode/
  skills/functional-3d-design/
    SKILL.md
    references/
    scripts/
    data/
    schemas/
    templates/
    examples/
    tests/
  agents/
  commands/
config-examples/
```

See `INSTALL.md` for setup choices, `VALIDATION.md` for executed checks and limitations, and `.opencode/skills/functional-3d-design/references/` for the full engineering guidance.

## Recommended next adaptations

For a real printer environment, add a process-specific calibration registry, a slicer CLI adapter, geometric regression checks, measured material coupons, and an evidence-backed standard-component catalog. The detailed roadmap is in `references/recommended-extensions.md`.
