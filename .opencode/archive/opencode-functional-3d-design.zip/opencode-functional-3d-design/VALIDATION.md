# Package validation report

Validation date: 2026-08-09

## Automated checks completed

- OpenCode skill frontmatter and expected directory structure
- Markdown agent/command frontmatter presence
- YAML and JSON parsing
- Python syntax compilation
- tool/material/nozzle routing scripts
- print-vs-buy, fit, snap-fit, and gear calculators
- design-spec validation for every example
- local parts-library qualification gate
- CadQuery source execution and STEP/STL export
- OpenSCAD source execution and STL export
- Trimesh topology, watertightness, body-count, bounds, and volume checks

The unit-test log is in `generated/unit-tests.txt`. The aggregate example report is in `generated/validation-summary.json`.

## Example result summary

| Example | Source/export check | Mesh check |
|---|---|---|
| honeycomb wall shelf + keyhole coupon | passed | passed |
| rounded desk organizer parts | passed | passed |
| integrated unicorn dice tower | passed | passed |
| fit/wall/engraving/bridge coupons | passed | passed |

`passed` here means the source executed and the generated manufacturing mesh met the automated checks declared by the example. It does **not** mean the part has passed slicing, printing, proof load, fatigue, wear, user safety, or service tests.

## Tested environment

See `generated/environment-report.json` for exact detected versions. This package was executed with:

- Python 3.13.5
- CadQuery 2.8.0
- OpenSCAD 2021.01
- Trimesh 4.11.1
- NumPy 2.3.5
- scikit-image 0.26.0
- PyYAML 6.0.3
- Matplotlib 3.10.8

## Not executed in this environment

- FreeCAD GUI/Python/FEM workflows
- Blender GUI/Python/MCP workflows
- PrusaSlicer or OrcaSlicer CLI dry-runs
- printer upload or start
- physical printing and dimensional coupons
- proof load, cycle, creep, impact, UV, temperature, chemical, or wear tests

Those paths are documented but must be validated in the target environment.

## Safety limitations

The wall-shelf example intentionally has no safe-load rating. Wall substrate, anchors, screws, installation, proof load, and creep must be verified as a complete system. The dice-tower example requires age-appropriate edge/small-component review and repeated dice-flow testing. The organizer requires real drawer-clearance and anti-tip tests.
