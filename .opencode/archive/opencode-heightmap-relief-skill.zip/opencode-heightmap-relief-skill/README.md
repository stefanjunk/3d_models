# 3D-print height-map relief — OpenCode skill package

This archive contains the project-local OpenCode skill:

```text
.opencode/skills/3d-print-heightmap-relief/
```

Copy `.opencode` into the root of an OpenCode project. The skill includes researched guidance, scripts, schemas, templates, procedural source images, prepared height maps, three complete examples, and validation reports.

Start with:

- `.opencode/skills/3d-print-heightmap-relief/INSTALL.md`
- `.opencode/skills/3d-print-heightmap-relief/SKILL.md`
- `.opencode/skills/3d-print-heightmap-relief/references/00-workflow.md`

Run the self-test from the skill directory:

```bash
python scripts/self_test.py
```

The package was validated with Python, CadQuery, and OpenSCAD. Blender and FreeCAD templates are included but were not runtime-tested in the build environment; this is recorded in `tests/validation-summary.json`.
