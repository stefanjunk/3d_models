from __future__ import annotations

import json
import re
import unittest
from pathlib import Path

import yaml


SKILL = Path(__file__).resolve().parents[1]


class SkillStructureTests(unittest.TestCase):
    def test_skill_frontmatter(self) -> None:
        text = (SKILL / "SKILL.md").read_text(encoding="utf-8")
        self.assertTrue(text.startswith("---\n"))
        parts = text.split("---", 2)
        self.assertGreaterEqual(len(parts), 3)
        meta = yaml.safe_load(parts[1])
        self.assertEqual(meta["name"], "functional-3d-design")
        self.assertRegex(meta["name"], r"^[a-z0-9]+(?:-[a-z0-9]+)*$")
        for key in ["name", "description", "license", "metadata"]:
            self.assertIn(key, meta)

    def test_expected_directories_and_examples(self) -> None:
        for directory in ["references", "scripts", "data", "schemas", "templates", "examples", "tests"]:
            self.assertTrue((SKILL / directory).is_dir(), directory)
        for example in ["honeycomb-wall-shelf", "rounded-desk-organizer", "unicorn-dice-tower", "calibration-coupons"]:
            self.assertTrue((SKILL / "examples" / example).is_dir(), example)
            self.assertTrue((SKILL / "examples" / example / "design-spec.yaml").exists())

    def test_yaml_and_json_are_parseable(self) -> None:
        for path in SKILL.rglob("*.yaml"):
            with self.subTest(path=path):
                yaml.safe_load(path.read_text(encoding="utf-8"))
        for path in SKILL.rglob("*.json"):
            with self.subTest(path=path):
                json.loads(path.read_text(encoding="utf-8"))

    def test_opencode_integration(self) -> None:
        opencode = SKILL.parent.parent
        expected_commands = ["design-3d", "review-3d", "cad-microtask", "learn-part"]
        expected_agents = ["functional-3d-designer", "3d-design-reviewer", "cad-microtask", "parts-librarian"]
        for name in expected_commands:
            path = opencode / "commands" / f"{name}.md"
            self.assertTrue(path.exists(), path)
            metadata = yaml.safe_load(path.read_text(encoding="utf-8").split("---", 2)[1])
            self.assertTrue(metadata.get("description"), path)
        for name in expected_agents:
            path = opencode / "agents" / f"{name}.md"
            self.assertTrue(path.exists(), path)
            metadata = yaml.safe_load(path.read_text(encoding="utf-8").split("---", 2)[1])
            self.assertIn(metadata.get("mode"), {"primary", "subagent"}, path)

    def test_no_placeholder_tokens_in_core(self) -> None:
        pattern = re.compile(r"\b(TODO|FIXME|REPLACE_ME)\b")
        for path in [SKILL / "SKILL.md", *(SKILL / "references").glob("*.md")]:
            with self.subTest(path=path):
                self.assertIsNone(pattern.search(path.read_text(encoding="utf-8")))


if __name__ == "__main__":
    unittest.main()
