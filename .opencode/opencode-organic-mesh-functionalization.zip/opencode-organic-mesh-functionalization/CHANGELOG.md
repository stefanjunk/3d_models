# Changelog

## 1.0.0 — 2026-08-09

- Initial standalone OpenCode skill package.
- Added ROI/protected/transition/keep-out operating model.
- Added Blender, OpenSCAD, CadQuery, FreeCAD, Trimesh/Manifold, voxel/SDF, and hybrid guidance.
- Added mesh inspection, memory estimation, landmark fitting, primitive generation, Boolean, section, and protected-surface validation scripts.
- Added dice tower, barefoot shoe, and unicorn compartment examples.
- Added agents, commands, templates, schemas, tests, installation, and packaging tools.
