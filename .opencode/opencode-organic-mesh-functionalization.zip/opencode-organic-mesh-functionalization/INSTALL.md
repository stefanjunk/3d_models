# Installation

## Project-local package

```bash
./install.sh --project /absolute/path/to/project
```

This merges skills, agents, and commands into `PROJECT/.opencode`. Existing files are not overwritten unless `--force` is supplied.

## Global skill only

```bash
./install.sh --global
```

This installs the skill at:

```text
~/.config/opencode/skills/organic-mesh-functionalization
```

Agents and commands remain project-local by default because shell and external-tool permissions should be reviewed per repository.

## Python environment

```bash
python -m pip install -r requirements.txt
```

Optional capabilities:

```bash
python -m pip install -r requirements-optional.txt
```

Install only the optional packages supported by your platform. `cadquery` runs the example generators, `manifold3d` enables the preferred headless Boolean backend, `rtree` improves proximity queries, and `fast-simplification` enables proxy decimation.

Blender, OpenSCAD, and FreeCAD are optional external applications. Run:

```bash
make env
```

The package remains useful with only NumPy, SciPy, Trimesh, PyYAML, and jsonschema. `manifold3d` enables the preferred headless mesh Boolean engine; CadQuery enables the included functional-part examples.

## Fast microtask model

The installed `mesh-microtask` inherits the current model. To pin GPT-5.3 Codex Spark:

```bash
cp config-examples/mesh-microtask-spark.md .opencode/agents/mesh-microtask.md
```

Review and adjust the provider/model identifier for your OpenCode configuration.

## Companion skill

Install `functional-3d-design` beside this skill when you want its deeper material/nozzle/slicer, fastener, gear, snap-fit, print-vs-buy, and physical-test guidance. Neither package requires the other at runtime.

## Optional OpenCode references

Merge the `references` object from `config-examples/opencode.references.jsonc` into your project configuration. OpenCode supports both local directory references and Git repository references. Adjust the local `functional-3d-design` path to your actual layout.
