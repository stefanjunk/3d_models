# OpenCode Organic Mesh Functionalization Skill

A source-first OpenCode skill for augmenting high-resolution AI-generated, scanned, or sculpted organic meshes with parametric functional geometry while preserving protected decorative surfaces.

It complements `functional-3d-design` but can operate independently.

## Typical jobs

- hollow a decorative dice-tower shell and add a parametric stair/baffle insert;
- remove an AI-generated shoe upper/interior and fit a parametric zero-drop sole;
- add a rounded compartment, door, hinge, and latch to a toy figure;
- add precise sockets, channels, mounts, electronics pockets, openings, flanges, or replaceable inserts to STL/OBJ/3MF/GLB meshes.

## Core idea

Every edit is planned as:

```text
functional ROI
+ protected region
+ transition band
+ keep-out regions
+ parametric functional geometry
+ measured validation
```

A successful Boolean or attractive render is not accepted as proof. The package includes tools for baseline inspection, memory estimation, primitive generation, landmark alignment, mesh Booleans, cross-sections, and symmetric protected-surface comparison.

## Included tool guidance

- Blender for dense organic meshes, segmentation, Shrinkwrap, local remesh, and visual review;
- CadQuery for exact functional parts and STEP masters;
- OpenSCAD for simple CSG on already clean meshes;
- FreeCAD for measured assembly, mesh/STEP context, drawings, and selected FEM;
- Trimesh + Manifold3D for headless inspection and valid-mesh Booleans;
- local voxel/SDF methods for invalid topology, uniform offsets, and difficult blended transitions.

## Quick start

```bash
./install.sh --project /absolute/path/to/your/project

python .opencode/skills/organic-mesh-functionalization/scripts/project_init.py my-edit
cd my-edit
python ../.opencode/skills/organic-mesh-functionalization/scripts/inspect_mesh.py \
  source/original.stl --json-out validation/baseline.json
```

In OpenCode:

```text
/functionalize-mesh Add a removable belly compartment to source/unicorn.stl.
```

## Examples

The package contains parametric generators and operation plans for:

- `dice-tower`
- `barefoot-shoe`
- `unicorn-compartment`

Generate their functional parts with:

```bash
make examples
```

The original organic meshes are intentionally not bundled.

## Validation scripts

```bash
python .opencode/skills/organic-mesh-functionalization/scripts/inspect_mesh.py --help
python .opencode/skills/organic-mesh-functionalization/scripts/estimate_memory.py --help
python .opencode/skills/organic-mesh-functionalization/scripts/fit_landmarks.py --help
python .opencode/skills/organic-mesh-functionalization/scripts/boolean_mesh.py --help
python .opencode/skills/organic-mesh-functionalization/scripts/validate_edit.py --help
python .opencode/skills/organic-mesh-functionalization/scripts/section_report.py --help
```

## Design limits

The workflow does not make an ambiguous surface into a safe solid automatically, infer footwear fit from an exterior shell, guarantee wall thickness from a coarse mesh, or certify toys/structural parts. It explicitly stops or changes strategy when source validity, alignment, memory, print resolution, or protected-detail requirements make a requested operation unreliable.
