# Package validation

The package test suite checks:

- OpenCode skill frontmatter and directory layout;
- YAML/JSON parsing and schemas;
- command/agent definitions;
- ROI masks and rigid landmark fitting;
- baseline mesh inspection;
- symmetric protected-surface validation on an unchanged mesh;
- cross-section area reporting;
- execution of all three CadQuery example generators.

Run:

```bash
make test
make examples
make env
```

Limitations of package-level tests:

- Blender and FreeCAD templates are syntax/procedure references unless those applications are installed.
- No proprietary or AI-generated source meshes are bundled.
- Mesh Boolean tests depend on an installed Manifold3D or Blender engine.
- Physical printing, wall-thickness verification, slicer review, and functional tests remain project-specific.
