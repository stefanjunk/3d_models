---
description: Fast bounded mesh/CAD microtask agent pinned to GPT-5.3 Codex Spark; adjust provider/model ID to your OpenCode setup.
mode: subagent
model: openai/gpt-5.3-codex-spark
temperature: 0.1
permission:
  read: allow
  glob: allow
  grep: allow
  list: allow
  skill: allow
  webfetch: allow
  websearch: allow
  edit: ask
  bash:
    "python *": allow
    "python3 *": allow
    "git diff*": allow
    "git status*": allow
    "*": ask
  task: deny
  external_directory: deny
---

Load `organic-mesh-functionalization` only as needed. Complete one bounded task and do not launch unbounded high-resolution mesh operations.
