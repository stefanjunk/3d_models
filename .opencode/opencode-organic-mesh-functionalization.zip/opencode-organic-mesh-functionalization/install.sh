#!/usr/bin/env bash
set -euo pipefail

ROOT="$(cd "$(dirname "${BASH_SOURCE[0]}")" && pwd)"
FORCE=0
MODE=""
TARGET=""

usage() {
  cat <<'USAGE'
Usage:
  ./install.sh --project /path/to/project [--force]
  ./install.sh --global [--force]

Project mode installs skills, agents, and commands under PROJECT/.opencode.
Global mode installs only the skill under ~/.config/opencode/skills.
USAGE
}

while [[ $# -gt 0 ]]; do
  case "$1" in
    --project) MODE="project"; TARGET="${2:-}"; shift 2 ;;
    --global) MODE="global"; shift ;;
    --force) FORCE=1; shift ;;
    -h|--help) usage; exit 0 ;;
    *) echo "Unknown argument: $1" >&2; usage >&2; exit 2 ;;
  esac
done

[[ -n "$MODE" ]] || { usage >&2; exit 2; }

copy_tree() {
  local src="$1" dst="$2"
  mkdir -p "$dst"
  if [[ "$FORCE" -eq 1 ]]; then cp -R "$src"/. "$dst"/; else cp -Rn "$src"/. "$dst"/; fi
}

if [[ "$MODE" == "project" ]]; then
  [[ -n "$TARGET" ]] || { echo "--project requires a path" >&2; exit 2; }
  mkdir -p "$TARGET/.opencode"
  copy_tree "$ROOT/.opencode/skills" "$TARGET/.opencode/skills"
  copy_tree "$ROOT/.opencode/agents" "$TARGET/.opencode/agents"
  copy_tree "$ROOT/.opencode/commands" "$TARGET/.opencode/commands"
  echo "Installed project package to $TARGET/.opencode"
else
  DEST="${HOME}/.config/opencode/skills/organic-mesh-functionalization"
  mkdir -p "$(dirname "$DEST")"
  copy_tree "$ROOT/.opencode/skills/organic-mesh-functionalization" "$DEST"
  echo "Installed global skill to $DEST"
fi
