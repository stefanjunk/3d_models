# Decision Log

| ID | Entscheidung | Begründung | Folge |
|---|---|---|---|
| D-001 | Funktionale Rekonstruktion statt 1:1-Replik | Nur eine unkalibrierte Konzeptansicht vorhanden | Verdeckte Mechanik ist ausdrücklich als konstruktive Annahme markiert |
| D-002 | Manifold-3D-Kernel und parametrischer JS-Quellcode | Robuste, indexierte, wasserdichte Meshes und reproduzierbare CSG-Geometrie | STL und 3MF werden deterministisch erzeugt |
| D-003 | Offener, nicht eingerasteter Exportzustand | Verhindert verschmolzene Rastflächen und eingedruckte Dauerspannung | Clip wird nach dem Druck erstmals geschlossen |
| D-004 | Lange C-Flexur mit Hartanschlag | Reduziert Dehnung gegenüber einem kurzen Filmscharnier | Coupon- und Zyklentest bleiben verpflichtend |
| D-005 | Funktionsgeometrie beginnt auf der Druckseite | Vermeidet schwebende Kämme, Rastzungen und zweite Flexuren | Verdeckte Innenseite ist leicht asymmetrisch, Außendesign bleibt erhalten |
| D-006 | Ungefülltes PETG | Gewünscht und duktiler als steifes PETG-CF/GF für Flexuren | Herstellerprofil und reales Ermüdungsverhalten müssen getestet werden |
| D-007 | Revision 3 als neue Anforderungen behandeln | Vollständige Hexagone, zusätzliche Seitenpanzerung und Materialabtrag ändern Erscheinung und Außenkontur | Anforderungen und Konzept müssen erneut freigegeben werden; Produktions-CAD r2 bleibt bis dahin unverändert |
| D-008 | Hexagon-Startwerte 8,0 / 0,8 / 0,9 mm | Bei 0,4-mm-Düse sind die 0,8-mm-Fugen klar slicbar; 8-mm-Zellen ergeben mehrere erkennbare Reihen auf 22 mm Breite | Werte werden in der Konzeptansicht geprüft und bleiben parametrisch |
| D-009 | Untere Mittelschiene auf der Nicht-Druckbettseite auf 12,5 mm Funktionsbreite reduzieren | Zähne und belastete Anbindung liegen bereits druckbettseitig; die entfernte Zone berührt weder Gelenk noch Rastclip | Volle Breite bleibt lokal an Gelenk und Rastclip, Übergänge werden facettiert |
| D-010 | Konzept Revision 3 freigegeben | Der Nutzer hat die Ansicht mit vollständigen Hexagonen und verschlankter Unterseite ausdrücklich freigegeben | Produktions-CAD und Exporte dürfen auf Revision 3 aktualisiert werden |
| D-011 | Drei vollständige obere Hexagonreihen statt am Rand beschnittener Zellen | 8,0-mm-Zellen plus 0,8-mm-Fugen passen nicht ohne Randbeschnitt in die 22-mm-Strukturbreite | Die vollständige Armor-Hülle misst 25,6 mm; die erste Reihe beginnt bei Z=0, die dritte wächst druckbar über die Nicht-Bettseite hinaus |
| D-012 | Eine eigene, tangential ausgerichtete Hexagonreihe auf der Nicht-Bettseite | Die 2,4-mm-Schale allein ist zu schmal für eine flächige 8-mm-Wabe | Jede vollständige Seitenzelle überlappt das Schalenband und bleibt außerhalb der Rastzungen-Freigabe |
| D-013 | Untere Schiene mit linearen Breitenübergängen 22→12,5→22 mm | Spart die ungenutzte obere Seitenzone, ohne Kammzähne, Gelenk- oder Clipanbindung zu schwächen | Facettierte Übergänge liegen bei X=11–16 mm und X=47–52 mm |
