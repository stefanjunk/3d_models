# Shower drain hair trap – exact 945 × 65 × 20 mm, edge-start swirl-rib revision

This revision keeps the larger-open-area funnel concept, but changes the rib geometry so the ribs **start directly at the outer funnel edge** and blend into the **top surface level** with **no radial gap**. From there, the ribs descend inward following the funnel slope, so water entering the funnel is guided into a swirl immediately.

## Main geometry
- Exact assembled outer size: **945.0 × 65.0 × 20.0 mm**
- Segment count: **4**
- Segment outer size: **236.25 × 65.0 × 20.0 mm** each
- Cross-section: **inverted U-profile** (open underside)
- Top plate thickness: **4.2 mm**
- Side wall thickness: **3.0 mm**
- Side wall height below top plate: **15.8 mm**

## Funnel / sieve geometry
- **4 catcher zones per segment** in one centered row → **16 total**
- funnel entry diameter: **46.0 mm**
- funnel depth: **2.5 mm**
- lower flat capture-floor diameter: **38.0 mm**
- sieve field radius: **16.0 mm**
- hole-free outer rim inside the funnel: **3.0 mm radial margin**
- sieve hole diameter: **2.8 mm**
- hole pitch: **4.3 mm**
- **55 holes per catcher**
- **880 holes total**
- gross open hole area: **~5419 mm²**

## Rib revision
- **5 swirl ribs per catcher**
- ribs are **1.6 mm** wide
- ribs begin **at the outer funnel edge**
- ribs merge into the **outer top surface level** and then descend with the funnel slope
- no radial gap between funnel edge and rib start
- rib inner end is pulled back from the center for a more open center drain area
- smaller center boss remains for hair collection / structural continuity

## Joining strategy
- Exact outside dimensions are preserved via **loose internal joiner keys**.
- Each seam uses **3 keys**.
- Included parts:
  - `joiner_key.stl`
  - `joiner_keys_12x.stl`

## Files
- `panel_left.stl`
- `panel_mid_left.stl`
- `panel_mid_right.stl`
- `panel_right.stl`
- `joiner_key.stl`
- `joiner_keys_12x.stl`
- `fit_coupon.stl`
- `functional_test_tile_80mm.stl`
- corresponding STEP files
- parametric source: `build_shower_drain_hairtrap_945x65_funnel_edge.py`

## Recommended print / test flow
1. Print `functional_test_tile_80mm.stl` first.
2. Check whether the new edge-start ribs behave as intended under water.
3. Check support cleanup on the funnel walls.
4. If hair retention is still too weak, reduce the hole diameter in the parameter file from **2.8 mm** to **2.6 mm** while keeping the same funnel/rib layout.
5. Then print the 4 final segments.
