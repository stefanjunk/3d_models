# Shower drain hair trap – exact 945 × 65 × 20 mm, larger-open-area funnel revision

This revision is based on the previous one-piece inverted U-profile funnel design, but with a **larger complete funnel/catcher diameter**, a **larger sieve area**, **slightly larger holes**, and **more open flow paths between the ribs**.

## Main geometry
- Exact assembled outer size: **945.0 × 65.0 × 20.0 mm**
- Segment count: **4**
- Segment outer size: **236.25 × 65.0 × 20.0 mm** each
- Cross-section: **inverted U-profile** (open underside)
- Top plate thickness: **4.2 mm**
- Side wall thickness: **3.0 mm**
- Side wall height below top plate: **15.8 mm**

## Revised drain / hair-catch concept
- **4 catcher zones per segment** in one centered row → **16 total**
- Entire catcher enlarged:
  - funnel entry diameter: **46.0 mm**
  - funnel depth: **2.5 mm**
  - lower flat capture-floor diameter: **38.0 mm**
- The sieve area was enlarged as well:
  - hole field radius: **16.0 mm**
  - hole-free outer rim inside the funnel: **3.0 mm radial margin**
- Sieve holes slightly enlarged for better flow:
  - hole diameter: **2.8 mm**
  - hole pitch: **4.3 mm**
  - **55 holes per catcher**
  - **880 holes total**
  - gross open hole area: **~5419 mm²**

## Rib revision
- **5 swirl ribs per catcher**
- ribs are slightly **narrower** than before to open the channels more
- ribs begin **farther outward** in the funnel
- ribs end at the **funnel/upper surface level**
- rib inner end is pulled **back from the center**, leaving a more open center drain area
- smaller center boss for additional free flow area

## Joining strategy
- Exact outside dimensions are preserved via **loose internal joiner keys**.
- Each seam uses **3 keys**.
- Included parts:
  - `joiner_key.stl`
  - `joiner_keys_12x.stl`

## Files
- `panel_left.stl`
- `panel_mid_left.stl`
- `panel_mid_right.stl`
- `panel_right.stl`
- `joiner_key.stl`
- `joiner_keys_12x.stl`
- `fit_coupon.stl`
- `functional_test_tile_75mm.stl`
- corresponding STEP files
- parametric source: `build_shower_drain_hairtrap_945x65_funnel_open.py`

## Recommended print/test flow
1. Print `functional_test_tile_75mm.stl` first.
2. Test the balance between flow, support cleanup, and hair retention.
3. If too much hair still passes through, reduce the hole diameter in the parameter file from 2.8 mm to 2.6 mm.
4. If support cleanup is acceptable, print the 4 final segments.

## Design intent
This version explicitly aims for a **better balance between drainage area and structural stability**:
- larger funnel and sieve area for more throughput
- slightly larger holes and more open rib spacing for lower clogging tendency
- enough solid rim and remaining top material to keep the segment stiff enough in PETG
