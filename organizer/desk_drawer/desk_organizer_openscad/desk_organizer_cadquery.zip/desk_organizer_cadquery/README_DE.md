# Modularer Schreibtisch-Organizer – CadQuery-Version

Diese Version ersetzt OpenSCAD + separaten Mesh-Exporter durch **ein einziges parametrisches CadQuery-Mastermodell**. STL und STEP werden aus demselben OpenCascade-BRep erzeugt.

## Enthaltene Module

- `drawer_housing` – Gehäuse für zwei Schubladen
- `drawer` – einzelne Schublade (`drawer_1` und `drawer_2` sind identische Kopien)
- `cubby` – offenes Ablagefach
- `shallow_tray` – flache Ablage, inkl. Docking-Aussparungen für das Drawer-Housing
- `divided_bin` – unterteiltes Organizerfach
- `pen_cup` – hoher Stiftehalter
- `connector_test` – Testteil für die seitliche Steckverbindung

## Ordner

- `exports_untextured/` – STL + STEP ohne Bildgravur
- `exports_textured_all/` – STL + STEP mit Carbon-Bildgravur
- `assets/` – Carbon-Heightmap / Bildquelle

## Export

Alle Teile ohne Textur:

```bash
python organizer.py --part all --out exports_untextured
```

Ein einzelnes Teil:

```bash
python organizer.py --part drawer_housing --out my_exports
python organizer.py --part drawer --out my_exports
python organizer.py --part divided_bin --out my_exports
```

Mit Bildgravur:

```bash
python organizer.py \
  --part all \
  --texture \
  --texture-image assets/carbon_fiber_heightmap_source.png \
  --texture-resolution 256 \
  --texture-depth 0.40 \
  --out exports_textured_all
```

## Bildgravur / Low-Res-Modus

`target_resolution = 256` ist der Default und bleibt als Parameter erhalten. Die 256×256-Pixel werden als **Bild-/Preprocessing-Auflösung** genutzt.

Die CAD-Geometrie wird absichtlich nicht pixelweise erzeugt. Stattdessen wird das Bild in durchgehende, in ihrer Breite modulierte Gravurlinien übersetzt. Dadurch entsteht ein kupferstichähnlicher Look, ohne zehntausende kleine Boolean-Körper zu erzeugen.

Wichtige Parameter in `TextureConfig`:

- `target_resolution = 256` – Bild-Zielauflösung
- `depth = 0.40` – Gravurtiefe
- `top_clear = 4.0` – texturfreier Bereich oben
- `bottom_clear = 4.0` – texturfreier Bereich unten
- `min_feature_mm = 1.20` – minimale physisch umgesetzte Detailgröße
- `cad_max_columns = 40` – BRep-Komplexitätslimit quer
- `max_rows = 32` – maximale Anzahl Gravurlinien

Die Seiten-Steckverbinder werden **nach** der Textur wieder als saubere CAD-Geometrie angefügt. Die Textur beeinflusst deshalb die Passflächen der Verbinder nicht.

## Konstruktive Korrektur aus dem Test

Beim echten CadQuery-Kollisionstest wurde sichtbar, dass die alten Führungsschienen aus dem SCAD-Entwurf ca. 0,6 mm in den Schubladenkörper hineinragten. Die Führungsschienen wurden deshalb minimal zurückgesetzt. Die äußere Designsprache und die Schubladenabmessungen bleiben erhalten.

Aktuelle Schubladenpassung:

- seitliches Spiel: **0,50 mm je Seite**
- Spiel nach hinten: **1,80 mm**
- vertikales Spiel: **2,60 mm**
- Boolean-Kollision Schublade ↔ Gehäuse: **0,0 mm³**

Tray auf Drawer-Housing:

- Boolean-Kollision bei eingerasteter Position: **0,0 mm³**

## Validierung

Ausführen:

```bash
python validate_project.py
```

Geprüft werden für alle untexturierten und texturierten Teile:

- CadQuery/OpenCascade BRep gültig
- STL wasserdicht (`watertight`)
- STL genau eine zusammenhängende Komponente
- STEP erneut importierbar
- STEP genau ein Solid
- STEP-Volumen entspricht dem Ausgangs-BRep
- Schublade kollidiert nicht mit dem Gehäuse
- Tray kollidiert nicht mit dem Drawer-Housing
- Textur verändert die Außen-Bounding-Box nicht

Der mitgelieferte `TEST_REPORT.json` ist aus einem erfolgreichen vollständigen Testlauf erzeugt worden.

## Gemessene Laufzeit / Speicher im Testcontainer

Vollständiger Export aller sieben texturierten Teile mit `target_resolution=256`:

- Laufzeit: ca. **30 s**
- Peak-RAM: ca. **691 MB**

Die CadQuery-Basis selbst benötigt in dieser Umgebung bereits einen großen Teil davon; die Bildgravur erhöht den Peak nur moderat, weil keine pixelweise Heightmap-BRep erzeugt wird.
