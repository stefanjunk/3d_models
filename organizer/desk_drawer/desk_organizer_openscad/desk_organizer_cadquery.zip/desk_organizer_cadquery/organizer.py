from __future__ import annotations

from dataclasses import dataclass, replace
from pathlib import Path
from typing import Iterable, Optional, Sequence
import argparse
import json
import math
import os
import time

import cadquery as cq
from cadquery import exporters
import numpy as np
from PIL import Image, ImageOps


# -----------------------------------------------------------------------------
# Configuration
# -----------------------------------------------------------------------------

@dataclass(frozen=True)
class TextureConfig:
    enabled: bool = False
    image_file: str = "assets/carbon_fiber_heightmap_source.png"
    target_resolution: int = 256  # high but still useful as preprocessing input
    depth: float = 0.40
    top_clear: float = 4.0
    bottom_clear: float = 4.0
    front_margin: float = 2.0
    side_margin: float = 3.0
    min_feature_mm: float = 1.20  # physical CAD detail floor for a 0.4 mm nozzle
    line_fill: float = 0.50       # retained for compatibility/reporting
    threshold: float = 0.52       # retained for compatibility/reporting
    cad_max_columns: int = 40     # BRep simplification, independent of image target res
    max_rows: int = 32            # BRep scanline cap; target_resolution can stay 256
    connector_keepout: float = 11.0


@dataclass(frozen=True)
class OrganizerConfig:
    fit: float = 0.35
    legacy_ribs: bool = False
    texture: TextureConfig = TextureConfig()

    # common drawer housing dimensions from the accepted OpenSCAD design
    housing_w: float = 96.0
    housing_d: float = 96.0
    housing_h: float = 80.0
    housing_wall: float = 3.2
    housing_back: float = 3.2
    housing_r: float = 15.0
    drawer_open_h: float = 34.8
    drawer_lower_z: float = 4.2
    drawer_shelf: float = 3.2

    # drawer
    drawer_body_w: float = 88.6
    drawer_body_d: float = 91.0
    drawer_body_h: float = 32.2
    drawer_body_r: float = 10.0
    drawer_face_w: float = 89.1
    drawer_face_h: float = 34.6
    drawer_face_t: float = 2.4
    drawer_face_plan_r: float = 1.15  # current SCAD behaves like ~half the 2.4 mm depth


# -----------------------------------------------------------------------------
# Base CAD primitives
# -----------------------------------------------------------------------------

def rounded_box_xy(w: float, d: float, h: float, r: float) -> cq.Workplane:
    """Box from (0,0,0) with rounded XY footprint and straight Z extrusion."""
    rr = max(0.0, min(r, w / 2.0 - 1e-4, d / 2.0 - 1e-4))
    obj = cq.Workplane("XY").box(w, d, h, centered=(False, False, False))
    if rr > 1e-5:
        obj = obj.edges("|Z").fillet(rr)
    return obj


def rounded_box_xz(w: float, d: float, h: float, r: float) -> cq.Workplane:
    """Box from (0,0,0) with rounded XZ front/back profile, extruded in Y."""
    rr = max(0.0, min(r, w / 2.0 - 1e-4, h / 2.0 - 1e-4))
    obj = cq.Workplane("XY").box(w, d, h, centered=(False, False, False))
    if rr > 1e-5:
        obj = obj.edges("|Y").fillet(rr)
    return obj


def top_cup(w: float, d: float, h: float, wall: float, bottom: float, r: float) -> cq.Workplane:
    outer = rounded_box_xy(w, d, h, r)
    inner = rounded_box_xy(
        w - 2 * wall,
        d - 2 * wall,
        h - bottom + 0.25,
        max(0.8, r - wall),
    ).translate((wall, wall, bottom))
    return outer.cut(inner)


def front_cup(w: float, d: float, h: float, wall: float, back: float, r: float) -> cq.Workplane:
    outer = rounded_box_xz(w, d, h, r)
    inner = rounded_box_xz(
        w - 2 * wall,
        d - back + 0.25,
        h - 2 * wall,
        max(0.8, r - wall),
    ).translate((wall, -0.25, wall))
    return outer.cut(inner)


def box_at(x: float, y: float, z: float, sx: float, sy: float, sz: float) -> cq.Workplane:
    return cq.Workplane("XY").box(sx, sy, sz, centered=(False, False, False)).translate((x, y, z))


def polygon_prism(points: Sequence[tuple[float, float]], z0: float, height: float) -> cq.Workplane:
    return cq.Workplane("XY").polyline(points).close().extrude(height).translate((0, 0, z0))


def connector_solids(w: float, d: float, h: float, fit: float,
                     rail_h: float = 56.0, rail_z: float = 12.0,
                     p: float = 4.0, base: float = 8.0, head: float = 12.0,
                     rail_t: float = 2.2) -> list[cq.Workplane]:
    y0 = d / 2.0
    zh = min(rail_h, h - rail_z - 5.0)
    if zh <= 0:
        return []
    male_poly = [
        (w, y0 - base / 2),
        (w + p, y0 - head / 2),
        (w + p, y0 + head / 2),
        (w, y0 + base / 2),
    ]
    mouth = base + 2 * fit
    inner = head + 2 * fit
    top_poly = [
        (-p - 0.15, y0 + mouth / 2),
        (0, y0 + inner / 2),
        (0, y0 + inner / 2 + rail_t),
        (-p - 0.15, y0 + mouth / 2 + rail_t),
    ]
    bot_poly = [
        (-p - 0.15, y0 - mouth / 2 - rail_t),
        (0, y0 - inner / 2 - rail_t),
        (0, y0 - inner / 2),
        (-p - 0.15, y0 - mouth / 2),
    ]
    return [
        polygon_prism(male_poly, rail_z, zh),
        polygon_prism(top_poly, rail_z, zh),
        polygon_prism(bot_poly, rail_z, zh),
    ]


def add_connectors(obj: cq.Workplane, w: float, d: float, h: float, cfg: OrganizerConfig,
                   rail_h: float = 56.0, rail_z: float = 12.0) -> cq.Workplane:
    for s in connector_solids(w, d, h, cfg.fit, rail_h=rail_h, rail_z=rail_z):
        obj = obj.union(s)
    return obj


def rib_ring(w: float, d: float, r: float, z: float, amp: float = 0.38,
             rib_h: float = 0.75) -> cq.Workplane:
    outer = rounded_box_xy(w + 2 * amp, d + 2 * amp, rib_h, r + amp).translate((-amp, -amp, z))
    inner = rounded_box_xy(w, d, rib_h + 0.2, r).translate((0, 0, z - 0.1))
    return outer.cut(inner)


# -----------------------------------------------------------------------------
# Low-memory image engraving
# -----------------------------------------------------------------------------

def _resolve_image(path: str | Path, base_dir: Path) -> Path:
    p = Path(path)
    if not p.is_absolute():
        p = (base_dir / p).resolve()
    if not p.exists():
        raise FileNotFoundError(f"Texture image not found: {p}")
    return p


def load_lowres_image(path: Path, target_resolution: int) -> np.ndarray:
    """Load image as square grayscale preprocessing raster.

    This is intentionally *not* converted into one CAD face per pixel.  The
    raster is later resampled to a physically meaningful engraving grid.
    """
    res = max(16, int(target_resolution))
    img = Image.open(path).convert("L")
    img = ImageOps.autocontrast(img)
    img.thumbnail((res, res), Image.Resampling.LANCZOS)
    canvas = Image.new("L", (res, res), 127)
    ox = (res - img.width) // 2
    oy = (res - img.height) // 2
    canvas.paste(img, (ox, oy))
    return np.asarray(canvas, dtype=np.float32) / 255.0


def scanline_profiles_for_panel(image: np.ndarray, panel_w: float, panel_h: float,
                                tex: TextureConfig) -> list[tuple[float, list[tuple[float, float]]]]:
    """Convert an image into continuous copperplate-like engraving scanlines.

    Each row becomes ONE continuous groove spanning the complete panel width.
    The groove thickness varies with local image darkness.  This preserves a
    2-D tonal pattern while avoiding one closed CAD pocket per pixel/run.
    """
    cols = max(12, min(tex.target_resolution, tex.cad_max_columns,
                       int(panel_w / tex.min_feature_mm)))
    rows = max(6, min(tex.target_resolution, tex.max_rows,
                      int(panel_h / tex.min_feature_mm)))
    if cols <= 1 or rows <= 0:
        return []

    arr8 = np.clip(image * 255, 0, 255).astype(np.uint8)
    # Mild blur/resampling suppresses sub-nozzle detail before CAD creation.
    im = Image.fromarray(arr8, mode="L").resize((cols, rows), Image.Resampling.BILINEAR)
    a = np.asarray(im, dtype=np.float32) / 255.0

    pitch = panel_h / rows
    min_t = max(0.16, pitch * 0.16)
    max_t = max(min_t + 0.05, pitch * 0.74)
    levels = 6
    # Use cell edges so every scanline spans the complete panel width.
    edges = np.linspace(0.0, panel_w, cols + 1)
    result: list[tuple[float, list[tuple[float, float]]]] = []

    for r in range(rows):
        center = (r + 0.5) * pitch
        darkness = 1.0 - a[r]
        # Quantize and run-length compress. This turns e.g. 40 raster samples
        # into only a handful of step segments for most source images.
        q = np.round(darkness * (levels - 1)) / (levels - 1)
        thickness = min_t + q * (max_t - min_t)
        profile: list[tuple[float, float]] = []
        start = 0
        while start < cols:
            end = start + 1
            while end < cols and abs(float(thickness[end]) - float(thickness[start])) < 1e-9:
                end += 1
            t = float(thickness[start])
            profile.append((float(edges[start]), t))
            profile.append((float(edges[end]), t))
            start = end
        result.append((center, profile))
    return result


def _front_scanline_tool(x0: float, y_surface: float, z0: float,
                         panel_w: float, center_v: float,
                         profile: list[tuple[float, float]], depth: float,
                         inward_positive_y: bool) -> cq.Workplane:
    eps = 0.10
    top = [(x0 + u, y_surface - eps if inward_positive_y else y_surface + eps,
            z0 + center_v + t / 2.0) for u, t in profile]
    bot = [(x0 + u, y_surface - eps if inward_positive_y else y_surface + eps,
            z0 + center_v - t / 2.0) for u, t in reversed(profile)]
    wire = cq.Wire.makePolygon([cq.Vector(*p) for p in top + bot], close=True)
    vec = cq.Vector(0, depth + 2 * eps, 0) if inward_positive_y else cq.Vector(0, -(depth + 2 * eps), 0)
    solid = cq.Solid.extrudeLinear(wire, [], vec)
    return cq.Workplane(obj=solid)


def _side_scanline_tool(x_surface: float, y0: float, z0: float,
                        panel_w: float, center_v: float,
                        profile: list[tuple[float, float]], depth: float,
                        inward_positive_x: bool) -> cq.Workplane:
    eps = 0.10
    x = x_surface - eps if inward_positive_x else x_surface + eps
    top = [(x, y0 + u, z0 + center_v + t / 2.0) for u, t in profile]
    bot = [(x, y0 + u, z0 + center_v - t / 2.0) for u, t in reversed(profile)]
    wire = cq.Wire.makePolygon([cq.Vector(*p) for p in top + bot], close=True)
    vec = cq.Vector(depth + 2 * eps, 0, 0) if inward_positive_x else cq.Vector(-(depth + 2 * eps), 0, 0)
    solid = cq.Solid.extrudeLinear(wire, [], vec)
    return cq.Workplane(obj=solid)


def engrave_front(obj: cq.Workplane, image: np.ndarray, *, x0: float, y_surface: float,
                  z0: float, panel_w: float, panel_h: float, tex: TextureConfig,
                  inward_positive_y: bool = True) -> cq.Workplane:
    for center, profile in scanline_profiles_for_panel(image, panel_w, panel_h, tex):
        tool = _front_scanline_tool(x0, y_surface, z0, panel_w, center, profile,
                                    tex.depth, inward_positive_y)
        obj = obj.cut(tool)
    return obj.clean()


def engrave_side(obj: cq.Workplane, image: np.ndarray, *, x_surface: float, y0: float,
                 z0: float, panel_w: float, panel_h: float, tex: TextureConfig,
                 inward_positive_x: bool) -> cq.Workplane:
    for center, profile in scanline_profiles_for_panel(image, panel_w, panel_h, tex):
        tool = _side_scanline_tool(x_surface, y0, z0, panel_w, center, profile,
                                   tex.depth, inward_positive_x)
        obj = obj.cut(tool)
    return obj.clean()


# -----------------------------------------------------------------------------
# Organizer model
# -----------------------------------------------------------------------------

class Organizer:
    def __init__(self, cfg: OrganizerConfig = OrganizerConfig(), base_dir: Optional[Path] = None):
        self.cfg = cfg
        self.base_dir = Path(base_dir or Path(__file__).resolve().parent)
        self._texture_image: Optional[np.ndarray] = None
        if cfg.texture.enabled:
            img_path = _resolve_image(cfg.texture.image_file, self.base_dir)
            self._texture_image = load_lowres_image(img_path, cfg.texture.target_resolution)

    @property
    def tex(self) -> TextureConfig:
        return self.cfg.texture

    def _apply_xy_module_texture(self, obj: cq.Workplane, w: float, d: float, h: float,
                                 r: float, front: bool = True, sides: bool = True) -> cq.Workplane:
        if self._texture_image is None:
            return obj
        tex = self.tex
        z0 = tex.bottom_clear
        ph = h - tex.bottom_clear - tex.top_clear
        if ph <= 1:
            return obj

        # Grooves span beyond the lateral panel edges.  That keeps every
        # scanline open to the exterior and avoids thousands of enclosed
        # micro-cavities in STL tessellation.  Top and bottom remain untouched.
        edge = 0.35
        if front:
            obj = engrave_front(obj, self._texture_image,
                               x0=-edge, y_surface=0.0, z0=z0,
                               panel_w=w + 2 * edge, panel_h=ph, tex=tex,
                               inward_positive_y=True)
        if sides:
            obj = engrave_side(obj, self._texture_image,
                              x_surface=0.0, y0=-edge, z0=z0,
                              panel_w=d + 2 * edge, panel_h=ph, tex=tex,
                              inward_positive_x=True)
            obj = engrave_side(obj, self._texture_image,
                              x_surface=w, y0=-edge, z0=z0,
                              panel_w=d + 2 * edge, panel_h=ph, tex=tex,
                              inward_positive_x=False)
        return obj

    def drawer_housing(self) -> cq.Workplane:
        c = self.cfg
        w, d, h = c.housing_w, c.housing_d, c.housing_h
        wall, back, r = c.housing_wall, c.housing_back, c.housing_r
        open_h = c.drawer_open_h
        lower_z = c.drawer_lower_z
        upper_z = lower_z + open_h + c.drawer_shelf

        outer = rounded_box_xy(w, d, h, r)
        inner_w = w - 2 * wall
        inner_d = d - back
        inner_r = max(1.0, r - wall)

        def cavity(z: float) -> cq.Workplane:
            rounded = rounded_box_xy(inner_w, inner_d, open_h, inner_r).translate((wall, 0, z))
            square_front = box_at(wall, -0.25, z, inner_w, inner_r + 0.25, open_h)
            return rounded.union(square_front)

        obj = outer.cut(cavity(lower_z)).cut(cavity(upper_z))

        # Shallow runners.  Keep them inside the wall-side clearance instead
        # of intersecting the drawer body (the legacy SCAD geometry overlapped
        # the drawer by ~0.6 mm on each side).
        runner_w = 0.85
        runner_inset_outer = 0.60
        left_x = wall - runner_inset_outer
        right_x = w - wall - runner_w + runner_inset_outer
        for z in (lower_z + 1.2, upper_z + 1.2):
            obj = obj.union(box_at(left_x, 7, z, runner_w, d - back - 10, 1.5))
            obj = obj.union(box_at(right_x, 7, z, runner_w, d - back - 10, 1.5))

        # Top docking locators for shallow tray
        key_w, key_d, key_h, key_r = 12.0, 8.0, 1.2, 1.8
        key_x1, key_x2, key_y = 18.0, w - 18.0 - key_w, (d - key_d) / 2.0
        obj = obj.union(rounded_box_xy(key_w, key_d, key_h, key_r).translate((key_x1, key_y, h)))
        obj = obj.union(rounded_box_xy(key_w, key_d, key_h, key_r).translate((key_x2, key_y, h)))

        # Texture the body first; connectors are unioned afterwards so their
        # mating geometry remains perfectly smooth and dimensionally stable.
        obj = self._apply_xy_module_texture(obj, w, d, h, r, front=False, sides=True)
        obj = add_connectors(obj, w, d, h, c)
        return obj

    def drawer(self) -> cq.Workplane:
        c = self.cfg
        body = top_cup(c.drawer_body_w, c.drawer_body_d, c.drawer_body_h,
                       2.4, 2.4, c.drawer_body_r)

        # Match the accepted SCAD design: thin front plate with rounded plan-view
        # left/right ends, extruded straight in Z.
        face_x0 = -(c.drawer_face_w - c.drawer_body_w) / 2.0
        face = rounded_box_xy(c.drawer_face_w, c.drawer_face_t, c.drawer_face_h,
                              c.drawer_face_plan_r).translate((face_x0, -c.drawer_face_t, 0))
        pull = rounded_box_xy(30.0, 5.5, 6.2, 2.4).translate(((c.drawer_body_w - 30.0) / 2.0, -4.2, 9.7))
        obj = body.union(face).union(pull)

        if self._texture_image is not None:
            tex = self.tex
            # Front face texture; preserve top/bottom border.
            z0 = tex.bottom_clear
            ph = c.drawer_face_h - tex.bottom_clear - tex.top_clear
            edge = 0.35
            if ph > 1:
                obj = engrave_front(obj, self._texture_image,
                                   x0=face_x0-edge, y_surface=-c.drawer_face_t, z0=z0,
                                   panel_w=c.drawer_face_w+2*edge, panel_h=ph, tex=tex,
                                   inward_positive_y=True)
            # Side grooves run from front to rear edge and remain open there.
            ph2 = c.drawer_body_h - tex.bottom_clear - tex.top_clear
            if ph2 > 1:
                obj = engrave_side(obj, self._texture_image,
                                  x_surface=0.0, y0=-edge, z0=tex.bottom_clear,
                                  panel_w=c.drawer_body_d+2*edge, panel_h=ph2, tex=tex,
                                  inward_positive_x=True)
                obj = engrave_side(obj, self._texture_image,
                                  x_surface=c.drawer_body_w, y0=-edge, z0=tex.bottom_clear,
                                  panel_w=c.drawer_body_d+2*edge, panel_h=ph2, tex=tex,
                                  inward_positive_x=False)
        return obj

    def cubby(self) -> cq.Workplane:
        w = d = 96.0
        h, r = 80.0, 13.0
        obj = front_cup(w, d, h, 3.2, 3.2, r)
        if self._texture_image is not None:
            tex = self.tex
            z0 = max(tex.bottom_clear, r + 1.0)
            ph = h - z0 - max(tex.top_clear, r + 1.0)
            edge = 0.35
            if ph > 2:
                obj = engrave_side(obj, self._texture_image,
                                  x_surface=0, y0=-edge, z0=z0,
                                  panel_w=d+2*edge, panel_h=ph, tex=tex,
                                  inward_positive_x=True)
                obj = engrave_side(obj, self._texture_image,
                                  x_surface=w, y0=-edge, z0=z0,
                                  panel_w=d+2*edge, panel_h=ph, tex=tex,
                                  inward_positive_x=False)
        obj = add_connectors(obj, w, d, h, self.cfg)
        return obj

    def shallow_tray(self) -> cq.Workplane:
        w = d = 96.0
        h, r = 26.0, 14.0
        obj = top_cup(w, d, h, 3.0, 3.0, r)
        obj = obj.union(box_at(46.5, 3.2, 3.0, 2.4, d - 6.4, 15.5))

        key_w, key_d, key_h, key_r, fit = 12.0, 8.0, 1.2, 1.8, 0.25
        key_x1, key_x2, key_y = 18.0, w - 18.0 - key_w, (d - key_d) / 2.0
        sock_h = key_h + 0.35
        s1 = rounded_box_xy(key_w + 2 * fit, key_d + 2 * fit, sock_h, key_r + fit).translate((key_x1 - fit, key_y - fit, -0.05))
        s2 = rounded_box_xy(key_w + 2 * fit, key_d + 2 * fit, sock_h, key_r + fit).translate((key_x2 - fit, key_y - fit, -0.05))
        obj = obj.cut(s1).cut(s2)
        obj = self._apply_xy_module_texture(obj, w, d, h, r, front=True, sides=True)
        obj = add_connectors(obj, w, d, h, self.cfg, rail_h=14, rail_z=6)
        return obj

    def divided_bin(self) -> cq.Workplane:
        w = d = 96.0
        h, r = 78.0, 15.0
        obj = top_cup(w, d, h, 3.0, 3.0, r)
        obj = obj.union(box_at(46.7, 3.0, 3.0, 2.6, d - 6.0, 57.0))
        obj = obj.union(box_at(3.0, 47.0, 3.0, 43.7, 2.6, 57.0))
        obj = obj.union(box_at(49.3, 58.0, 3.0, 43.7, 2.6, 57.0))
        if self.cfg.legacy_ribs:
            z = 10.0
            while z <= 60.0 + 1e-9:
                obj = obj.union(rib_ring(w, d, r, z))
                z += 5.5
        obj = self._apply_xy_module_texture(obj, w, d, h, r, front=True, sides=True)
        obj = add_connectors(obj, w, d, h, self.cfg)
        return obj

    def pen_cup(self) -> cq.Workplane:
        w, d, h, r = 64.0, 96.0, 110.0, 17.0
        obj = top_cup(w, d, h, 3.0, 3.0, r)
        obj = obj.union(box_at(3.0, 50.0, 3.0, w - 6.0, 2.6, 87.0))
        if self.cfg.legacy_ribs:
            z = 10.0
            while z <= 79.0 + 1e-9:
                obj = obj.union(rib_ring(w, d, r, z))
                z += 5.5
        obj = self._apply_xy_module_texture(obj, w, d, h, r, front=True, sides=True)
        obj = add_connectors(obj, w, d, h, self.cfg, rail_h=56, rail_z=12)
        return obj

    def connector_test(self) -> cq.Workplane:
        w, d, h = 24.0, 34.0, 30.0
        obj = box_at(0, 0, 0, w, d, h)
        return add_connectors(obj, w, d, h, self.cfg, rail_h=20, rail_z=5)

    def part(self, name: str) -> cq.Workplane:
        aliases = {
            "housing": "drawer_housing",
            "drawer_1": "drawer",
            "drawer_2": "drawer",
            "ablage": "cubby",
            "tray": "shallow_tray",
            "bin": "divided_bin",
            "pen_holder": "pen_cup",
        }
        name = aliases.get(name, name)
        if name == "drawer_housing": return self.drawer_housing()
        if name == "drawer": return self.drawer()
        if name == "cubby": return self.cubby()
        if name == "shallow_tray": return self.shallow_tray()
        if name == "divided_bin": return self.divided_bin()
        if name == "pen_cup": return self.pen_cup()
        if name == "connector_test": return self.connector_test()
        raise KeyError(name)


PARTS = [
    "drawer_housing",
    "drawer",
    "cubby",
    "shallow_tray",
    "divided_bin",
    "pen_cup",
    "connector_test",
]


def export_part(obj: cq.Workplane, out_dir: Path, name: str, *, stl: bool = True, step: bool = True) -> dict:
    out_dir.mkdir(parents=True, exist_ok=True)
    rec: dict = {"name": name}
    solid = obj.val()
    rec["valid_brep"] = bool(solid.isValid())
    rec["volume_mm3"] = float(solid.Volume())
    bb = solid.BoundingBox()
    rec["bbox_mm"] = [float(bb.xlen), float(bb.ylen), float(bb.zlen)]
    if stl:
        path = out_dir / f"{name}.stl"
        exporters.export(obj, str(path), tolerance=0.05, angularTolerance=0.1)
        rec["stl"] = str(path)
    if step:
        path = out_dir / f"{name}.step"
        exporters.export(obj, str(path))
        rec["step"] = str(path)
    return rec


def fit_checks(model: Organizer) -> dict:
    c = model.cfg
    # Test drawer BODY (not front fascia) against the exact housing cavity plan.
    side_clear = (c.housing_w - 2 * c.housing_wall - c.drawer_body_w) / 2.0
    back_clear = (c.housing_d - c.housing_back) - c.drawer_body_d
    z_clear = c.drawer_open_h - c.drawer_body_h

    # Boolean collision check with drawer inserted in lower opening.
    housing = model.drawer_housing()
    drawer = model.drawer().translate(((c.housing_w - c.drawer_body_w) / 2.0, 0.0, c.drawer_lower_z))
    inter = housing.intersect(drawer)
    collision_volume = float(inter.val().Volume()) if inter.val() is not None else 0.0

    return {
        "drawer_side_clearance_each_mm": side_clear,
        "drawer_back_clearance_mm": back_clear,
        "drawer_vertical_clearance_mm": z_clear,
        "drawer_vs_housing_intersection_mm3": collision_volume,
    }


def validate_stl(path: Path) -> dict:
    import trimesh
    m = trimesh.load(path, force="mesh")
    return {
        "watertight": bool(m.is_watertight),
        "faces": int(len(m.faces)),
        "components": int(len(m.split(only_watertight=False))),
        "extents_mm": [float(x) for x in m.extents],
    }


def main() -> None:
    ap = argparse.ArgumentParser(description="CadQuery modular desk organizer")
    ap.add_argument("--part", choices=PARTS + ["all"], default="all")
    ap.add_argument("--out", default="exports")
    ap.add_argument("--texture", action="store_true")
    ap.add_argument("--texture-image", default="assets/carbon_fiber_heightmap_source.png")
    ap.add_argument("--texture-resolution", type=int, default=256)
    ap.add_argument("--texture-depth", type=float, default=0.40)
    ap.add_argument("--legacy-ribs", action="store_true")
    ap.add_argument("--no-step", action="store_true")
    ap.add_argument("--no-stl", action="store_true")
    ap.add_argument("--report", default=None)
    args = ap.parse_args()

    tex = TextureConfig(
        enabled=args.texture,
        image_file=args.texture_image,
        target_resolution=args.texture_resolution,
        depth=args.texture_depth,
    )
    cfg = OrganizerConfig(texture=tex, legacy_ribs=args.legacy_ribs)
    model = Organizer(cfg)
    out = (Path(__file__).resolve().parent / args.out).resolve()

    names = PARTS if args.part == "all" else [args.part]
    report = {
        "cadquery_version": cq.__version__,
        "texture": tex.__dict__,
        "parts": {},
    }
    for name in names:
        t0 = time.perf_counter()
        obj = model.part(name)
        rec = export_part(obj, out, name, stl=not args.no_stl, step=not args.no_step)
        rec["build_seconds"] = time.perf_counter() - t0
        if not args.no_stl:
            rec["stl_validation"] = validate_stl(Path(rec["stl"]))
        report["parts"][name] = rec
        print(f"{name}: valid={rec['valid_brep']} bbox={rec['bbox_mm']} build={rec['build_seconds']:.2f}s")

    # Always run fit checks without texture because texture should not affect fit surfaces.
    fit_model = Organizer(replace(cfg, texture=replace(tex, enabled=False)))
    report["fit_checks"] = fit_checks(fit_model)

    report_path = Path(args.report) if args.report else out / "validation.json"
    report_path.parent.mkdir(parents=True, exist_ok=True)
    report_path.write_text(json.dumps(report, indent=2), encoding="utf-8")
    print(f"report: {report_path}")


if __name__ == "__main__":
    main()
