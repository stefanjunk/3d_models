from __future__ import annotations

from pathlib import Path
import json
import math

import cadquery as cq
import trimesh

from organizer import Organizer, OrganizerConfig, TextureConfig, PARTS

ROOT = Path(__file__).resolve().parent


def validate_export_folder(folder: Path) -> dict:
    report_path = folder / "validation.json"
    source = json.loads(report_path.read_text())
    out = {"parts": {}}
    for name in PARTS:
        rec = source["parts"][name]
        stl = trimesh.load(rec["stl"], force="mesh")
        step = cq.importers.importStep(rec["step"])
        step_shape = step.val()
        step_vol = float(step_shape.Volume())
        rel_volume_error = abs(step_vol - rec["volume_mm3"]) / max(abs(rec["volume_mm3"]), 1e-9)
        out["parts"][name] = {
            "brep_valid_at_export": bool(rec["valid_brep"]),
            "stl_watertight": bool(stl.is_watertight),
            "stl_components": len(stl.split(only_watertight=False)),
            "step_valid_after_reimport": bool(step_shape.isValid()),
            "step_solids_after_reimport": int(step.solids().size()),
            "step_relative_volume_error": rel_volume_error,
        }
    return out


def fit_tests() -> dict:
    model = Organizer(OrganizerConfig(texture=TextureConfig(enabled=False)))
    c = model.cfg

    housing = model.drawer_housing()
    drawer = model.drawer().translate(((c.housing_w - c.drawer_body_w) / 2.0, 0.0, c.drawer_lower_z))
    collision = housing.intersect(drawer).val().Volume()

    tray = model.shallow_tray().translate((0, 0, c.housing_h))
    tray_collision = housing.intersect(tray).val().Volume()

    return {
        "drawer_side_clearance_each_mm": (c.housing_w - 2*c.housing_wall - c.drawer_body_w) / 2.0,
        "drawer_back_clearance_mm": (c.housing_d - c.housing_back) - c.drawer_body_d,
        "drawer_vertical_clearance_mm": c.drawer_open_h - c.drawer_body_h,
        "drawer_housing_collision_mm3": float(collision),
        "tray_housing_collision_mm3": float(tray_collision),
    }


def texture_tests(untextured_folder: Path, textured_folder: Path) -> dict:
    u = json.loads((untextured_folder / "validation.json").read_text())
    t = json.loads((textured_folder / "validation.json").read_text())
    out = {}
    for name in PARTS:
        ur = u["parts"][name]
        tr = t["parts"][name]
        out[name] = {
            "bbox_unchanged": all(abs(a-b) < 1e-7 for a,b in zip(ur["bbox_mm"], tr["bbox_mm"])),
            "volume_change_mm3": tr["volume_mm3"] - ur["volume_mm3"],
            "textured_brep_valid": bool(tr["valid_brep"]),
            "textured_stl_watertight": bool(tr["stl_validation"]["watertight"]),
            "textured_stl_components": int(tr["stl_validation"]["components"]),
        }
    return out


def main() -> None:
    udir = ROOT / "exports_untextured"
    tdir = ROOT / "exports_textured_all"
    report = {
        "untextured_exports": validate_export_folder(udir),
        "textured_exports": validate_export_folder(tdir),
        "fit": fit_tests(),
        "texture": texture_tests(udir, tdir),
    }

    failures = []
    for group in ("untextured_exports", "textured_exports"):
        for name, rec in report[group]["parts"].items():
            if not rec["brep_valid_at_export"]: failures.append(f"{group}/{name}: invalid BRep")
            if not rec["stl_watertight"]: failures.append(f"{group}/{name}: STL not watertight")
            if rec["stl_components"] != 1: failures.append(f"{group}/{name}: STL components != 1")
            if not rec["step_valid_after_reimport"]: failures.append(f"{group}/{name}: STEP invalid after reimport")
            if rec["step_solids_after_reimport"] != 1: failures.append(f"{group}/{name}: STEP solids != 1")
            if rec["step_relative_volume_error"] > 1e-9: failures.append(f"{group}/{name}: STEP volume drift")

    if abs(report["fit"]["drawer_housing_collision_mm3"]) > 1e-6:
        failures.append("drawer/housing collision")
    if abs(report["fit"]["tray_housing_collision_mm3"]) > 1e-6:
        failures.append("tray/housing collision")

    for name, rec in report["texture"].items():
        if not rec["bbox_unchanged"]: failures.append(f"{name}: texture changed bounding box")
        if not rec["textured_brep_valid"]: failures.append(f"{name}: textured BRep invalid")
        if not rec["textured_stl_watertight"]: failures.append(f"{name}: textured STL not watertight")
        if rec["textured_stl_components"] != 1: failures.append(f"{name}: textured STL components != 1")

    report["passed"] = not failures
    report["failures"] = failures
    out = ROOT / "TEST_REPORT.json"
    out.write_text(json.dumps(report, indent=2))
    print(json.dumps({"passed": report["passed"], "failures": failures, "fit": report["fit"]}, indent=2))
    if failures:
        raise SystemExit(1)


if __name__ == "__main__":
    main()
