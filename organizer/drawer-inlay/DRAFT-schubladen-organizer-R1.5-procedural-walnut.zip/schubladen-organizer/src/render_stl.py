#!/usr/bin/env python3
"""Render the actual exported binary STL triangles with a small orthographic rasterizer."""

from __future__ import annotations

import argparse
import json
from pathlib import Path

import numpy as np
from PIL import Image, ImageDraw

from validate_stl import load_binary_stl


def normalized(vector: np.ndarray) -> np.ndarray:
    length = float(np.linalg.norm(vector))
    return vector / max(length, 1.0e-12)


def main() -> None:
    parser = argparse.ArgumentParser()
    parser.add_argument("output", type=Path)
    parser.add_argument("--width", type=int, default=1600)
    parser.add_argument("--height", type=int, default=1100)
    parser.add_argument("--view", choices=("overall", "hardware", "hardware-front", "coupon"), default="overall")
    args = parser.parse_args()

    root = Path(__file__).resolve().parent.parent
    params = json.loads((root / "config" / "model-params.json").read_text(encoding="utf-8"))
    zone = float(params["layout"]["screwdriver_zone_width"])
    split = float(params["layout"]["depth_split"])
    floor = float(params["organizer"]["floor_thickness"])
    files = [
        ("DRAFT-driver-front-textured.stl", np.array([0.0, 0.0, 0.0]), np.array([104, 67, 43])),
        ("DRAFT-driver-back-textured.stl", np.array([0.0, split, 0.0]), np.array([110, 72, 46])),
        ("DRAFT-hardware-front-textured.stl", np.array([zone, 0.0, 0.0]), np.array([116, 77, 49])),
        ("DRAFT-hardware-back-textured.stl", np.array([zone, split, 0.0]), np.array([122, 82, 52])),
        ("DRAFT-screwdriver-comb.stl", np.array([4.0, split - 5.0, floor]), np.array([133, 91, 59])),
    ]
    if args.view == "coupon":
        files = [("DRAFT-walnut-texture-coupon.stl", np.array([0.0, 0.0, 0.0]), np.array([121, 80, 50]))]
        center = np.array([45.0, 25.0, 15.0])
        camera = center + np.array([110.0, -145.0, 170.0])
    elif args.view == "hardware-front":
        files = files[2:3]
        center = np.array([zone + 67.5, 93.25, 30.0])
        camera = center + np.array([220.0, -270.0, 480.0])
    elif args.view == "hardware":
        files = files[2:4]
        center = np.array([(zone + params["organizer"]["width_x"]) / 2, split, 30.0])
        camera = center + np.array([300.0, -390.0, 250.0])
    else:
        center = np.array([params["organizer"]["width_x"] / 2, params["organizer"]["depth_y"] / 2, 32.0])
        camera = center + np.array([340.0, -420.0, 650.0])
    forward = normalized(center - camera)
    right = normalized(np.cross(forward, np.array([0.0, 0.0, 1.0])))
    up = normalized(np.cross(right, forward))
    light = normalized(np.array([-0.35, -0.45, 1.0]))

    visible: list[tuple[float, np.ndarray, tuple[int, int, int]]] = []
    all_projected = []
    for filename, translation, color in files:
        triangles = load_binary_stl(root / "output" / "DRAFT" / filename) + translation
        edges_a = triangles[:, 1] - triangles[:, 0]
        edges_b = triangles[:, 2] - triangles[:, 0]
        normals = np.cross(edges_a, edges_b)
        lengths = np.linalg.norm(normals, axis=1)
        good = lengths > 1.0e-12
        normals[good] /= lengths[good, None]
        relative = triangles - center
        projected = np.stack(
            [relative @ right, relative @ up, relative @ forward], axis=-1
        )
        all_projected.append(projected[:, :, :2].reshape(-1, 2))
        face_centers = triangles.mean(axis=1)
        view_vectors = normalized(camera - face_centers.mean(axis=0))
        facing = (normals @ forward) < 0.0
        for index in np.nonzero(facing & good)[0]:
            shade = 0.34 + 0.66 * max(0.0, float(np.dot(normals[index], light)))
            face_color = tuple(int(np.clip(channel * shade + 18, 0, 255)) for channel in color)
            depth = float(projected[index, :, 2].mean())
            visible.append((depth, projected[index, :, :2], face_color))

    projected_all = np.concatenate(all_projected, axis=0)
    minimum = projected_all.min(axis=0)
    maximum = projected_all.max(axis=0)
    margin = 70
    scale = min(
        (args.width - 2 * margin) / max(maximum[0] - minimum[0], 1.0),
        (args.height - 2 * margin) / max(maximum[1] - minimum[1], 1.0),
    )

    image = Image.new("RGB", (args.width, args.height), (238, 240, 242))
    draw = ImageDraw.Draw(image)
    visible.sort(key=lambda item: item[0], reverse=True)
    for _, points, color in visible:
        pixel_points = []
        for u, v in points:
            x = margin + (u - minimum[0]) * scale
            y = args.height - margin - (v - minimum[1]) * scale
            pixel_points.append((float(x), float(y)))
        draw.polygon(pixel_points, fill=color)

    args.output.parent.mkdir(parents=True, exist_ok=True)
    image.save(args.output)
    print(f"rendered {len(visible)} visible triangles to {args.output}")


if __name__ == "__main__":
    main()
