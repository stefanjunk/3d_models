# Schubladen-Organizer R1 – DRAFT-Produktionskandidat

Parametrische, vierteilige FDM-Einlage für eine Schublade mit 360 × 230 × 80 mm Innenmaß. Der aktuelle Kandidat nutzt 227 × 357 × 64 mm, lässt damit nominell 1,5 mm Spiel an jeder XY-Seite und 16 mm Höhenreserve.

> **Freigabestatus:** Anforderungen und Konzept R1 sind freigegeben. Die aktualisierte Geometrie und alle neun STL-Netze sind digital geprüft. Die Dateien bleiben `DRAFT`, bis die R1-Release-Freigabe und idealerweise die Slicer-/Couponprüfungen bestätigt wurden.

![Render der tatsächlich exportierten R1-STL-Geometrie](reports/DRAFT-R1-model-preview.png)

![R1-Nahansicht der U-Griffnuten und vollhohen Wandknoten](reports/DRAFT-R1-feature-closeup.png)

## Aufbau

- Vier steckbare Hauptmodule, jeweils kleiner als 135 × 186,5 mm Druckfläche.
- Linke 92-mm-Zone für lange Schraubendreher; separater Kamm mit acht Schaftplätzen.
- Rechte 135-mm-Zone mit acht Hardwarefächern (2 Spalten × 4 Reihen) und jeweils einer 22 × 8-mm-U-Griffnut mit 4-mm-Bodenradius.
- 2,6-mm-Boden und 3,2-mm-Basiswandstärke; Außen- und Trennwandstärke besitzen getrennte optionale Overrides.
- Vollhohe, glatte Wandknoten: 4,0-mm-T-Blenden und 5,5-mm-Kreuzungshubs von der Bodenoberseite bis zur 55-mm-Wandoberkante.
- Supportfreie, flache Druckorientierung; ebene Puzzleverbinder mit 0,30 mm Nennspiel.
- Innenböden sowie sichtbare Innen-/Außenwandbänder tragen die unregelmäßige 180-mm-R1-Stahlplatten-/Nietenstruktur mit Patchstellen und nahtloser Kachelung.

## Schnellstart zum Drucken

1. Zuerst `DRAFT-drawer-fit-corner-coupon.stl`, beide Connector-Coupons und `DRAFT-relief-depth-coupon.stl` drucken.
2. Passung in der realen Schublade sowie Steckspiel und Reliefwirkung beurteilen.
3. `output/DRAFT/DRAFT-R1-organizer-textured-assembly.3mf` im Slicer öffnen oder die vier texturierten Modul-STLs einzeln laden.
4. Die vier Module flach mit der geschlossenen Unterseite auf dem Druckbett, ohne Supports, drucken.
5. Den Schraubendreherkamm separat drucken und anschließend in die lange Werkzeugzone setzen.

Das empfohlene PETG-Ausgangsprofil steht in `print-profile.md`. Temperaturen und Fluss müssen dem verwendeten Filamentprofil folgen.

## Parametrik

Die maßgebenden Abmessungen liegen in `config/model-params.json`:

- Schubladenmaß und umlaufendes Spiel
- Gesamtmaß, Boden-/Wandstärken und Höhen
- Breite der Schraubendreherzone sowie 2×4-Hardware-Raster
- Breite, Tiefe und Rundungsradius der U-Griffnuten
- Basiswandstärke, optionale Außen-/Trennwand-Overrides und beide Wandknotenradien
- Kammabmessungen, Anzahl und Radius der Schlitze
- Verbindergeometrie und Spiel
- Relief-Tiefen und Flächenmasken

Nach einer Änderung:

```bash
npm install
npm run build
npm run validate
```

`npm run build` erzeugt die DRAFT-STL- und 3MF-Dateien reproduzierbar. `npm run validate` prüft jede STL unabhängig auf geschlossene Kanten, Manifold-Geometrie, konsistente Orientierung, positives Volumen, Einzelkörper, Nullflächen und Duplikate.

## Oberflächenbild austauschen

Die Quelle ist vollständig von der Grundgeometrie getrennt:

1. Ein neues nahtloses Graustufen-Höhenbild bereitstellen. Dunkel bedeutet Vertiefung, hell Erhöhung, Mittelgrau neutral. Das R1-Masterbild liegt separat als `texture/steel-rivets-source-R1.png` vor.
2. In `config/relief-config.json` den Eintrag `prepared_heightmap` auf dieses Bild setzen oder `texture/steel-rivets-height-16.png` ersetzen.
3. Optional Kachelmaß, Geometrieraster und Schwellenwerte in derselben Datei anpassen.
4. Manifest und Vorschau neu erzeugen:

```bash
python3 src/vectorize_heightmap.py \
  config/relief-config.json \
  texture/steel-rivets-relief-manifest.json \
  --preview texture/steel-rivets-vector-preview.png
npm run build
npm run validate
```

In `config/model-params.json` lassen sich Boden-, Innenwand- und Außenwandrelief separat aktivieren. Die Tiefen sind unabhängig parametrierbar. Nach einem Oberflächenwechsel sind Reliefcoupon und Netzprüfung erneut erforderlich.

Die aktuelle Fertigungs-Heightmap ist 180 × 180 mm groß, in beiden Achsen nahtkorrigiert und wird mit 1,5-mm-Geometriepitch vektorisiert. Bodenrelief reicht bis 0,50 mm nach innen und 0,55 mm nach außen. Auf Außenwänden liegt das Muster in einem 0,35-mm-Rezess, sodass keine Niete das Einbaumaß vergrößert.

## Dateien

- `src/manifold_model.mjs` – parametrische Produktionsgeometrie
- `src/manifold_build.mjs` – STL-Export und Buildbericht
- `src/package_3mf.py` – standardkonforme 3MF-Baugruppenverpackung der validierten STL-Netze
- `src/vectorize_heightmap.py` – Höhenbild zu robusten Relief-Rasterläufen
- `src/validate_stl.py` – unabhängige STL-Netzprüfung
- `config/model-params.json` – geometrische Parameter
- `config/relief-config.json` – austauschbare Oberflächenparameter
- `reports/validation-report.md` – konsolidierter Prüfnachweis
- `reports/watermark-evidence.md` – Kennzeichnungsnachweis

Ein STEP-Export ist nicht enthalten, weil in der Ausführungsumgebung kein STEP-fähiges parametrisches CAD-Backend verfügbar war. Die JavaScript-/Manifold3D-Quelle ist der vollständig parametrierbare Master.
