# Decision Log – Schubladen-Organizer

## 2026-08-11 – Anforderungen R0 freigegeben

- Nutzerfreigabe: „R0 freigeben“.
- Angenommene Standardwerte: Druckbett 220 × 220 mm, 0,4-mm-Düse, PETG.
- Schraubendreherzone: universelles 92 × 350-mm-Fach mit austauschbarem Kamm.
- Modularchitektur: vier Teile in einer 2×2-Teilung.
- Hardwarezone: exakt acht Fächer in zwei Spalten und vier Reihen.

## 2026-08-11 – Konzeptbild R0

- Erzeugungsmodus: integrierte Bildgenerierung, anschließend gezielte Bildkorrektur.
- Ergebnis: `concept-R0-v2.png`.
- Status: vom Nutzer mit „Konzept R0 freigegeben“ freigegeben.
- Darstellungsgrenze: Die Explosionsansicht zeigt acht Hardwarefächer eindeutig. In der perspektivischen Hauptansicht ist die vorderste Quertrennung optisch gedrängt. Für die Produktionsgeometrie gilt ausschließlich `design-spec.yaml`.

### Finaler Korrekturprompt

> Add the same shallow, FDM-printable industrial steel-plate relief language already visible on the compartment floors to the visible vertical wall bands: subtle rectangular plate seams and sparse small domed rivets on the inner wall faces and on the visible outer wall panels of both the assembled organizer and the exploded modules. Change only the surface relief on visible wall bands. Preserve exactly the composition, camera, four-module 2-by-2 architecture, one long screwdriver zone, removable comb, the eight-compartment hardware intent shown by the exploded modules, all compartment walls, finger scoops, connectors, gussets, proportions, graphite PETG material, floor relief, lighting, and background. Relief must remain shallow and printable. No text, labels, arrows, dimensions, logos, watermark, damage, rust, extra compartments, or geometry redesign.

## 2026-08-11 – Produktionskandidat R0 DRAFT

- Parametrische Grundgeometrie mit `manifold-3d` umgesetzt, weil in der lokalen Umgebung weder CadQuery/FreeCAD noch OpenSCAD oder Blender verfügbar waren.
- Baugruppe: 227 × 357 × 64 mm; vier einzeln auf 220 × 220 mm druckbare Module.
- Layout: 92-mm-Schraubendreherzone mit separatem Achtfach-Kamm; Hardwarezone 135 mm breit mit exakt 2 × 4 Fächern.
- Stabilität: 2,4-mm-Boden und -Trennwände, 2,8-mm-Außenwände, durchgehende Materialkreuzungen und Wurzelgussets.
- Verbinder: flache Puzzlelaschen mit 0,30 mm Nennspiel; separate Paarprobe erzeugt.
- Alle neun STL-Dateien bestehen die unabhängige Watertight-/Manifold-/Volumen-/Einzelkörperprüfung.

## 2026-08-11 – Austauschbares Höhenbildrelief

- Masterbild: `texture/steel-rivets-source.png`, eigens als nahtlose Graustufen-Displacement-Textur erzeugt.
- Fertigungskonvention: dunkle Plattenstöße werden 0,35 mm vertieft, helle Nieten 0,40 mm erhaben.
- Für robuste, speicherschonende Boolesche Operationen wird das 16-bit-Höhenbild über `src/vectorize_heightmap.py` in 1,5-mm-Rasterläufe umgewandelt.
- Das Relief kann über `config/relief-config.json` sowie `config/model-params.json` ausgetauscht, skaliert oder je Flächengruppe deaktiviert werden.
- Mindest-Reststärke an reliefierten Böden/Wänden: rechnerisch mindestens 2,0 mm.

## 2026-08-11 – Kennzeichnung und Freigabestatus

- Exakte kompakte JuSt-Innovation-DXF-Geometrie `JSI-WM-001-R1` als letzte Produktionsgeometrieänderung auf den vier druckbettseitigen Modulunterseiten vertieft.
- Kennzeichnungsmaß: 15,991 × 14,000 mm bei Skalierung 1,4; Tiefe 0,40 mm; Restboden 2,00 mm.
- Direkte Unterseitenansicht, Nahansicht, Querschnitt und geometrische Schichtsimulation dokumentiert.
- Die finale Freigabe bleibt blockiert, bis eine echte Slicer-Vorschau und vorzugsweise die Passungs-/Reliefcouponprüfung vorliegen. Alle Exporte bleiben deshalb als `DRAFT` benannt.

## 2026-08-11 – 3MF-Interoperabilität

- Die zuerst verwendete JSCAD-Verpackungsstufe ließ den 3MF-Core-XML-Namensraum weg.
- Die STL-Dreiecke waren davon nicht betroffen; nur der Container wurde ersetzt.
- `src/package_3mf.py` paketiert jetzt die validierten STL-Netze reproduzierbar mit Core-Namensraum, vier benannten Objekten, vier Build-Items und geprüfter Baugruppenhülle 227 × 357 × 64 mm.

## 2026-08-11 – Änderungsanforderung R1

- Nutzerwunsch 1: Die schmalen rechteckigen Ausschnitte der R0-DRAFT-Geometrie werden durch breitere, leicht gerundete Griffnuten entsprechend der Wirkung des Konzeptbilds ersetzt.
- Empfohlener Startwert: 22 mm Breite, 8 mm Tiefe, 4 mm unterer Rundungsradius; alle Werte extern parametrierbar.
- Nutzerwunsch 2: T- und Kreuzungsknoten der Trennwände werden nicht nur am Boden verstärkt, sondern über die volle Wandhöhe optisch und funktional verrundet.
- Empfohlener Startwert: 4,0 mm vertikaler Blendenradius und 5,5 mm Kreuzungshub; Wandstärke als 3,2-mm-Basisparameter mit getrennten Overrides für Außen- und Trennwände.
- Nutzerwunsch 3: Die Gravur wird deutlicher und das Heightmap-Motiv unregelmäßiger. Vorgesehen sind verschieden große und versetzte Platten, ungleichmäßige Nietnähte mit Lücken, einzelne Patchplatten und dezente Gebrauchsspuren statt eines schachbrettartigen Rasters.
- Empfohlene R1-Relieftiefen: bis 0,50 mm vertieft und 0,55 mm erhaben; 2,6-mm-Boden und 3,2-mm-Wände halten mindestens 2,0 mm Restmaterial.
- Gate-Status: R0-Konzept- und Kennzeichnungsfreigaben sind für R1 ungültig. Vor Texturbild und CAD ist die ausdrückliche R1-Anforderungsfreigabe erforderlich.

## 2026-08-11 – Anforderungen R1 freigegeben

- Nutzerfreigabe: „Anforderungen R1 freigeben.“
- Freigegebene Geometrieparameter: 22 × 8 mm breite U-Griffnuten mit 4-mm-Rundung, 4,0-mm-Vollhöhenblenden an Wandknoten, 5,5-mm-Kreuzungshub sowie 3,2-mm-Basiswandstärke mit getrennten Overrides.
- Freigegebene Reliefparameter: bis 0,50 mm vertieft und 0,55 mm erhaben, 180 × 180 mm physisches Mastermotiv, mindestens 0,9 mm druckbare Merkmalsbreite und mindestens 2,0 mm Restmaterial.
- Freigegebene Bildsprache: unterschiedlich große und versetzte Stahlplatten, unregelmäßige Nietnähte mit Lücken, vereinzelte Patchplatten und dezente Gebrauchsspuren ohne Rost oder scharfe Schäden.
- Gate-Status: Anforderungen R1 `approved`; Konzept R1 `pending`. Produktions-CAD und Fertigungsexporte bleiben bis zur Konzeptfreigabe gesperrt.

## 2026-08-11 – Konzept und Textur R1 erstellt

- Bildmodus: integrierte Bildgenerierung; das R0-Konzept diente als Geometrie-/Kompositionsreferenz, das neue R1-Masterbild als Reliefreferenz.
- Konzeptasset: `concept-R1.png` (1536 × 1024 px, SHA-256 `73c6226136488a0464909b1ef45f52e3f58eb859d0ac244be0f16364104064e5`).
- Texturasset: `texture/steel-rivets-source-R1.png` (1254 × 1254 px, SHA-256 `80bbcafabca8a649d09e9887da43daabcda4d39af9e1b260e2d1a36c0b1816ac`).
- Sichtprüfung: vier Module, acht Kleinteilfächer, eine lange Schraubendreherzone und ein separater Kamm bleiben erhalten. Breite U-Griffnuten, vollhohe gerundete Wandknoten und ein unregelmäßigeres Patch-/Nietrelief sind deutlich sichtbar.
- Heightmap-Quellenanalyse bei 180 × 180 mm: 0,1435 mm/px Quellabtastung, 2,75 Z-Schritte bei 0,55 mm und 0,20-mm-Schichten, keine subnominellen verbundenen Komponenten. Die Top-/Bottom-Kante ist unauffällig; die Left-/Right-Kante ist mit Verhältnis 1,64 noch stärker als lokale Nachbarvariation und wird deshalb erst nach Konzeptfreigabe in der Produktionsvorbereitung nahtkorrigiert.
- Konzeptdarstellung ist keine Maß- oder Druckbarkeitsprüfung. Verbindlich bleiben die Werte in `design-spec.yaml`.

### Finaler Prompt – R1-Texturmaster

> Use case: stylized-concept. Asset type: square grayscale displacement / height-map master for an FDM-printable industrial drawer-organizer surface. Create an organic, realistic-looking repaired steel plate and rivet relief pattern that does not resemble a checkerboard: differently sized staggered plates, a few overlapping repair patches, irregular rivet seams with varied spacing, occasional gaps and double rivets. Perfectly flat orthographic square, seamless intent, no frame. Medium gray plate fields, darker recessed seams and shallow dents, brighter rounded rivets and subtly raised patch edges. Broad printable features for a 0.4-mm nozzle at 180 × 180 mm. Black/dark means recessed, 50% gray neutral, white/bright raised. No lighting gradient, cast shadows, specular highlights, perspective, color, rust, holes, sharp damage, text, symbols, logos, screws, bolts, tread, checkerboard, evenly spaced rows or fine photographic noise.

### Finaler Prompt – R1-Konzeptblatt

> Use case: precise-object-edit. Image 1 defines the unchanged organizer architecture, camera and composition; Image 2 supplies only the irregular plate/rivet relief language. Update Image 1 for R1: use broad shallow U-shaped 22-mm access grooves with rounded 4-mm bottoms and soft transitions on the visible wall of every one of the eight small-parts compartments; add smooth tangential vertical blend columns at every T- and four-way wall junction from floor to wall top with fuller rounded crossing hubs; replace the regular plate/rivet treatment with varied staggered plates, patch plates and irregular rivet runs, visibly stronger yet shallow and FDM-printable on floors and visible wall bands. Preserve exactly four modules, exactly eight compartments in a 2 × 4 arrangement, one uninterrupted long screwdriver zone, one removable comb, proportions, wall heights, rounded outer corners, connectors, layout, camera, lighting and white background. No text, dimensions, labels, arrows, logos, watermark, rust, holes, tears, sharp damage, extra compartments, missing walls, accessories, exaggerated rivets, deep carvings or unsupported overhangs.

## 2026-08-11 – Konzept R1 freigegeben

- Nutzerfreigabe: „Konzept R1 freigeben“.
- Freigabebasis: `concept-R1.png`, `texture/steel-rivets-source-R1.png` und die Werte in `design-spec.yaml` Revision R1.
- Produktionsumfang: 22 × 8-mm-U-Griffnuten mit 4-mm-Bodenradius, vollhohe parametrierbare T-/Kreuzungsblenden, 3,2-mm-Basiswandstärke sowie die nahtkorrigierte 180 × 180-mm-R1-Heightmap.
- Gate-Status: Anforderungen R1 und Konzept R1 `approved`; R1-Produktionsgeometrie und digitale Regression dürfen beginnen. Die finale Freigabe bleibt bis zur geprüften DRAFT-Fassung und erneuten Kennzeichnungsstufe gesperrt.

## 2026-08-11 – Produktionskandidat R1 DRAFT

- Parametrierung umgesetzt: 2,6-mm-Boden, 3,2-mm-Basiswandstärke mit getrennten Außen-/Trennwand-Overrides, 22 × 8-mm-U-Griffnuten mit 4-mm-Bodenradius.
- Wandknoten umgesetzt: drei 5,5-mm-Kreuzungshubs und sechs 4,0-mm-T-Blenden, durchgehend von z = 2,6 bis 55,0 mm. Die glatten Knoten werden nach der Reliefstufe erneut vereinigt.
- Relief umgesetzt: R1-Master auf 180 × 180 mm abgebildet, 16 Bit, 0,30-mm-Bildpitch, 7-mm-Nahtüberblendung und 1,5-mm-Geometriepitch. Fertigungsmanifest: 703 Gravur- und 47 Erhöhungszellen in 377 Läufen.
- Tiefen umgesetzt: 0,50 mm Gravur und 0,55 mm Erhöhung auf Böden/Innenflächen; Außenflächen bleiben durch ein 0,35-mm-Rezessfeld innerhalb der Einbauhülle.
- Materialreserven: mindestens 2,10 mm am gravierten Boden und 2,20 mm an beidseitig reliefierten Wänden beziehungsweise unter der 0,40-mm-Unterseitenmarke.
- Digitale Regression: 9/9 STL-Dateien geschlossen, manifold, einteilig und volumenhaltig; Baugruppe 227 × 357 × 64 mm; R1-3MF enthält vier Objekte und vier Build-Items.
- Kennzeichnung: `JSI-WM-001-R1` compact, Skalierung 1,4, auf allen vier Hauptmodulen als letzte Geometrieänderung integriert. Eine echte Slicer-Vorschau fehlt weiterhin; deshalb bleiben Dateien und Freigabestatus `DRAFT`.
