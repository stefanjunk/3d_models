# Digitaler Validierungsbericht – R1 DRAFT

Datum: 2026-08-11  
Status: **digital PASS, physisch und druckerspezifisch noch nicht qualifiziert**

## Ergebnis

Der R1-Produktionskandidat setzt die freigegebenen U-Griffnuten, vollhohen Wandknoten, parametrierbaren Wandstärken und die neue unregelmäßige Heightmap um. Alle neun exportierten STL-Dateien sind geschlossene, orientierte Einzelkörper mit positivem Volumen. Die Baugruppe bleibt bei 227 × 357 × 64 mm. Es wurde kein echter Slicer ausgeführt.

## Baugruppe und Einbauraum

| Merkmal | Ergebnis | Kriterium | Status |
|---|---:|---:|---|
| Breite X | 227,0 mm | ≤ 227,0 mm | PASS |
| Tiefe Y | 357,0 mm | ≤ 357,0 mm | PASS |
| Höhe Z | 64,0 mm | ≤ 76,0 mm | PASS |
| Nennspiel pro XY-Seite | 1,5 mm | 1,5 mm | PASS rechnerisch |
| Höhenreserve | 16,0 mm | ≥ 4,0 mm | PASS rechnerisch |
| größter Druck-Footprint | 135,0 × 186,5 mm | ≤ 220 × 220 mm | PASS |
| Hardwarefächer | 8 (2 × 4) | exakt 8 | PASS |
| U-Griffnuten | 8; 22 × 8 mm, Radius 4 mm | exakt 8 | PASS parametrisch/visuell |
| Wandknoten | 3 Kreuzungshubs + 6 T-Blenden | vollhoch und glatt | PASS parametrisch/visuell |

Das Außenmaß bezieht sich auf die zusammengesetzte Baugruppe. Männliche Verbinder ragen nur in die korrespondierenden Aussparungen der Nachbarmodule.

## Netzprüfung

Prüfer: `src/validate_stl.py`, Schweiß-Toleranz 0,0001 mm.

| Datei | Größe mm | Dreiecke | Ergebnis |
|---|---:|---:|---|
| driver-front | 100 × 186,5 × 64 | 11.828 | PASS |
| driver-back | 100 × 178,5 × 64 | 11.732 | PASS |
| hardware-front | 135 × 186,5 × 64 | 18.182 | PASS |
| hardware-back | 135 × 178,5 × 64 | 15.590 | PASS |
| Schraubendreherkamm | 84 × 10 × 20 | 612 | PASS |
| Eckcoupon | 40 × 40 × 12 | 100 | PASS |
| Reliefcoupon | 90 × 32 × 3,2 | 1.164 | PASS |
| Connector männlich | 28 × 20 × 2,6 | 156 | PASS |
| Connector weiblich | 20 × 20 × 2,6 | 144 | PASS |

Für jede Datei: 0 Randkanten, 0 nicht-manifold Kanten, 0 inkonsistent orientierte Kanten, 0 Nullflächendreiecke, 0 doppelte Flächen, genau 1 zusammenhängender Körper und positives Volumen. Maschinell lesbare Details: `mesh-validation.json`.

## R1-Geometrie und Materialreserven

- Boden 2,6 mm; Basis-, Außen- und Trennwandstärke 3,2 mm. Außen- und Trennwandstärke können den Basiswert getrennt überschreiben.
- U-Griffnuten: 22 mm breit, 8 mm tief, 4 mm Bodenradius; als in Wandrichtung extrudiertes, abgerundetes Profil statt Kreisbohrung.
- Wandknoten: 4,0-mm-T-Blenden und 5,5-mm-Kreuzungshubs, sichtbar von z = 2,6 bis z = 55 mm. Die glatten Knoten werden nach dem Relief erneut vereinigt.
- Bodenrelief: maximal 0,50 mm vertieft und 0,55 mm erhaben; Restboden ohne Unterseitenmarke mindestens 2,10 mm.
- Beidseitige Trennwandgravur: rechnerische Mindestreststärke 2,20 mm.
- Außenwand: 0,35-mm-Rezess + 0,15-mm-Außengravur + 0,50-mm-Innengravur; rechnerische Mindestreststärke 2,20 mm.
- Unterseitenmarke: 0,40 mm tief; Oberseitenrelief wird mit 1,5 mm Rand lokal ausgespart; verbleibender Boden mindestens 2,20 mm.
- Außenrelief bleibt innerhalb der 227 × 357-mm-Hülle.

## Reliefpipeline

Das freigegebene R1-Masterbild wird auf eine physische 180 × 180-mm-Kachel abgebildet. Die 16-Bit-Heightmap hat 601 × 601 Pixel beziehungsweise rund 0,30 mm/Pixel. Eine 7-mm-Randüberblendung macht beide Achsen periodisch; der Analysebericht misst für beide Kachelnähte ein Verhältnis von 0,0 zur lokalen Nachbarvariation.

Die Fertigungsvektorisierung arbeitet mit 1,5-mm-Pitch und enthält 703 Gravur- sowie 47 Erhöhungszellen in 377 Rasterläufen. Die größere Kachel, unterschiedlich große Platten und unregelmäßige Niet-/Patchstellen vermeiden die frühere Schachbrettwirkung. Details: `heightmap-prepare.json`, `heightmap-analysis.json` und `steel-rivets-relief-manifest.json`.

## 3MF und Volumen

Die R1-3MF-Datei enthält vier benannte Modellobjekte und vier Build-Items im 3MF-Core-Namensraum. Ihre Hülle entspricht 227 × 357 × 64 mm.

Vier Hauptmodule plus Schraubendreherkamm besitzen 622.418,69 mm³ beziehungsweise 622,42 cm³ geometrisches Festkörpervolumen. Bei 1,27 g/cm³ entspricht das rund 790 g PETG bei vollständig massiv interpretiertem Modellvolumen. Maßgeblich bleibt die Slicer-Schätzung.

## Noch offene Nachweise

- echte Slicer-Vorschau der ersten Schichten, Wandfüllung, U-Nuten, Reliefbahnen und Unterseitenkennzeichnung
- physische Schubladenpassung mit Eckcoupon
- reale Steckpassung des Connector-Coupons
- Reliefschärfe und Reinigbarkeit am Zielmaterial
- optionaler Hardware-Modul-Probedruck zur Prüfung von Wandknoten und Verzug

Ohne diese Nachweise ist keine `FINAL`-Freigabe erklärt; alle Druckdateien bleiben absichtlich mit `DRAFT` gekennzeichnet.
