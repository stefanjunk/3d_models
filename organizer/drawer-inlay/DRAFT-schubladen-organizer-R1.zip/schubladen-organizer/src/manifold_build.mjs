#!/usr/bin/env node

import fs from 'node:fs'
import path from 'node:path'
import { fileURLToPath } from 'node:url'

import {
  assemblyEnvelope,
  buildCombManifold,
  buildConnectorCouponManifold,
  buildFitCouponManifold,
  buildModulesManifold,
  buildReliefCouponManifold,
  resolveModelParameters
} from './manifold_model.mjs'
import { watermarkOutline } from './watermark.mjs'

const root = path.resolve(path.dirname(fileURLToPath(import.meta.url)), '..')

function parseArgs () {
  const args = process.argv.slice(2)
  const index = args.indexOf('--quality')
  return { quality: index >= 0 ? args[index + 1] : 'final' }
}

function readJson (file) {
  return JSON.parse(fs.readFileSync(file, 'utf8'))
}

function meshVertices (mesh) {
  const vertices = []
  for (let index = 0; index < mesh.numVert; index += 1) {
    const offset = index * mesh.numProp
    vertices.push([
      mesh.vertProperties[offset],
      mesh.vertProperties[offset + 1],
      mesh.vertProperties[offset + 2]
    ])
  }
  return vertices
}

function writeBinaryStl (file, manifold, headerText) {
  const mesh = manifold.getMesh()
  mesh.merge()
  const vertices = meshVertices(mesh)
  const triangleCount = mesh.numTri
  const buffer = Buffer.alloc(84 + triangleCount * 50)
  buffer.fill(0, 0, 80)
  buffer.write(headerText.slice(0, 80), 0, 'ascii')
  buffer.writeUInt32LE(triangleCount, 80)
  for (let triangle = 0; triangle < triangleCount; triangle += 1) {
    const ids = [mesh.triVerts[triangle * 3], mesh.triVerts[triangle * 3 + 1], mesh.triVerts[triangle * 3 + 2]]
    const points = ids.map(id => vertices[id])
    const ab = points[1].map((value, axis) => value - points[0][axis])
    const ac = points[2].map((value, axis) => value - points[0][axis])
    const normal = [
      ab[1] * ac[2] - ab[2] * ac[1],
      ab[2] * ac[0] - ab[0] * ac[2],
      ab[0] * ac[1] - ab[1] * ac[0]
    ]
    const length = Math.hypot(...normal) || 1
    const offset = 84 + triangle * 50
    for (let axis = 0; axis < 3; axis += 1) buffer.writeFloatLE(normal[axis] / length, offset + axis * 4)
    for (let vertex = 0; vertex < 3; vertex += 1) {
      for (let axis = 0; axis < 3; axis += 1) buffer.writeFloatLE(points[vertex][axis], offset + 12 + (vertex * 3 + axis) * 4)
    }
    buffer.writeUInt16LE(0, offset + 48)
  }
  fs.writeFileSync(file, buffer)
  return { triangles: triangleCount, vertices: mesh.numVert }
}

function stats (manifold) {
  const bounds = manifold.boundingBox()
  const mesh = manifold.getMesh()
  return {
    status: manifold.status(),
    bounds,
    size_mm: bounds.max.map((value, axis) => value - bounds.min[axis]),
    volume_mm3: manifold.volume(),
    triangles: mesh.numTri,
    vertices: mesh.numVert
  }
}

function main () {
  const args = parseArgs()
  const paramsPath = path.join(root, 'config', 'model-params.json')
  const params = resolveModelParameters(readJson(paramsPath))
  const manifestPath = path.resolve(path.dirname(paramsPath), params.relief.manifest)
  const manifest = readJson(manifestPath)
  const preview = args.quality === 'preview'
  const segments = preview ? params.export.segments_preview : params.export.segments_final
  const watermarkPath = path.resolve(path.dirname(paramsPath), params.watermark.dxf)
  const markOutline = watermarkOutline(watermarkPath, params.watermark)
  const preWatermarkModules = buildModulesManifold(params, manifest, {
    segments,
    withRelief: !preview,
    withWatermark: false,
    watermarkOutline: markOutline
  })
  // The production mark is deliberately the final geometry-changing step.
  const modules = preview
    ? preWatermarkModules
    : buildModulesManifold(params, manifest, {
        segments,
        withRelief: true,
        withWatermark: true,
        watermarkOutline: markOutline
      })
  const outputDir = path.join(root, 'output', 'DRAFT')
  const reportDir = path.join(root, 'reports')
  fs.mkdirSync(outputDir, { recursive: true })
  fs.mkdirSync(reportDir, { recursive: true })
  const report = {
    status: 'DRAFT',
    quality: args.quality,
    engine: `manifold-3d`,
    params: path.relative(root, paramsPath),
    resolved_wall_thickness_mm: {
      base: params.organizer.base_wall_thickness,
      outer: params.organizer.outer_wall_thickness,
      divider: params.organizer.divider_thickness
    },
    relief_manifest: path.relative(root, manifestPath),
    watermark: preview
      ? { enabled: false }
      : {
          asset_id: params.watermark.asset_id,
          variant: params.watermark.variant,
          dxf: path.relative(root, watermarkPath),
          source_bounds: markOutline.source_bounds,
          actual_envelope_mm: markOutline.actual_envelope_mm,
          scale: params.watermark.uniform_scale,
          rotation_deg: params.watermark.rotation_deg,
          depth_mm: params.watermark.depth,
          residual_floor_mm: params.organizer.floor_thickness - params.watermark.depth,
          relief_keepout_mm: params.relief.watermark_keepout,
          placements_global_xy: params.watermark.placements_global_xy,
          marked_parts: Object.keys(params.watermark.placements_global_xy),
          unmarked_covered_parts: params.watermark.unmarked_covered_parts
        },
    modules: []
  }
  if (!preview) {
    report.pre_watermark_geometry = preWatermarkModules.map(item => ({
      id: item.def.id,
      ...stats(item.textured)
    }))
  }
  for (const item of modules) {
    const global = preview ? item.smooth : item.textured
    const local = global.translate([-item.def.bounds[0], -item.def.bounds[2], 0])
    const filename = `DRAFT-${item.def.id}${preview ? '-smooth-preview' : '-textured'}.stl`
    const meshStats = writeBinaryStl(path.join(outputDir, filename), local, `DRAFT ${item.def.id} manifold-3d`)
    report.modules.push({ id: item.def.id, file: filename, ...stats(local), export_mesh: meshStats })
  }
  const comb = buildCombManifold(params, segments)
  const fit = buildFitCouponManifold(params)
  const relief = buildReliefCouponManifold(params, manifest)
  const connector = buildConnectorCouponManifold(params, segments)
  if (!preview) {
    writeBinaryStl(path.join(outputDir, 'DRAFT-screwdriver-comb.stl'), comb, 'DRAFT screwdriver comb manifold-3d')
    writeBinaryStl(path.join(outputDir, 'DRAFT-drawer-fit-corner-coupon.stl'), fit, 'DRAFT drawer fit coupon manifold-3d')
    writeBinaryStl(path.join(outputDir, 'DRAFT-relief-depth-coupon.stl'), relief, 'DRAFT relief coupon manifold-3d')
    writeBinaryStl(path.join(outputDir, 'DRAFT-connector-coupon-male.stl'), connector.male, 'DRAFT connector coupon male manifold-3d')
    writeBinaryStl(path.join(outputDir, 'DRAFT-connector-coupon-female.stl'), connector.female, 'DRAFT connector coupon female manifold-3d')
  }
  report.accessories = {
    comb: stats(comb),
    fit_coupon: stats(fit),
    relief_coupon: stats(relief),
    connector_coupon_male: stats(connector.male),
    connector_coupon_female: stats(connector.female)
  }
  report.assembly_envelope = assemblyEnvelope(modules)
  fs.writeFileSync(path.join(reportDir, `build-${args.quality}.json`), JSON.stringify(report, null, 2) + '\n')
  console.log(JSON.stringify({ status: 'ok', quality: args.quality, engine: 'manifold-3d', modules: modules.length }))
}

main()
