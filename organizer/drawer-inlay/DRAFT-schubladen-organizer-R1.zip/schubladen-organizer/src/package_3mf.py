#!/usr/bin/env python3
"""Package the validated binary STL meshes as a standards-namespaced 3MF assembly."""

from __future__ import annotations

import argparse
import json
import struct
import zipfile
from pathlib import Path
from xml.etree.ElementTree import Element, SubElement, tostring


ROOT = Path(__file__).resolve().parent.parent
CORE_NS = "http://schemas.microsoft.com/3dmanufacturing/core/2015/02"
REL_NS = "http://schemas.openxmlformats.org/package/2006/relationships"
CONTENT_NS = "http://schemas.openxmlformats.org/package/2006/content-types"
XML_NS = "http://www.w3.org/XML/1998/namespace"


def read_binary_stl(path: Path) -> list[tuple[tuple[float, float, float], ...]]:
    data = path.read_bytes()
    if len(data) < 84:
        raise ValueError(f"STL too short: {path}")
    count = struct.unpack_from("<I", data, 80)[0]
    expected = 84 + count * 50
    if len(data) != expected:
        raise ValueError(f"STL size mismatch: {path}")
    triangles = []
    for index in range(count):
        offset = 84 + index * 50 + 12
        values = struct.unpack_from("<9f", data, offset)
        triangles.append(tuple(tuple(values[i : i + 3]) for i in range(0, 9, 3)))
    return triangles


def fmt(value: float) -> str:
    if abs(value) < 5.0e-8:
        value = 0.0
    return f"{value:.6f}".rstrip("0").rstrip(".") or "0"


def mesh_xml(parent: Element, triangles, translation) -> None:
    mesh = SubElement(parent, f"{{{CORE_NS}}}mesh")
    vertices_node = SubElement(mesh, f"{{{CORE_NS}}}vertices")
    triangles_node = SubElement(mesh, f"{{{CORE_NS}}}triangles")
    vertex_ids: dict[tuple[float, float, float], int] = {}
    indexed_triangles = []
    for triangle in triangles:
        ids = []
        for vertex in triangle:
            global_vertex = tuple(round(vertex[axis] + translation[axis], 6) for axis in range(3))
            if global_vertex not in vertex_ids:
                vertex_ids[global_vertex] = len(vertex_ids)
            ids.append(vertex_ids[global_vertex])
        indexed_triangles.append(ids)
    ordered = sorted(vertex_ids.items(), key=lambda item: item[1])
    for (x, y, z), _ in ordered:
        SubElement(vertices_node, f"{{{CORE_NS}}}vertex", {"x": fmt(x), "y": fmt(y), "z": fmt(z)})
    for v1, v2, v3 in indexed_triangles:
        SubElement(triangles_node, f"{{{CORE_NS}}}triangle", {"v1": str(v1), "v2": str(v2), "v3": str(v3)})


def zip_info(name: str) -> zipfile.ZipInfo:
    info = zipfile.ZipInfo(name, date_time=(2026, 8, 11, 0, 0, 0))
    info.compress_type = zipfile.ZIP_DEFLATED
    info.external_attr = 0o644 << 16
    return info


def main() -> None:
    parser = argparse.ArgumentParser()
    parser.add_argument("--quality", choices=("final", "preview"), default="final")
    args = parser.parse_args()
    suffix = "textured" if args.quality == "final" else "smooth-preview"
    output_name = "DRAFT-R1-organizer-textured-assembly.3mf" if args.quality == "final" else "DRAFT-R1-organizer-smooth-preview-assembly.3mf"
    params = json.loads((ROOT / "config" / "model-params.json").read_text(encoding="utf-8"))
    zone = float(params["layout"]["screwdriver_zone_width"])
    split = float(params["layout"]["depth_split"])
    items = [
        ("driver-front", f"DRAFT-driver-front-{suffix}.stl", (0.0, 0.0, 0.0)),
        ("driver-back", f"DRAFT-driver-back-{suffix}.stl", (0.0, split, 0.0)),
        ("hardware-front", f"DRAFT-hardware-front-{suffix}.stl", (zone, 0.0, 0.0)),
        ("hardware-back", f"DRAFT-hardware-back-{suffix}.stl", (zone, split, 0.0)),
    ]

    model = Element(
        f"{{{CORE_NS}}}model",
        {"unit": "millimeter", f"{{{XML_NS}}}lang": "de-DE"},
    )
    SubElement(model, f"{{{CORE_NS}}}metadata", {"name": "Title"}).text = "Schubladen-Organizer R1 DRAFT"
    SubElement(model, f"{{{CORE_NS}}}metadata", {"name": "Application"}).text = "Parametric Manifold3D organizer pipeline"
    resources = SubElement(model, f"{{{CORE_NS}}}resources")
    build = SubElement(model, f"{{{CORE_NS}}}build")
    for object_id, (name, filename, translation) in enumerate(items, start=1):
        obj = SubElement(resources, f"{{{CORE_NS}}}object", {"id": str(object_id), "type": "model", "name": name})
        mesh_xml(obj, read_binary_stl(ROOT / "output" / "DRAFT" / filename), translation)
        SubElement(build, f"{{{CORE_NS}}}item", {"objectid": str(object_id)})

    model_xml = b'<?xml version="1.0" encoding="UTF-8"?>\n' + tostring(model, encoding="utf-8", xml_declaration=False)
    rels = Element(f"{{{REL_NS}}}Relationships")
    SubElement(
        rels,
        f"{{{REL_NS}}}Relationship",
        {
            "Target": "/3D/3dmodel.model",
            "Id": "rel-1",
            "Type": "http://schemas.microsoft.com/3dmanufacturing/2013/01/3dmodel",
        },
    )
    rels_xml = b'<?xml version="1.0" encoding="UTF-8"?>\n' + tostring(rels, encoding="utf-8", xml_declaration=False)
    types = Element(f"{{{CONTENT_NS}}}Types")
    SubElement(types, f"{{{CONTENT_NS}}}Default", {"Extension": "rels", "ContentType": "application/vnd.openxmlformats-package.relationships+xml"})
    SubElement(types, f"{{{CONTENT_NS}}}Default", {"Extension": "model", "ContentType": "application/vnd.ms-package.3dmanufacturing-3dmodel+xml"})
    types_xml = b'<?xml version="1.0" encoding="UTF-8"?>\n' + tostring(types, encoding="utf-8", xml_declaration=False)

    destination = ROOT / "output" / "DRAFT" / output_name
    with zipfile.ZipFile(destination, "w") as archive:
        archive.writestr(zip_info("[Content_Types].xml"), types_xml)
        archive.writestr(zip_info("_rels/.rels"), rels_xml)
        archive.writestr(zip_info("3D/3dmodel.model"), model_xml)
    legacy_name = "DRAFT-organizer-textured-assembly.3mf" if args.quality == "final" else "DRAFT-organizer-smooth-preview-assembly.3mf"
    (ROOT / "output" / "DRAFT" / legacy_name).unlink(missing_ok=True)
    print(f"packaged 4 objects into {destination}")


if __name__ == "__main__":
    main()
