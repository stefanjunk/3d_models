#!/usr/bin/env python3
"""Convert a prepared 16-bit height map into sparse printable raster runs.

The generated manifest is consumed by the JSCAD model.  It retains the image
as the replaceable source of relief while avoiding one B-rep feature per source
pixel.  Dark cells become engraving cutters; bright cells become emboss bodies.
"""

from __future__ import annotations

import argparse
import json
from pathlib import Path

import numpy as np
from PIL import Image


def load_config(path: Path) -> dict:
    with path.open("r", encoding="utf-8") as handle:
        return json.load(handle)


def normalize_image(path: Path, width: int, height: int) -> np.ndarray:
    image = Image.open(path)
    if image.mode not in ("I;16", "I", "F", "L"):
        image = image.convert("L")
    image = image.resize((width, height), Image.Resampling.LANCZOS)
    data = np.asarray(image)
    if data.dtype == np.uint16:
        field = data.astype(np.float32) / 65535.0
    elif np.issubdtype(data.dtype, np.integer):
        maximum = float(np.iinfo(data.dtype).max)
        field = data.astype(np.float32) / maximum
    else:
        field = data.astype(np.float32)
        low = float(np.nanmin(field))
        high = float(np.nanmax(field))
        field = (field - low) / max(high - low, 1.0e-9)
    return np.clip(field, 0.0, 1.0)


def runs_for_mask(mask: np.ndarray, level: str, minimum: int) -> list[dict]:
    runs: list[dict] = []
    for row_index, row in enumerate(mask):
        start = None
        for x_index, active in enumerate(np.append(row, False)):
            if active and start is None:
                start = x_index
            elif not active and start is not None:
                length = x_index - start
                if length >= minimum:
                    runs.append(
                        {
                            "level": level,
                            "row": int(row_index),
                            "x0": int(start),
                            "x1": int(x_index),
                        }
                    )
                start = None
    return runs


def save_preview(path: Path, field: np.ndarray, engrave: np.ndarray, emboss: np.ndarray) -> None:
    base = np.clip(field * 255.0, 0, 255).astype(np.uint8)
    rgb = np.stack([base, base, base], axis=-1)
    rgb[engrave] = [20, 80, 220]
    rgb[emboss] = [240, 60, 30]
    image = Image.fromarray(rgb, mode="RGB").resize(
        (field.shape[1] * 8, field.shape[0] * 8), Image.Resampling.NEAREST
    )
    image.save(path)


def main() -> None:
    parser = argparse.ArgumentParser()
    parser.add_argument("config", type=Path)
    parser.add_argument("output", type=Path)
    parser.add_argument("--preview", type=Path)
    args = parser.parse_args()

    cfg = load_config(args.config)
    tile_width = float(cfg["physical_tile_width_mm"])
    tile_height = float(cfg["physical_tile_height_mm"])
    pitch = float(cfg["geometry_pitch_mm"])
    nx = max(2, round(tile_width / pitch))
    ny = max(2, round(tile_height / pitch))
    source = (args.config.parent / cfg["prepared_heightmap"]).resolve()
    field = normalize_image(source, nx, ny)
    neutral = float(np.median(field))
    engrave_threshold = float(cfg["engrave_threshold"])
    emboss_threshold = float(cfg["emboss_threshold"])
    engrave_mask = field <= engrave_threshold
    emboss_mask = field >= emboss_threshold

    # Drop isolated one-cell noise while retaining two-cell FDM features.
    for mask in (engrave_mask, emboss_mask):
        neighbors = (
            np.roll(mask, 1, 0)
            + np.roll(mask, -1, 0)
            + np.roll(mask, 1, 1)
            + np.roll(mask, -1, 1)
        )
        mask &= neighbors >= 1

    minimum = int(cfg.get("minimum_run_cells", 1))
    runs = runs_for_mask(engrave_mask, "engrave", minimum)
    runs.extend(runs_for_mask(emboss_mask, "emboss", minimum))
    manifest = {
        "schema_version": 1,
        "source_heightmap": str(source),
        "tile_width_mm": tile_width,
        "tile_height_mm": tile_height,
        "pitch_x_mm": tile_width / nx,
        "pitch_y_mm": tile_height / ny,
        "grid": [nx, ny],
        "neutral_value": neutral,
        "thresholds": {
            "engrave_max": engrave_threshold,
            "emboss_min": emboss_threshold,
        },
        "counts": {
            "engrave_cells": int(np.count_nonzero(engrave_mask)),
            "emboss_cells": int(np.count_nonzero(emboss_mask)),
            "runs": len(runs),
        },
        "runs": runs,
    }
    args.output.parent.mkdir(parents=True, exist_ok=True)
    args.output.write_text(json.dumps(manifest, indent=2) + "\n", encoding="utf-8")
    if args.preview:
        save_preview(args.preview, field, engrave_mask, emboss_mask)
    print(json.dumps(manifest["counts"], sort_keys=True))


if __name__ == "__main__":
    main()
