# Austauschbare Stahlplatten-/Nieten-Heightmap

## Dateien

- `steel-rivets-source.png` – eigens erzeugtes Raster-Masterbild
- `steel-rivets-source-R1.png` – freigegebenes unregelmäßiges R1-Masterbild mit verschieden großen Platten und Patchstellen
- `steel-rivets-height-16.png` – vorbereitete 16-bit-Heightmap
- `steel-rivets-height-preview.png` – visuelle Vorschau
- `steel-rivets-relief-manifest.json` – vektorisierte Rasterläufe für das CAD-Modell
- `steel-rivets-vector-preview.png` – blau = Gravur, rot = Erhöhung

## Erzeugungsprompt des Masterbilds

> Seamless square grayscale displacement height map for 3D printing, orthographic and perfectly tileable. Mid-gray flat steel plate panels with crisp dark recessed plate seams, sparse small bright circular domed rivets along some seams and corners, neutral gray background, uniform height values only. No perspective, no directional lighting, no cast shadows, no reflections, no rust, no scratches, no text, no labels, no border. High contrast enough for shallow 0.35–0.40 mm FDM relief, large clean features, monochrome 16-bit-heightmap aesthetic.

## Höhenkonvention

- dunkel: Material wird entfernt / graviert
- mittelgrau: nominelle Fläche
- hell: Material wird erhaben ergänzt

Das physische R1-Kachelmaß beträgt 180 × 180 mm. Die abgeleitete 16-Bit-Datei wird mit 0,30 mm/Pixel aufbereitet und vor der Vektorisierung in beiden Achsen nahtkorrigiert. Die Produktionsgeometrie nutzt weiterhin ein 1,5-mm-Raster, damit Reliefmerkmale mit einer 0,40-mm-Düse robuste Bahnen bilden und die Booleschen Operationen reproduzierbar bleiben. Austauschschritte stehen im Projekt-`README.md`.
