# Schubladen-Organizer R1.6 – parametrische Oberflächen (DRAFT)

R1.6 übernimmt die funktionale Organizer-Geometrie aus R1.5 unverändert und macht ausschließlich die sichtbare Oberflächenfamilie austauschbar. Standard ist eine prozedurale 2×2-Carbon-Twill-Struktur; Walnuss aus R1.5, Stahl aus R1.4 und eine vollständig glatte Variante bleiben mit derselben Quelle rebuildbar.

> **Status:** digital validierter DRAFT. Carbonwirkung, Haptik, Reinigbarkeit, Ziel-Slicer-Pfade sowie die bereits bekannte reale Connector-Nichtpassung benötigen weiterhin Coupons und eine Slicerprüfung.

![R1.6 Carbon – tatsächliche STL-Vorschau](reports/DRAFT-R1.6-carbon-model-preview.png)

## Rebuild

```bash
python3 rebuild.py --surface carbon
python3 rebuild.py --surface walnut
python3 rebuild.py --surface steel
python3 rebuild.py --surface plain
```

Ohne `--surface` wird `default_profile` aus `config/surface-texture.json` verwendet. Der Build verändert keine Konfigurationsdatei. Haupt-STLs und gemeinsame Reports bilden immer den zuletzt gebauten Modus ab; 3MF und ZIP tragen den Profilnamen.

## Carbonoberfläche

Die Carbonvariante verwendet ein deterministisches 2×2-Twill-Feld aus flachen, linsenförmigen Zellen. Zwei Tiefenstufen und wechselnde ±45°-Richtungen erzeugen die Over/Under-Wirkung und wechselnde Highlights. Einzelne Fasern werden bewusst nicht modelliert; schwarze Farbe, Satin-Glanz und gerichtete Top-Pfade liefern den optischen Feinmaßstab.

| Fläche | Pitch | Zellenbreite | maximale Tiefe |
|---|---:|---:|---:|
| Innenböden | 3,00 mm | 1,05 mm | 0,18 mm |
| innere Wandflächen | 3,15 mm | 1,00 mm | 0,16 mm |
| Wandoberseiten | 2,60 mm | 0,55 mm | 0,10 mm |

Die Struktur ist nur Carbonoptik. Sie verleiht dem Druckteil keine Eigenschaften eines Carbonlaminats.

## Geschützte Geometrie

Unabhängig vom Profil bleiben Außenwände, Connectoren, Wandknoten, Griffnuten, Gussets, Wandwurzeln, Bettauflage und Kennzeichnungszonen glatt. Organizerhülle, Fächer, Kamm, Wandstärken und Connector-Nennfreigabe werden nicht umkonstruiert. Die Texturen sind ausschließlich subtraktiv und flach; `plain` deaktiviert sie vollständig.

## Parameterstruktur

- `config/surface-texture.json` – Profilselektor und Default
- `config/surfaces/carbon.json` – Twillmaßstab, Tiefen, Finish und Budgets
- `config/surfaces/walnut.json` – unveränderte R1.5-Maserungsfamilie
- `config/surfaces/steel.json` – unveränderte R1.4-Schmiedestahlfamilie
- `config/surfaces/plain.json` – Nulltextur-Baseline
- `src/surface_texture.mjs` – kleiner Profil-Dispatcher
- `src/textures/*.mjs` – voneinander getrennte prozedurale Generatoren

## Empfohlene Freigabereihenfolge

1. `DRAFT-surface-texture-coupon.stl` im gewählten Material drucken und unter mindestens drei Lichtwinkeln prüfen.
2. Connector-Coupons gemeinsam drucken und Istmaße/Fügegefühl dokumentieren.
3. Eckcoupon im realen Schubladenrand prüfen.
4. Profilbenannte 3MF im Ziel-Slicer öffnen; erste drei Schichten, kurze Texturpfade, Wandoberseiten, glatte Keep-outs und Unterseitenkennzeichnung prüfen.
5. Erst danach ein Hauptmodul drucken.

Die Herstellungsdateien bleiben `DRAFT`, bis diese physischen und Slicer-Prüfungen bestanden sind.

## Digitaler Buildstatus

- 9/9 STL-Dateien: watertight, manifold, einteilig, positiv volumig
- Hauptmodule: 199.426–283.924 Dreiecke nach lokaler Float32-Sliver-Reparatur
- 3MF: vier positionierte Objekte, 227 × 357 × 64 mm, CRC PASS
- Connector-Coupons: byte-identisch zu R1.4
- Peak-RSS: 498,75 MiB; unter dem 2.048-MiB-Ziel
- Release-ZIP: CRC PASS

Details stehen in `reports/validation-report.md` und `reports/surface-texture-validation.json`.
