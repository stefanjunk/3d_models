# Decision Log – Schubladen-Organizer

## 2026-08-22 – R1.6 parametrische Oberflächen

- Nutzerwunsch: zusätzliche außergewöhnlich realistische Carbonoberfläche, ohne vollständiges Redesign; Stahl aus R1.4 und eine rebuildbare Nulltextur sollen wählbar sein.
- Architektur: neue R1.6-Arbeitskopie; R1.4 und R1.5 bleiben unverändert. Ein Selektor wählt `carbon`, `walnut`, `steel` oder `plain`, ohne Konfigurationsdateien umzuschreiben.
- Carbonrepräsentation: prozedurale 2×2-Twill-Zellen mit ±45°-Richtung, linsenförmigem Profil und getrennten Over/Under-Tiefen. Kein Foto, keine Heightmap, keine modellierten Mikrofasern.
- Prozessmaßstab: 0,40-mm-Düse, 0,44-mm-Linienbreite, 0,20-mm-Schicht. Nominaler Pitch 2,60–3,15 mm; Relief 0,075–0,18 mm.
- Schutz: Außenwände, Connectoren, Junctions, Griffnuten, Gussets, Wandwurzeln, Bettauflage und Kennzeichnung bleiben glatt. Kernmaße, Layout, Kamm und Connectoren sind unverändert.
- Materialwirkung: dunkles Satinmaterial und gerichtete Top-Pfade tragen Farbe und Glanz. Carbonoptik ist keine Aussage über Laminatsteifigkeit.
- Freigabe: digitaler Mesh-/3MF-Build, Profil-Coupon, Ziel-Slicer-Prüfung, Connector-Coupon und Schubladen-Eckcoupon erforderlich; bis dahin DRAFT.

## Geerbte Oberflächen

- `walnut` übernimmt den prozeduralen R1.5-Grain/Knot-Generator und seine Parameter.
- `steel` übernimmt den prozeduralen R1.4-Dimple-Generator und seine Parameter.
- `plain` schaltet alle optionale Oberflächengeometrie ab und dient als Regressionsbaseline.
