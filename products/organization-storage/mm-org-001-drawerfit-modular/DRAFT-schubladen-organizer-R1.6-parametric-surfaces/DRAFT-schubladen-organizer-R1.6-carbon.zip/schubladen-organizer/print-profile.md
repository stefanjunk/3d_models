# Druckprofil – R1.6 parametrische Oberflächen (DRAFT)

## Gemeinsamer Startpunkt

| Parameter | Startwert |
|---|---:|
| Düse | 0,40 mm |
| Linienbreite | 0,44 mm |
| Schichthöhe | 0,20 mm |
| Orientierung | Unterseite flach |
| Supports | aus |
| Fuzzy Skin | aus |

## Profilabhängige Wirkung

| Profil | Materialstart | Top-Pfad | Hinweis |
|---|---|---|---|
| `carbon` | tiefschwarzes Satin-PETG oder PLA | monoton, möglichst +45° | trocknen; Glanz unter drei Winkeln prüfen |
| `walnut` | mattes walnussbraunes PETG | monoton, vorn–hinten | optionale Wash/Mattschicht nur nach Coupon |
| `steel` | metallisches Graphit-PETG | monoton, einheitlich | Abrasionshinweise des Herstellers beachten |
| `plain` | qualifiziertes Basismaterial | Standardprofil | Nulltextur-Vergleich |

Zuerst den Oberflächencoupon drucken. Prüfkriterien sind erkennbare Musterfamilie bei 300–700 mm Abstand, saubere kurze Pfade, keine scharfen Kanten, Wischreinigung, keine verlorenen Zellen sowie glatte funktionale Keep-outs. Carbongefülltes Filament ist optional und kann abrasiv sein; es ersetzt weder Twillgeometrie noch Düsenprüfung.
