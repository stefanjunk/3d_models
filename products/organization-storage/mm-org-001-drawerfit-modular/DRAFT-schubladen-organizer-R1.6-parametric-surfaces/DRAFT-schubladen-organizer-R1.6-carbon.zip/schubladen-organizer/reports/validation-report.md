# Validierungsbericht – R1.6 Carbonoberfläche (DRAFT)

## Ergebnis

Der profilselektierbare R1.6-Build wurde mit `--surface carbon` vollständig erzeugt. Alle neun STL-Dateien sind geschlossen, manifold, einteilig und positiv volumig. Die positionierte Vierobjekt-3MF besteht CRC- und Hüllenprüfung. Die Carbonvariante bleibt DRAFT, weil optische Wirkung, Haptik, Reinigbarkeit, Connectorpassung und exakte Ziel-Slicer-Pfade physisch beziehungsweise im Ziel-Slicer geprüft werden müssen.

## Oberflächensystem

| Fläche | Twill-Zellen | maximale Tiefe | Restmaterial |
|---|---:|---:|---:|
| Innenböden | 5.199 | 0,18 mm | 2,42 mm |
| innere Wandflächen | 12.456 | 0,16 mm | 2,88 mm doppelseitige Trennwand |
| Wandoberseiten | 681 | 0,10 mm | 54,90 mm vertikale Reserve |

- Repräsentation: `deterministic-2x2-twill-lenticular-cell-field`
- Seed: `160622`
- Over/Under: wechselnde ±45°-Kapselzellen mit zwei flachen Tiefenstufen
- Bild-/Heightmap-Pfad: inaktiv
- Glatt geschützt: Außenwände, Connectoren, Junctions, Griffnuten, Gussets, Wandwurzeln, Bettauflage und Kennzeichnung
- Aussagegrenze: Carbonoptik, keine Carbonlaminat-Struktur- oder Festigkeitsbehauptung

## Mesh- und Ressourcenprüfung

| Datei | Dreiecke | Ergebnis |
|---|---:|---|
| Driver vorn | 202.916 | PASS |
| Driver hinten | 199.426 | PASS |
| Hardware vorn | 283.924 | PASS |
| Hardware hinten | 255.294 | PASS |
| Oberflächencoupon | 18.136 | PASS |
| Kamm / Eckcoupon | 612 / 100 | PASS |
| Connector male / female | 152 / 144 | PASS |

Die dichte strukturierte Oberfläche erzeugte bei der Float32-STL-Tessellation lokal sehr kurze Sliverkanten. Der deterministische lokale Reparaturschritt kollabierte 1 Kante im vorderen und 52 Kanten im hinteren Hardwaremodul; danach bleiben 0 Boundary-, Non-Manifold-, Zero-Area- und Duplicate-Face-Fehler. Die Funktionsflächen wurden nicht global decimiert.

- Peak-RSS: 498,75 MiB
- Ziel: 2.048 MiB; Stop: 4.096 MiB
- Triangle-Review-Grenze: 1.000.000 je Modul
- größtes Modul: 283.924 Dreiecke

## Funktionsregression

- Baugruppenhülle: 227 × 357 × 64 mm
- Boden / Basiswand: 2,6 / 3,2 mm
- Connector-Nennfreigabe: 0,30 mm
- Male- und Female-Connector-Coupons: SHA-256 byte-identisch zu R1.4
- Organizerlayout, Fächer, Kamm, Griffnuten und Connectorgeometrie: unverändert

## Offene Freigabepunkte

1. Carboncoupon in Zielmaterial drucken und unter drei Lichtwinkeln fotografieren.
2. Kurze Zellpfade, Wandtop-Komfort, Wischreinigung und Staubretention prüfen.
3. Connectorpaar drucken und die bekannte reale Nichtpassung separat vermessen.
4. Eckcoupon in der realen Schublade prüfen.
5. 3MF im Ziel-Slicer prüfen; erste drei Schichten, Wandpfade, Keep-outs und Kennzeichnung kontrollieren.
