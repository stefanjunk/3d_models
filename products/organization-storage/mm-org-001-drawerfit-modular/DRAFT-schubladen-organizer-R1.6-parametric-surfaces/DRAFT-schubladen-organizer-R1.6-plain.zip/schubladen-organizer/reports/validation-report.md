# Validierungsbericht – R1.6 Carbon Basket Weave (DRAFT)

## Ergebnis

Der profilselektierbare R1.6-Build wurde mit `--surface carbon-wave` vollständig erzeugt. Alle neun STL-Dateien sind geschlossen, manifold, einteilig und positiv volumig. Die positionierte Vierobjekt-3MF besteht CRC- und Hüllenprüfung. Die Variante bleibt DRAFT, weil optische Wirkung, Haptik, Reinigbarkeit, Connectorpassung und exakte Ziel-Slicer-Pfade physisch beziehungsweise im Ziel-Slicer geprüft werden müssen.

## Oberflächensystem

| Fläche | Tow-Zellen | maximale Tiefe | Restmaterial |
|---|---:|---:|---:|
| Innenböden | 4.908 | 0,18 mm | 2,42 mm |
| innere Wandflächen | 12.499 | 0,16 mm | 2,88 mm doppelseitige Trennwand |
| Wandoberseiten | 374 | 0,09 mm | 54,91 mm vertikale Reserve |

- Referenz: `libraries/carbonfiber1.png`
- Repräsentation: `deterministic-reference-basket-weave-tow-cell-field`
- Seed: `160823`
- Over/Under-Wirkung: gepaarte breite 0°/90°-Tow-Zellen, diagonal versetzte Blockalternation und stärkere horizontale Tiefe
- Fasereindruck: drei flache Längsmodulationen je breitem Tow; einzelne Carbonfilamente werden nicht behauptet
- Bild-/Heightmap-Pfad: inaktiv
- Glatt geschützt: Außenwände, Connectoren, Junctions, Griffnuten, Gussets, Wandwurzeln, Bettauflage und Kennzeichnung
- Aussagegrenze: Carbonoptik, keine Carbonlaminat-Struktur- oder Festigkeitsbehauptung

## Mesh- und Ressourcenprüfung

| Datei | Dreiecke | Ergebnis |
|---|---:|---|
| Driver vorn | 504.494 | PASS |
| Driver hinten | 495.352 | PASS |
| Hardware vorn | 712.538 | PASS |
| Hardware hinten | 609.744 | PASS |
| Oberflächencoupon | 44.496 | PASS |
| Kamm / Eckcoupon | 612 / 100 | PASS |
| Connector male / female | 152 / 144 | PASS |

Der endliche, 0,008–0,015 mm tiefe Tow-Randeintritt vermeidet tangentiale Float32-Flächen. Kein strukturiertes STL benötigte einen Sliver-Kollaps: 0 Boundary-, Non-Manifold-, Zero-Area- und Duplicate-Face-Fehler. Funktionsflächen wurden nicht global decimiert.

- Peak-RSS: 939,31 MiB
- Ziel: 1.536 MiB; Stop: 3.072 MiB
- Triangle-Review-Grenze: 1.000.000 je Modul
- größtes Modul: 712.538 Dreiecke

## Funktionsregression

- Baugruppenhülle: 227 × 357 × 64 mm
- Boden / Basiswand: 2,6 / 3,2 mm
- Connector-Nennfreigabe: 0,30 mm
- Male- und Female-Connector-Coupons: SHA-256 byte-identisch zu R1.4
- Organizerlayout, Fächer, Kamm, Griffnuten und Connectorgeometrie: unverändert

## Offene Freigabepunkte

1. `carbon-wave`-Coupon in Zielmaterial drucken und unter drei Lichtwinkeln fotografieren.
2. 0/90-Tow-Paare, diagonalen Wechsel, Wandtop-Komfort, Wischreinigung und Staubretention prüfen.
3. Connectorpaar drucken und die bekannte reale Nichtpassung separat vermessen.
4. Eckcoupon in der realen Schublade prüfen.
5. 3MF im Ziel-Slicer prüfen; erste drei Schichten, Wandpfade, Keep-outs und Kennzeichnung kontrollieren.
