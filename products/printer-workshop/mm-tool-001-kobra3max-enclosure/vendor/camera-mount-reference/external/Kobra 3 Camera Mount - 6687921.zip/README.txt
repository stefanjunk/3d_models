Kobra 3 Camera Mount by Curtiswlkr on Thingiverse: https://www.thingiverse.com/thing:6687921

Summary:
Anycubic Kobra 3 camera mount. This is the DIY camera mount from Anycubic. Its kind of hard to locate the STL's after buying their camera and having to print the mount yourself so I'm uploading it here.The .3mf in the files is for the Kobra 3 with PLA+ ready to print. It is shown on the build plate pic and It came out perfect.