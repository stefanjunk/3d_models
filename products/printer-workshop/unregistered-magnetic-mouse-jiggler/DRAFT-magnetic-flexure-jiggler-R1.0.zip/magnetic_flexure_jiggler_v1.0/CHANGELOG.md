# Changelog

## R1.0 — prototype

- Replaced geared rotary drive with flat moving-coil actuator.
- Added monolithic 4-beam 1D flexure stage.
- Added ±1.2 mm mechanical hard stops around ±1.0 mm commanded travel.
- Added 0.50 / 0.55 / 0.60 mm flexure variants and calibration coupon.
- Added low / mid / high sensor risers for optical lift-off calibration.
- Added rectangular coil bobbin and winding jig.
- Added two-bar-magnet carrier with optional steel back-iron recess.
- Added generic MCU/H-bridge bay and USB cable exit.
- Added random-motion ESP32-C3 example firmware using 20 kHz PWM.
- Assembly interference review found a collision between the first stage frame and lid screw posts; stage width and mounting layout were revised. Final reference assembly reports zero volumetric interference for the checked pairs.
- All individual STL exports pass watertight and single-connected-body validation.
