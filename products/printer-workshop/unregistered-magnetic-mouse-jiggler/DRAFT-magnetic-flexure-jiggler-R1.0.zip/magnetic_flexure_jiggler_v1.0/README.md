# Magnetic 1D Flexure Mouse Jiggler — Prototype R1.0

A quiet, physically moving optical surface for a mouse sensor. The moving surface is guided by four printed flexure beams and driven by a flat moving-coil actuator. There are no gears, rolling bearings, or sliding guides.

> Status: **prototype design, geometry checked, not yet physically validated.** The mechanical files are rebuildable and include calibration variants so the first print can be tuned rather than treated as a final production release.

## 1. Design targets

- 1D optical-surface motion: **±1.0 mm nominal**, hard-stop at approx. ±1.2 mm.
- Quiet actuation: Lorentz / voice-coil principle; no geared motor.
- Overall enclosure: **100 × 80 × 17 mm** nominal.
- Optical surface height adjustable for different mouse lift-off distances.
- Printable on a normal 0.4 mm FDM nozzle.
- Base, lid, flexure stage, actuator carriers and calibration tools are printable.
- 5 V electronics can be housed in the base.

## 2. Architecture

From top to bottom:

1. `lid` — stationary mouse support with 36 × 30 mm optical window.
2. `sensor_tile` — textured moving target under the mouse sensor.
3. `sensor_riser_*` — sets the sensor-surface distance.
4. `flexure_stage_*` — monolithic 1D spring guidance with mechanical end stops.
5. `coil_bobbin` — moving rectangular coil, bonded under the sled.
6. Two **20 × 5 × 2 mm neodymium bar magnets**, mounted with opposite upward poles.
7. `magnet_carrier` + optional thin steel back plate.
8. `base` — enclosure, stage supports, generic electronics bay and cable exit.

## 3. Recommended R1.0 configuration

- Material for flexure stage: **PETG**.
- Flexure: `flexure_stage_055.stl` (0.55 mm beam width).
- Sensor riser: `sensor_riser_mid.stl`.
- Coil: ~150 turns of **0.15 mm enamelled copper wire**, target resistance roughly 10–15 Ω.
- Magnets: 2 × 20 × 5 × 2 mm neodymium bars.
- Driver: DRV8833-class H-bridge or equivalent.
- Controller: ESP32-C3 / similar small MCU.
- Supply: 5 V USB.

The left and right magnets must present **opposite poles toward the moving coil**. Current reversal in the coil reverses the lateral force.

## 4. Why there are calibration variants

FDM line width, polymer modulus and mouse optical lift-off distance vary significantly in practice. R1.0 therefore includes:

### Flexure stages

- `flexure_stage_050.stl` — softest / easiest to move.
- `flexure_stage_055.stl` — default.
- `flexure_stage_060.stl` — stiffer / more robust.

Print `flexure_calibration_coupon.stl` first if desired. The three test cells are identified by 1, 2 and 3 holes and correspond to 0.50 / 0.55 / 0.60 mm.

### Sensor risers

- `sensor_riser_low.stl` — optical target about 0.95 mm below the lid top plane.
- `sensor_riser_mid.stl` — about 0.65 mm below the lid top plane.
- `sensor_riser_high.stl` — about 0.35 mm below the lid top plane.

Start with **mid**. If the mouse does not track, try **high**. If the mouse physically rubs the moving tile, use **low**.

## 5. Print order for the functional-design workflow

1. Print `flexure_calibration_coupon.stl`.
2. Confirm the 0.55 mm beam prints continuously and returns to centre after a ±1 mm finger deflection.
3. Print `magnet_carrier.stl` and test the magnet pocket fit before gluing magnets.
4. Print `coil_winding_jig.stl` and wind/test the coil resistance.
5. Bench-test the coil + magnets + H-bridge at low PWM duty.
6. Print `flexure_stage_055.stl`, `coil_bobbin.stl`, `sensor_riser_mid.stl`, `sensor_tile.stl`.
7. Assemble and verify ±1 mm motion without the lid.
8. Print/fit `base.stl` and `lid.stl`.
9. Choose final riser height based on the actual mouse.
10. Only after the above checks, run the randomized firmware.

## 6. Critical dimensions

- Flexure beam free length: ~21 mm.
- Default flexure beam cross-section: 0.55 × 0.80 mm.
- Mechanical stop clearance: nominal travel + 0.20 mm per side.
- Magnet pocket: 20.2 × 5.2 × 2.25 mm.
- Moving-coil bobbin outer size: 30 × 22 × 2.6 mm.
- Nominal magnet-to-bobbin plastic gap: ~0.7 mm.
- Optical window: 36 × 30 mm.

See `docs/parameters.json` for the rebuild parameters.

## 7. Engineering check

The included `docs/engineering_check.py` estimates the flexure and coil requirements. With PETG modulus assumed at 2 GPa, the default 0.55 mm flexures are approximately:

- combined lateral stiffness: **0.115 N/mm**
- force at 1 mm: **0.115 N**
- estimated peak beam strain at 1 mm: **0.37 %**

The coil estimate assumes 150 turns of 0.15 mm wire and an effective magnetic field of 0.15 T. The resulting required current is estimated at ~0.14 A for a 1 mm static displacement. This magnetic-force estimate must be verified with the real magnets and wound coil before unattended use.

## 8. Print settings

See `docs/PRINT_SETTINGS.md`. The flexure stage is the critical part; do not auto-thicken the thin beams without checking the generated toolpath.

## 9. CAD / exports

- `cad/generate_cad.py` — rebuildable CadQuery source.
- `step/` — editable STEP exports for all parts and reference assembly.
- `stl/` — STL exports.
- `stl_print_ready/` — bed-oriented copies for slicing.
- `magnetic_flexure_jiggler_print_plate.3mf` — convenience multi-part plate.

Run:

```bash
python cad/generate_cad.py
```

from the project folder after installing CadQuery.

## 10. Assembly caveat

This is the first mechanical release of a custom actuator, not a hardware-tested commercial design. The geometry, mesh validity, clearances and first-order mechanics are checked, but the real actuator force depends strongly on magnet grade, steel return path, winding quality and actual air gap. Use the staged test procedure above before committing to a full assembly.
