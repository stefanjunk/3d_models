$fn=64;
root="../stl/";
color([0.70,0.72,0.74,1.0]) import(str(root,"base.stl"));
color([0.15,0.17,0.20,1.0]) translate([0,0,3.4]) import(str(root,"magnet_carrier.stl"));
// Reference solids for purchased magnets (not printed)
color([0.76,0.77,0.80,1.0]) translate([-13,0,4.8]) cube([5,20,2],center=true);
color([0.40,0.43,0.48,1.0]) translate([13,0,4.8]) cube([5,20,2],center=true);
color([0.82,0.45,0.12,1.0]) translate([0,0,6.5]) import(str(root,"coil_bobbin.stl"));
color([0.18,0.20,0.23,1.0]) translate([0,0,8.4]) import(str(root,"flexure_stage_055.stl"));
color([0.28,0.31,0.34,1.0]) translate([0,0,10.4]) import(str(root,"sensor_riser_mid.stl"));
color([0.10,0.12,0.14,1.0]) translate([0,0,15.57]) import(str(root,"sensor_tile.stl"));
// Exploded lid +5 mm from installed location
color([0.78,0.80,0.82,0.72]) translate([0,0,19.0]) import(str(root,"lid.stl"));
