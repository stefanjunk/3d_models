$fn=64;
color([0.2,0.22,0.24]) import("../stl/flexure_calibration_coupon.stl");
