import cadquery as cq
from cadquery import exporters
from pathlib import Path
import math, json

ROOT=Path(__file__).resolve().parents[1]
STL=ROOT/'stl'; STEP=ROOT/'step'
STL.mkdir(exist_ok=True); STEP.mkdir(exist_ok=True)

# ---------------- Parameters (mm) ----------------
P = {
  'outer_x': 100.0,
  'outer_y': 80.0,
  'base_h': 14.0,
  'floor_t': 2.4,
  'wall_t': 2.4,
  'corner_r': 6.0,
  'lid_t': 3.0,
  'lid_clearance': 0.25,
  'screw_d': 3.4,
  'screw_head_d': 6.6,
  'screw_x': 43.0,
  'screw_y': 33.0,
  'stage_x': 76.0,
  'stage_y': 68.0,
  'stage_frame_w': 4.0,
  'stage_frame_t': 2.0,
  'stage_z': 8.4,
  'sled_x': 34.0,
  'sled_y': 18.0,
  'sled_t': 2.0,
  'flex_w': 0.55,
  'flex_t': 0.8,
  'travel': 1.0,
  'stop_extra': 0.20,
  'sensor_tile_x': 30.0,
  'sensor_tile_y': 24.0,
  'sensor_tile_t': 0.8,
  'sensor_recess_d': 0.35,
  'coil_outer_x': 30.0,
  'coil_outer_y': 22.0,
  'coil_inner_x': 24.0,
  'coil_inner_y': 16.0,
  'coil_bobbin_t': 2.6,
  'coil_flange_t': 0.5,
  'coil_channel_depth': 1.8,
  'mag_x': 5.2,      # pocket for nominal 5.0
  'mag_y': 20.2,     # pocket for nominal 20.0
  'mag_z': 2.25,     # pocket for nominal 2.0
  'mag_center_x': 13.0,
  'magnet_carrier_x': 38.0,
  'magnet_carrier_y': 28.0,
  'magnet_carrier_t': 2.4,
  'steel_plate_x': 34.0,
  'steel_plate_y': 24.0,
  'steel_plate_z': 1.2,
  'pcb_bay_x': 28.0,
  'pcb_bay_y': 23.0,
  'pcb_bay_depth': 2.0,
  'cable_slot_x': 12.0,
  'cable_slot_z': 5.0,
  'foot_d': 10.0,
  'foot_h': 2.0,
}

# ---------- helpers ----------
def rounded_plate(x,y,z,r):
    return (cq.Workplane('XY').rect(x-2*r,y).extrude(z)
            .union(cq.Workplane('XY').rect(x,y-2*r).extrude(z))
            .union(cq.Workplane('XY').pushPoints([(sx*(x/2-r), sy*(y/2-r)) for sx in (-1,1) for sy in (-1,1)])
                   .circle(r).extrude(z)))

def export(shape, name, tol=0.01, ang=0.2):
    exporters.export(shape, str(STEP/f'{name}.step'))
    exporters.export(shape, str(STL/f'{name}.stl'), tolerance=tol, angularTolerance=ang)

# ---------- Base ----------
def make_base():
    ox,oy,h=P['outer_x'],P['outer_y'],P['base_h']
    body=rounded_plate(ox,oy,h,P['corner_r'])
    inner=rounded_plate(ox-2*P['wall_t'],oy-2*P['wall_t'],h-P['floor_t']+0.2,max(1,P['corner_r']-P['wall_t']))
    inner=inner.translate((0,0,P['floor_t']))
    body=body.cut(inner)
    # lid screw posts
    for x in (-P['screw_x'],P['screw_x']):
      for y in (-P['screw_y'],P['screw_y']):
        post=(cq.Workplane('XY').center(x,y).circle(4.2).extrude(h-1.0)
              .cut(cq.Workplane('XY').center(x,y).circle(1.35).extrude(h)))
        body=body.union(post)
    # stage support pads at 6 points, top at stage_z
    pad_h=P['stage_z']-P['floor_t']
    for x,y in [(-30,-32),(0,-32),(30,-32),(-30,32),(0,32),(30,32)]:
        pad=cq.Workplane('XY').center(x,y).rect(6,6).extrude(pad_h).translate((0,0,P['floor_t']))
        body=body.union(pad)
    # magnet cartridge pedestal: raises carrier so magnet faces sit close to moving coil
    ledge_z=P['floor_t']
    ledge=(cq.Workplane('XY').rect(P['magnet_carrier_x']+4,P['magnet_carrier_y']+4).extrude(1.0).translate((0,0,ledge_z)))
    body=body.union(ledge)
    # electronics bay shallow recess in floor, rear right
    bay=(cq.Workplane('XY').center(31,0).rect(P['pcb_bay_x'],P['pcb_bay_y']).extrude(P['pcb_bay_depth']).translate((0,0,P['floor_t']-P['pcb_bay_depth']+0.01)))
    body=body.cut(bay)
    # two zip-tie slots near PCB bay
    for yy in (-6,6):
        slot=cq.Workplane('XY').center(31,yy).rect(24,2.2).extrude(P['floor_t']+0.2)
        body=body.cut(slot)
    # cable exit in rear wall (negative y)
    slot=(cq.Workplane('XZ').center(0,5.0).rect(P['cable_slot_x'],P['cable_slot_z']).extrude(P['wall_t']+2).translate((0,-oy/2-1,0)))
    body=body.cut(slot)
    # ventilation / wire route holes near coil
    for x in (-18,18):
        hole=cq.Workplane('XY').center(x,0).circle(2).extrude(P['floor_t']+0.3)
        body=body.cut(hole)
    return body

# ---------- Lid ----------
def make_lid():
    lid=rounded_plate(P['outer_x'],P['outer_y'],P['lid_t'],P['corner_r'])
    # Central optical window; sized for riser + +/-1 mm motion + print clearance
    win=(cq.Workplane('XY').rect(36.0,30.0).extrude(P['lid_t']+0.5).translate((0,0,-0.2)))
    lid=lid.cut(win)
    # screw clearance + countersink-like head recess from top
    for x in (-P['screw_x'],P['screw_x']):
      for y in (-P['screw_y'],P['screw_y']):
        hole=cq.Workplane('XY').center(x,y).circle(P['screw_d']/2).extrude(P['lid_t']+0.3).translate((0,0,-0.1))
        head=cq.Workplane('XY').center(x,y).circle(P['screw_head_d']/2).extrude(1.3).translate((0,0,P['lid_t']-1.3))
        lid=lid.cut(hole).cut(head)
    # underside locating lip, segmented to avoid tight fit
    lip_z=1.2
    lipx=P['outer_x']-2*P['wall_t']-2*P['lid_clearance']
    lipy=P['outer_y']-2*P['wall_t']-2*P['lid_clearance']
    # 4 small locating tabs
    for x,y,dx,dy in [(0, lipy/2-1.6,36,2.5),(0,-lipy/2+1.6,36,2.5),(lipx/2-1.6,0,2.5,26),(-lipx/2+1.6,0,2.5,26)]:
        tab=cq.Workplane('XY').center(x,y).rect(dx,dy).extrude(lip_z).translate((0,0,-lip_z))
        lid=lid.union(tab)
    return lid

# ---------- Flexure stage ----------
def make_stage(flex_w=None):
    if flex_w is None: flex_w=P['flex_w']
    sx,sy=P['stage_x'],P['stage_y']; fw=P['stage_frame_w']; ft=P['stage_frame_t']
    # ring frame
    frame=cq.Workplane('XY').rect(sx,sy).extrude(ft)
    frame=frame.cut(cq.Workplane('XY').rect(sx-2*fw,sy-2*fw).extrude(ft+0.3).translate((0,0,-0.1)))
    # sled
    sled=cq.Workplane('XY').rect(P['sled_x'],P['sled_y']).extrude(P['sled_t'])
    stage=frame.union(sled)
    # four flexure beams parallel Y, connect sled to inside frame edge
    inner_y=sy/2-fw
    beam_len=inner_y-P['sled_y']/2
    # x locations chosen to resist yaw
    xloc=P['sled_x']/2-5.0
    z0=(P['stage_frame_t']-P['flex_t'])/2
    for x in (-xloc,xloc):
        # top and bottom beams, exact butt connection
        for sign in (-1,1):
            y0=sign*(P['sled_y']/2 + beam_len/2)
            beam=cq.Workplane('XY').center(x,y0).rect(flex_w,beam_len+0.04).extrude(P['flex_t']).translate((0,0,z0))
            stage=stage.union(beam)
    # motion stop ears + grounded stop towers. Stops engage at travel + 0.20 mm.
    gap=P['travel']+P['stop_extra']
    ear_y=4.5
    inner_x=sx/2-fw
    for sign in (-1,1):
        xear=sign*(P['sled_x']/2+2.0)
        ear=cq.Workplane('XY').center(xear,0).rect(4.0,ear_y).extrude(P['sled_t'])
        stage=stage.union(ear)
        stop_inner=sign*(P['sled_x']/2+4.0+gap)
        stopx=stop_inner+sign*1.5
        stop=cq.Workplane('XY').center(stopx,0).rect(3.0,8.0).extrude(P['stage_frame_t'])
        # rigid bridge back to outer frame so stop is part of the grounded frame
        bridge_len=inner_x-abs(stopx)-1.5
        bridge_center=sign*(abs(stopx)+1.5+bridge_len/2)
        bridge=cq.Workplane('XY').center(bridge_center,0).rect(bridge_len+0.05,3.0).extrude(P['stage_frame_t'])
        stage=stage.union(stop).union(bridge)
    # 4 stage mounting holes in the top/bottom frame rails, away from lid posts.
    for x,y in [(-30,-32),(30,-32),(-30,32),(30,32)]:
        hole=cq.Workplane('XY').center(x,y).circle(1.35).extrude(ft+0.3).translate((0,0,-0.1))
        stage=stage.cut(hole)
    # underside interface recess for coil bobbin flange
    coil_recess=(cq.Workplane('XY').rect(P['coil_outer_x']+1.0,P['coil_outer_y']+1.0).extrude(0.7).translate((0,0,-0.01)))
    stage=stage.cut(coil_recess)
    # two tiny wire reliefs from bobbin to back
    for x in (-10,10):
        relief=cq.Workplane('XY').center(x,-P['sled_y']/2+1).rect(1.2,4.0).extrude(0.8)
        stage=stage.cut(relief)
    return stage

# ---------- Coil bobbin ----------
def make_coil_bobbin():
    # thin rectangular bobbin bonded under sled. Winding around perimeter.
    ox,oy=P['coil_outer_x'],P['coil_outer_y']; ix,iy=P['coil_inner_x'],P['coil_inner_y']
    t=P['coil_bobbin_t']; fl=P['coil_flange_t']
    # central web ring
    ring=cq.Workplane('XY').rect(ox,oy).extrude(t)
    ring=ring.cut(cq.Workplane('XY').rect(ix,iy).extrude(t+0.2).translate((0,0,-0.1)))
    # carve winding channel from exterior sides, leaving bottom/top flanges
    ch_ox=ox-1.0; ch_oy=oy-1.0
    ch_ix=ix+1.0; ch_iy=iy+1.0
    channel=cq.Workplane('XY').rect(ch_ox,ch_oy).extrude(P['coil_channel_depth']).translate((0,0,fl))
    channel=channel.cut(cq.Workplane('XY').rect(ch_ix,ch_iy).extrude(P['coil_channel_depth']+0.2).translate((0,0,fl-0.1)))
    ring=ring.cut(channel)
    # two lead notches at rear
    for x in (-3,3):
        notch=cq.Workplane('YZ').center(-oy/2,fl+P['coil_channel_depth']/2).rect(1.0,1.4).extrude(3).translate((x,0,0))
        ring=ring.cut(notch)
    return ring

# ---------- Magnet carrier ----------
def make_magnet_carrier():
    x,y,t=P['magnet_carrier_x'],P['magnet_carrier_y'],P['magnet_carrier_t']
    c=cq.Workplane('XY').rect(x,y).extrude(t)
    # pockets from top for two bar magnets, opposite polarity on assembly
    for mx in (-P['mag_center_x'],P['mag_center_x']):
        pocket=(cq.Workplane('XY').center(mx,0).rect(P['mag_x'],P['mag_y']).extrude(P['mag_z']).translate((0,0,t-P['mag_z'])))
        c=c.cut(pocket)
    # center clearance and wire relief
    c=c.cut(cq.Workplane('XY').rect(10,16).extrude(t+0.2).translate((0,0,-0.1)))
    # steel backplate recess from bottom (optional plate)
    steel=(cq.Workplane('XY').rect(P['steel_plate_x']+0.3,P['steel_plate_y']+0.3).extrude(P['steel_plate_z']).translate((0,0,-0.01)))
    c=c.cut(steel)
    # two M2.5 screw holes, can also just glue
    for yy in (-12,12):
        c=c.cut(cq.Workplane('XY').center(0,yy).circle(1.35).extrude(t+0.2).translate((0,0,-0.1)))
    return c

# ---------- Sensor risers ----------
def make_sensor_riser(height):
    # Raises the optical texture close to the mouse bottom while compliant stage stays low.
    # Three heights are exported because optical lift-off distance varies by mouse.
    x,y=32.0,26.0
    r=cq.Workplane('XY').rect(x,y).extrude(height)
    recess=(cq.Workplane('XY').rect(P['sensor_tile_x']+0.25,P['sensor_tile_y']+0.25)
            .extrude(P['sensor_recess_d']+0.05).translate((0,0,height-P['sensor_recess_d'])))
    r=r.cut(recess)
    return r

# ---------- Sensor tile ----------
def make_sensor_tile():
    x,y,t=P['sensor_tile_x'],P['sensor_tile_y'],P['sensor_tile_t']
    tile=cq.Workplane('XY').rect(x,y).extrude(t)
    # shallow random-ish deterministic pits, usable as tactile/optical microtexture but paper overlay still recommended
    pts=[]
    for ix in range(-6,7):
      for iy in range(-4,5):
        # deterministic jitter without random package
        jx=((ix*37+iy*17)%7-3)*0.12
        jy=((ix*19-iy*29)%7-3)*0.12
        px=ix*2.1+jx; py=iy*2.2+jy
        if abs(px)<x/2-1.2 and abs(py)<y/2-1.2:
            pts.append((px,py))
    pits=cq.Workplane('XY').pushPoints(pts).circle(0.38).extrude(0.22).translate((0,0,t-0.21))
    tile=tile.cut(pits)
    return tile

# ---------- Flexure calibration coupon ----------
def make_flexure_coupon():
    # Three miniature flexure cells. Left/center/right = 0.50/0.55/0.60 mm beam width.
    W,H=96.0,60.0
    frame=cq.Workplane('XY').rect(W,H).extrude(2.0)
    frame=frame.cut(cq.Workplane('XY').rect(W-6,H-6).extrude(2.3).translate((0,0,-0.1)))
    # separators make three independent windows
    for x in (-16,16):
        frame=frame.union(cq.Workplane('XY').center(x,0).rect(2.0,H-6).extrude(2.0))
    stage=frame
    xvals=(-32,0,32); widths=(0.50,0.55,0.60)
    inner_y=H/2-3
    pad_y=10.0
    beam_len=inner_y-pad_y/2
    for idx,(x,w) in enumerate(zip(xvals,widths),start=1):
        pad=cq.Workplane('XY').center(x,0).rect(10,10).extrude(2.0)
        # two parallel beams, top/bottom, same geometry as main stage scaled locally
        for sign in (-1,1):
            y0=sign*(pad_y/2+beam_len/2)
            beam=cq.Workplane('XY').center(x,y0).rect(w,beam_len+0.04).extrude(0.8).translate((0,0,0.6))
            pad=pad.union(beam)
        # identification holes: 1 / 2 / 3 holes in pad
        for j in range(idx):
            hx=x+(j-(idx-1)/2)*2.5
            pad=pad.cut(cq.Workplane('XY').center(hx,0).circle(0.65).extrude(2.3).translate((0,0,-0.1)))
        stage=stage.union(pad)
    return stage

# ---------- Coil winding jig ----------
def make_winding_jig():
    # removable two-part-ish simple winding mandrel; wind coil then slide off and place on bobbin.
    core=cq.Workplane('XY').rect(P['coil_inner_x']-0.5,P['coil_inner_y']-0.5).extrude(8)
    flange1=cq.Workplane('XY').rect(P['coil_outer_x']+5,P['coil_outer_y']+5).extrude(1.2)
    flange2=cq.Workplane('XY').rect(P['coil_outer_x']+5,P['coil_outer_y']+5).extrude(1.2).translate((0,0,8))
    jig=core.union(flange1).union(flange2)
    # slit to remove coil and lead notches
    slit=cq.Workplane('XZ').rect(2,10).extrude(P['coil_outer_y']+8).translate((0,-(P['coil_outer_y']+8)/2,0))
    jig=jig.cut(slit)
    return jig

parts={
 'base':make_base(),
 'lid':make_lid(),
 'flexure_stage_050':make_stage(0.50),
 'flexure_stage_055':make_stage(0.55),
 'flexure_stage_060':make_stage(0.60),
 'coil_bobbin':make_coil_bobbin(),
 'magnet_carrier':make_magnet_carrier(),
 'sensor_riser_low':make_sensor_riser(5.2),
 'sensor_riser_mid':make_sensor_riser(5.5),
 'sensor_riser_high':make_sensor_riser(5.8),
 'sensor_tile':make_sensor_tile(),
 'flexure_calibration_coupon':make_flexure_coupon(),
 'coil_winding_jig':make_winding_jig(),
}
for name,shape in parts.items(): export(shape,name)

# assembled STEP compound using actual intended Z stack
assy=[]
assy.append(parts['base'])
assy.append(parts['magnet_carrier'].translate((0,0,P['floor_t']+1.0)))
assy.append(parts['flexure_stage_055'].translate((0,0,P['stage_z'])))
# bobbin bottom attached to underside of sled; stage at z stage_z
assy.append(parts['coil_bobbin'].translate((0,0,P['stage_z']-P['coil_bobbin_t']+0.70)))
assy.append(parts['sensor_riser_mid'].translate((0,0,P['stage_z']+P['sled_t'])))
assy.append(parts['sensor_tile'].translate((0,0,P['stage_z']+P['sled_t']+5.5-P['sensor_recess_d']+0.02)))
assy.append(parts['lid'].translate((0,0,P['base_h'])))
compound=cq.Compound.makeCompound([s.val() for s in assy])
exporters.export(compound, str(STEP/'assembly.step'))
# also assembly STL for viewing only
exporters.export(compound, str(STL/'assembly_reference.stl'), tolerance=0.02, angularTolerance=0.3)

# parameters dump
(ROOT/'docs'/'parameters.json').write_text(json.dumps(P,indent=2), encoding='utf-8')
print('Generated', len(parts), 'parts + assembly')
