$fn=64;
color([0.18,0.20,0.23]) import("../stl/flexure_stage_055.stl");
