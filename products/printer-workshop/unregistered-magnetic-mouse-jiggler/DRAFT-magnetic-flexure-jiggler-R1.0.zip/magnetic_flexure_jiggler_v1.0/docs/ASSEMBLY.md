# Assembly sequence

## A. Calibrate flexure

1. Print `flexure_calibration_coupon`.
2. Deflect each centre pad sideways by roughly 1 mm and release.
3. Choose the narrowest beam that prints reliably and returns cleanly without permanent set. Default is the centre cell: 0.55 mm.

## B. Build magnet cartridge

1. Dry-fit two nominal 20 × 5 × 2 mm bar magnets in `magnet_carrier`.
2. Mark their poles before assembly.
3. Install them with **opposite top poles**:

```
Top view / looking down at magnets

      moving coil above

      N ↑          S ↑
   [ MAGNET ]   [ MAGNET ]
      left          right
```

4. Optional but recommended: place a 34 × 24 × ~1 mm low-carbon steel plate in the underside recess as magnetic back iron.
5. Glue only after the dry-run polarity test works.

## C. Wind moving coil

1. Use `coil_winding_jig`.
2. Start with 0.15 mm enamelled copper wire.
3. Wind approximately 150 turns evenly.
4. Target room-temperature resistance: roughly 10–15 Ω.
5. Secure with a small amount of thin epoxy or varnish.
6. Transfer/fit to `coil_bobbin` and route the two flexible leads to the rear.

## D. Build moving stage

1. Bond the coil bobbin into the underside recess of the flexure sled.
2. Bond the selected `sensor_riser_*` to the top of the sled, centred.
3. Fit the sensor tile into the riser recess.
4. Keep the coil leads as loose loops; they must not significantly spring-load the sled.

## E. Install in base

1. Place the magnet carrier on the central pedestal.
2. Install the flexure stage on the four support pads.
3. Verify that the coil does not touch either magnet through the full ±1 mm travel.
4. Verify the end-stop ears engage before the flexures are over-travelled.
5. Route electronics in the generic right-side bay.

## F. Electrical test

1. Start with a low PWM duty and short pulses.
2. Confirm one polarity moves the sled left and the opposite polarity moves it right.
3. If it only attracts vertically or does not move laterally, re-check magnet polarity and coil alignment.
4. Increase duty only until the sled reaches approximately 1 mm, not until it slams the hard stop.
5. Check coil temperature after repeated test pulses.

## G. Optical test

1. Fit the lid.
2. Position the mouse so its optical sensor is directly over the window.
3. Start with the medium riser.
4. If there is no tracking, try high; if the mouse rubs, use low.
5. Apply the supplied matte high-contrast texture if the printed surface tracks poorly.
