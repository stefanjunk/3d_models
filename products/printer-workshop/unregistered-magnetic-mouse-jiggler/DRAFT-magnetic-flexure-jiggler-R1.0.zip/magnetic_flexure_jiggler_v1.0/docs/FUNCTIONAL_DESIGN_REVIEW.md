# Functional Design Review — R1.0

## Requirement decomposition

| Requirement | Design response | Verification |
|---|---|---|
| Very quiet | No gears/sliding guides; moving-coil actuator | Bench sound test after coil build |
| 1D motion only | Four parallel flexure beams | Visual + hand displacement test |
| ~±1 mm | Flexure geometry + hard stops at ~±1.2 mm | Caliper/video check |
| Constant optical height | In-plane compliant stage | Optical tracking test |
| Mouse compatibility | Three riser heights | Low/mid/high trial |
| FDM printable | Flat monolithic flexure stage; no support-critical parts | Slicer inspection + STL mesh check |
| Cheap components | Wire, two bar magnets, H-bridge, MCU | BOM |
| Random timing possible | MCU firmware included | Firmware test |

## First-order mechanics

Default PETG flexure calculation (fixed-guided approximation):

- 4 beams
- free length ~21 mm
- width 0.55 mm
- Z thickness 0.80 mm
- nominal travel 1.0 mm
- total stiffness ~0.115 N/mm
- required static force at 1 mm ~0.115 N
- nominal maximum bending strain ~0.37 %

The hard stop is intentionally beyond the commanded travel so normal motion should not repeatedly impact it.

## Actuator concept

The moving rectangular coil has two long current-carrying sides above two fixed bar magnets. The magnets have opposite vertical polarity. The two coil sides carry opposite current direction, so the opposite magnetic fields cause both Lorentz forces to add in the same lateral direction. Reversing current reverses the lateral force.

R1.0 target winding:

- 0.15 mm enamelled copper wire
- about 150 turns
- estimated length ~13.8 m
- estimated resistance ~13 Ω
- expected operating current for the default stage is in the low hundreds of milliamps, but must be established experimentally.

## DFM risks and mitigations

1. **Thin beam deletion in slicer** — three stage variants and a coupon are supplied; inspect all four beams in preview.
2. **PETG stringing around flexures** — print stage alone, dry filament, lower travel moves, clean strings without nicking beams.
3. **Mouse sensor height variation** — three risers produce different optical gaps.
4. **Magnet dimensions vary** — pockets include ~0.2 mm nominal XY clearance; verify before gluing.
5. **Actuator force uncertain** — winding jig, current-controlled PWM and staged bench test are required.
6. **Moving-wire spring force** — leave a relaxed wire loop; use fine flexible leads.
7. **Coil heating** — intermittent drive only; verify temperature at intended duty cycle.
8. **Mechanical resonance** — random slow pulses and smooth current ramps; rubber feet optional.

## Geometry validation performed

- All individual exported STLs are watertight/manifold.
- The flexure stage is a single connected printable body.
- Nominal moving envelope fits the 36 × 30 mm lid opening with margin at the hard-stop travel.
- Default medium riser puts the tile about 0.65 mm below the lid top plane.
- Nominal magnet top to bobbin plastic underside gap is about 0.7 mm in the reference assembly.

## Physical acceptance criteria for R1.1

Before promoting this design from prototype to validated release:

- Default stage returns to centre for at least 1,000 manual/actuated cycles with no visible set.
- Coil reaches ±0.8–1.0 mm without hard-stop impact at a reasonable current.
- Coil temperature remains comfortably below softening temperatures during intended intermittent operation.
- At least two different optical mice track the moving tile with one of the supplied risers.
- Device is not perceptibly louder than a quiet room at normal desk distance.
- Random drive does not produce repeatable mechanical clicking.
