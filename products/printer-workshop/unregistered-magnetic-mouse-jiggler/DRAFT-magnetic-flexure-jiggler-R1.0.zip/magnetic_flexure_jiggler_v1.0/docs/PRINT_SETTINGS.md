# Print settings — R1.0

## General

- Nozzle: 0.4 mm
- Layer height: 0.20 mm
- Perimeters: 4 for base/lid, 3 for small parts
- Top/bottom layers: 5
- Infill: 20–30 % for base/lid; 100 % is not required
- Supports: none intended
- Elephant-foot compensation: 0.15–0.25 mm recommended

## Flexure stage — critical

- Material: PETG preferred for the first functional prototype.
- Print flat, as exported.
- Layer height: 0.20 mm.
- Use a line width that can actually produce the selected beam. For the default 0.55 mm stage, 0.48–0.55 mm line width works well on a 0.4 nozzle.
- Disable features that silently delete thin walls.
- Inspect preview: all four long flexure beams must be continuous from frame to sled.
- Do not sand or heat the flexures.
- If the default feels too stiff or the actuator cannot reach the stop: use `flexure_stage_050`.
- If beams print inconsistently or feel too fragile: use `flexure_stage_060`.

## Lid

The geometry contains underside locating tabs. The `stl_print_ready/lid.stl` copy is already flipped so the broad top face sits on the bed and the locating tabs print upward.

## Sensor tile

Print in matte PLA/PETG. Optical sensors often track a high-contrast matte paper/label better than a single-colour printed surface. `assets/sensor_texture.svg` is sized to the tile and can be printed at 100 % scale and adhered to the top.

## Coil bobbin / winding jig

PLA is fine. Print slowly enough to keep the winding channel clean. Remove burrs before winding to avoid damaging enamel insulation.
