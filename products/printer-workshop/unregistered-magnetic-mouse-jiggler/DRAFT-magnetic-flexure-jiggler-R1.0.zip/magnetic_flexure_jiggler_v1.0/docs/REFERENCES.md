# Engineering references used for the actuator concept

The mechanical geometry in this package is original and parametrically generated for this prototype. The actuator topology follows standard voice-coil / Lorentz-force practice.

- MIT Center for Bits and Atoms, *Voice Coil Actuators* — Lorentz-force principle and moving-coil actuator basics.
  - https://fab.cba.mit.edu/classes/865.18/motion/voiceCoil/index.html
- H2W Technologies, moving-magnet voice-coil actuator with integrated flexure bearing — example of combining non-contact electromagnetic actuation and flexure guidance.
  - https://www.h2wtech.com/product/voice-coil-actuators/NCM02-17-035-2F
- A. S. B. Akash, *Linear Voice Coil Actuator* — accessible 3D-printed voice-coil prototype using enamelled copper wire, permanent magnets and an H-bridge.
  - https://www.hackster.io/asbroakash/linear-voice-coil-actuator-b6bc64

These references validate the general topology, not the exact R1.0 force estimate. The exact magnetic circuit in this design still requires prototype measurement.
