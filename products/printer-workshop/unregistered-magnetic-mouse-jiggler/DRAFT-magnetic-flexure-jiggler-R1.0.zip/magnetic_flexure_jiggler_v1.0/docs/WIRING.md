# Wiring

Suggested topology:

```text
5 V USB supply
   +5V  ------------------+-------------------+
                          |                   |
                       ESP32-C3            DRV8833 VM
                          |                   |
GND  ---------------------+-------------------+---- GND

ESP GPIO 4  -------------------------------> IN1
ESP GPIO 5  -------------------------------> IN2

DRV8833 OUT1  ------------------------------ coil lead A
DRV8833 OUT2  ------------------------------ coil lead B
```

Use a common ground. Keep coil current out of the microcontroller pins; the H-bridge supplies the coil. Start at low PWM duty.

For reduced electrical noise, place a local bulk capacitor near the H-bridge supply (for example 100–470 µF) plus a small ceramic bypass capacitor. Exact values are not mechanically constrained by this design.
