import math, json
from pathlib import Path
P=json.loads((Path(__file__).parent/'parameters.json').read_text())
# Flexure beam approximated as fixed-guided beam. Four beams share load.
E_petg=2.0e9
E_pla=3.2e9
L=((P['stage_y']/2-P['stage_frame_w'])-P['sled_y']/2)/1000
w=P['flex_w']/1000
t=P['flex_t']/1000
delta=P['travel']/1000

def flex(E):
    k_one=E*t*w**3/L**3  # N/m, equivalent 12EI/L^3, I=t*w^3/12
    k_total=4*k_one
    force=k_total*delta
    strain=3*w*delta/L**2
    stress=E*strain
    return k_total,force,strain,stress

# Coil estimate. Rectangle mean perimeter and Lorentz active wire length.
wire_d=0.15e-3
turns=150
rho=1.68e-8
mean_x=(P['coil_outer_x']+P['coil_inner_x'])/2/1000
mean_y=(P['coil_outer_y']+P['coil_inner_y'])/2/1000
wire_len=turns*2*(mean_x+mean_y)
area=math.pi*(wire_d/2)**2
R=rho*wire_len/area
active_y=(P['mag_y']-2.0)/1000
B_eff=0.15 # T conservative working estimate in airgap; must be verified physically
I_req=flex(E_petg)[1]/(2*turns*active_y*B_eff)
Pcoil=I_req**2*R

lines=[]
for name,E in [('PETG',E_petg),('PLA',E_pla)]:
    k,F,eps,sigma=flex(E)
    lines += [f'{name}: k_total={k/1000:.3f} N/mm, force@1mm={F:.3f} N, peak_strain~{eps*100:.2f} %, nominal_bending_stress~{sigma/1e6:.1f} MPa']
lines += [
 f'Flexure free beam length: {L*1000:.2f} mm',
 f'Coil assumption: {turns} turns, {wire_d*1000:.2f} mm enamel copper wire, mean wire length ~{wire_len:.1f} m',
 f'Estimated coil resistance: ~{R:.1f} ohm at room temperature',
 f'With assumed effective B={B_eff:.2f} T and active conductor length {active_y*1000:.1f} mm per side:',
 f'Estimated current for PETG static 1 mm deflection: ~{I_req:.2f} A',
 f'Estimated coil dissipation at that current: ~{Pcoil:.2f} W (intermittent drive)',
 'IMPORTANT: magnetic flux density and force are estimates; verify on the actuator test before long unattended operation.'
]
report='\n'.join(lines)+'\n'
(Path(__file__).parent/'engineering_report.txt').write_text(report)
print(report)
