/*
  Magnetic 1D Flexure Jiggler R1.0
  ESP32-C3 + DRV8833-style dual-input H-bridge

  Behavior:
  - stays mechanically centered with no current
  - waits a randomized interval
  - applies a smooth current pulse left or right
  - releases so the flexures return to center

  IMPORTANT:
  Start with MAX_DUTY low and increase only until the sled reaches roughly 0.8–1.0 mm.
  Do not tune it to repeatedly hit the mechanical stops.
*/

#include <Arduino.h>
#include <esp_system.h>

static const int PIN_IN1 = 4;
static const int PIN_IN2 = 5;
static const uint32_t PWM_HZ = 20000;   // above most audible range
static const uint8_t PWM_BITS = 8;

static const uint8_t MAX_DUTY = 90;     // 0..255; conservative starting point
static const uint32_t WAIT_MIN_MS = 25000;
static const uint32_t WAIT_MAX_MS = 110000;
static const uint32_t PULSE_MIN_MS = 260;
static const uint32_t PULSE_MAX_MS = 850;

void coast() {
  ledcWrite(PIN_IN1, 0);
  ledcWrite(PIN_IN2, 0);
}

void driveSigned(int sign, uint8_t duty) {
  duty = constrain(duty, 0, 255);
  if (sign > 0) {
    ledcWrite(PIN_IN1, duty);
    ledcWrite(PIN_IN2, 0);
  } else {
    ledcWrite(PIN_IN1, 0);
    ledcWrite(PIN_IN2, duty);
  }
}

// Smooth half-sine envelope to avoid an audible/mechanical snap.
void smoothPulse(int sign, uint32_t durationMs, uint8_t peakDuty) {
  const int steps = 48;
  const uint32_t dt = max<uint32_t>(2, durationMs / steps);
  for (int i = 0; i <= steps; ++i) {
    float phase = PI * (float)i / (float)steps;
    float envelope = sinf(phase);
    uint8_t d = (uint8_t)roundf(peakDuty * envelope);
    driveSigned(sign, d);
    delay(dt);
  }
  coast();
}

void setup() {
  // Arduino-ESP32 core 3.x API: PWM is attached directly to pins.
  ledcAttach(PIN_IN1, PWM_HZ, PWM_BITS);
  ledcAttach(PIN_IN2, PWM_HZ, PWM_BITS);
  coast();

  // Mix timer noise into the PRNG. No cryptographic randomness is required here.
  randomSeed((uint32_t)micros() ^ (uint32_t)esp_random());
}

void loop() {
  uint32_t waitMs = random(WAIT_MIN_MS, WAIT_MAX_MS + 1);
  delay(waitMs);

  int sign = random(0, 2) ? 1 : -1;
  uint32_t pulseMs = random(PULSE_MIN_MS, PULSE_MAX_MS + 1);
  uint8_t peak = (uint8_t)random((int)(MAX_DUTY * 0.65), MAX_DUTY + 1);

  smoothPulse(sign, pulseMs, peak);

  // Usually let the flexures return completely before the next command.
  delay(random(120, 650));

  // Occasional smaller opposite nudge adds temporal/trajectory variation.
  if (random(0, 100) < 28) {
    smoothPulse(-sign, random(120, 360), (uint8_t)(peak * 0.45));
  }
  coast();
}
