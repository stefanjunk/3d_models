# Entscheidungsprotokoll

- **Grundform:** regelmäßiges, flach oben/unten orientiertes Sechseck. Dadurch entsteht unten eine echte horizontale Stellfläche und die Zellen bilden ein lückenloses Wabengitter.
- **Größe:** 168 × 145,49 × 72 mm außen; das passt auf viele 220-mm-Druckbetten und bietet etwa 149,5 × 129,5 × 67,2 mm nutzbaren Innenraum.
- **Verbindung:** universelle U-Brücken statt fester männlicher/weiblicher Kanten. Jede der sechs Seiten bleibt wahlfrei; zwei Clips pro gemeinsamer Kante begrenzen Verdrehung.
- **Wandmontage:** zwei durchgehende Schraublöcher mit von vorn zugänglicher Kopf-Senkung. Schrauben und Dübel bleiben wand- und lastspezifische Kaufteile.
- **Textur:** 0,6-mm-Gravur aus einer 16-Bit-Höhenkarte. Die Maserung läuft auf Innen- und Außenwänden entlang der Tiefe und wird nicht pro Fläche neu gedreht. Rückseite und Passflächen bleiben glatt.
- **Repräsentation:** präzise Basis als B-Rep/STEP, dichte Holzoberfläche erst im finalen Dreiecksmesh. Dadurch bleibt die parametrische Basis editierbar und die Rastertextur überlastet den CAD-Featurebaum nicht.
- **Material:** PETG als belastbarere Standardannahme; Holzfill ist eine dekorative, abrasive und herstellerspezifische Variante, die neu kalibriert werden muss.
- **Status:** experimentell bis Geometrie-, Slicer-, Clip-, Wand- und Kriechversuche mit dem tatsächlichen Druckprozess bestanden sind.
